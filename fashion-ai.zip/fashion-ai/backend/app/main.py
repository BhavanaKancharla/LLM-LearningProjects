"""
Fashion AI - Virtual Try-On & Color Analysis Application
Main FastAPI application entry point
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from app.models.database import engine, Base

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Fashion AI",
    description="AI-Powered Personalized Fashion Advisor with Virtual Try-On and Style Recommendation",
    version="2.0.0",
)

# CORS middleware for frontend - THIS MUST BE BEFORE ROUTES
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
os.makedirs("uploads", exist_ok=True)
os.makedirs("static/catalog", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Import and include routers - gracefully handle missing dependencies
from app.api import auth, catalog, recommendations
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(catalog.router, prefix="/api/catalog", tags=["Catalog"])
app.include_router(recommendations.router, prefix="/api/recommendations", tags=["Recommendations"])

try:
    from app.api import color_analysis
    app.include_router(color_analysis.router, prefix="/api/color-analysis", tags=["Color Analysis"])
except Exception as e:
    print(f"[WARN] Color analysis module not loaded: {e}")

try:
    from app.api import face_shape
    app.include_router(face_shape.router, prefix="/api/face-shape", tags=["Face Shape"])
except Exception as e:
    print(f"[WARN] Face shape module not loaded: {e}")

try:
    from app.api import body_type
    app.include_router(body_type.router, prefix="/api/body-type", tags=["Body Type"])
except Exception as e:
    print(f"[WARN] Body type module not loaded: {e}")

try:
    from app.api import hairstyle
    app.include_router(hairstyle.router, prefix="/api/hairstyle", tags=["Hairstyle"])
except Exception as e:
    print(f"[WARN] Hairstyle module not loaded: {e}")

try:
    from app.api import virtual_tryon
    app.include_router(virtual_tryon.router, prefix="/api/tryon", tags=["Virtual Try-On"])
except Exception as e:
    print(f"[WARN] Virtual try-on module not loaded: {e}")

try:
    from app.api import url_scraper
    app.include_router(url_scraper.router, prefix="/api/scraper", tags=["URL Scraper"])
except Exception as e:
    print(f"[WARN] URL scraper module not loaded: {e}")

try:
    from app.api import style_report
    app.include_router(style_report.router, prefix="/api/style-report", tags=["Style Report"])
except Exception as e:
    print(f"[WARN] Style report module not loaded: {e}")


@app.get("/")
def root():
    return {
        "message": "Fashion AI - Personalized Fashion Advisor",
        "version": "2.0.0",
        "docs": "/docs",
    }
