"""
Recommendation Service
Recommends clothing items based on the user's personal color analysis.
Uses color distance calculations and seasonal color theory.
"""

import numpy as np
from typing import List, Dict, Optional
from sqlalchemy.orm import Session
from app.models.database import CatalogItem
import colorsys


class RecommendationService:
    """Service for generating personalized clothing recommendations."""

    def __init__(self):
        pass

    def get_recommendations(
        self,
        db: Session,
        season: str,
        undertone: str,
        contrast_level: str,
        recommended_colors: List[str],
        category: Optional[str] = None,
        limit: int = 20,
    ) -> Dict:
        """
        Get clothing recommendations based on color profile.

        Args:
            db: Database session
            season: User's color season
            undertone: User's undertone (Warm/Cool/Neutral)
            contrast_level: User's contrast level
            recommended_colors: List of recommended hex colors
            category: Optional category filter
            limit: Max number of items to return

        Returns:
            Dictionary with recommended items, palette, and tips
        """
        # Query catalog items
        query = db.query(CatalogItem)
        if category:
            query = query.filter(CatalogItem.category == category)

        items = query.all()

        # Score each item based on color compatibility
        scored_items = []
        for item in items:
            score = self._calculate_match_score(
                item.color_hex, recommended_colors, undertone
            )
            scored_items.append((item, score))

        # Sort by score (highest first)
        scored_items.sort(key=lambda x: x[1], reverse=True)

        # Format results
        result_items = []
        for item, score in scored_items[:limit]:
            result_items.append({
                "id": item.id,
                "name": item.name,
                "category": item.category,
                "color_hex": item.color_hex,
                "color_name": item.color_name,
                "image_url": item.image_url,
                "price": item.price,
                "description": item.description,
                "tags": item.tags or [],
                "match_score": round(score, 2),
            })

        # Generate color palette for the user
        palette = self._generate_palette(season, undertone, contrast_level)

        # Generate styling tips
        tips = self._generate_styling_tips(season, undertone, contrast_level, category)

        return {
            "items": result_items,
            "color_palette": palette,
            "styling_tips": tips,
        }

    def _calculate_match_score(
        self, item_hex: str, recommended_colors: List[str], undertone: str
    ) -> float:
        """
        Calculate how well a clothing item's color matches the user's palette.

        Uses CIE Lab color space for perceptually uniform distance calculation.
        """
        if not item_hex or not recommended_colors:
            return 0.5

        item_rgb = self._hex_to_rgb(item_hex)
        item_lab = self._rgb_to_lab(item_rgb)

        # Find minimum distance to any recommended color
        min_distance = float("inf")
        for rec_hex in recommended_colors:
            if isinstance(rec_hex, dict):
                rec_hex = rec_hex.get("hex", "#000000")
            rec_rgb = self._hex_to_rgb(rec_hex)
            rec_lab = self._rgb_to_lab(rec_rgb)

            distance = np.sqrt(sum((a - b) ** 2 for a, b in zip(item_lab, rec_lab)))
            min_distance = min(min_distance, distance)

        # Convert distance to score (0-1, higher is better)
        # Max perceptual distance in Lab space is ~100
        score = max(0, 1 - (min_distance / 100))

        # Bonus for undertone match
        item_h, item_s, item_v = colorsys.rgb_to_hsv(
            item_rgb[0] / 255, item_rgb[1] / 255, item_rgb[2] / 255
        )
        hue_degrees = item_h * 360

        if undertone == "Warm" and 15 <= hue_degrees <= 60:
            score = min(1.0, score + 0.1)
        elif undertone == "Cool" and (hue_degrees > 200 or hue_degrees < 15):
            score = min(1.0, score + 0.1)

        return score

    def _hex_to_rgb(self, hex_color: str) -> tuple:
        """Convert hex color to RGB tuple."""
        hex_color = hex_color.lstrip("#")
        return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))

    def _rgb_to_lab(self, rgb: tuple) -> tuple:
        """Convert RGB to CIE Lab color space (simplified)."""
        # Normalize RGB
        r, g, b = [x / 255.0 for x in rgb]

        # Linearize
        r = ((r + 0.055) / 1.055) ** 2.4 if r > 0.04045 else r / 12.92
        g = ((g + 0.055) / 1.055) ** 2.4 if g > 0.04045 else g / 12.92
        b = ((b + 0.055) / 1.055) ** 2.4 if b > 0.04045 else b / 12.92

        # Convert to XYZ
        x = r * 0.4124 + g * 0.3576 + b * 0.1805
        y = r * 0.2126 + g * 0.7152 + b * 0.0722
        z = r * 0.0193 + g * 0.1192 + b * 0.9505

        # Normalize for D65 illuminant
        x /= 0.95047
        y /= 1.00000
        z /= 1.08883

        # Convert to Lab
        def f(t):
            return t ** (1 / 3) if t > 0.008856 else (7.787 * t) + (16 / 116)

        l = 116 * f(y) - 16
        a = 500 * (f(x) - f(y))
        b_val = 200 * (f(y) - f(z))

        return (l, a, b_val)

    def _generate_palette(self, season: str, undertone: str, contrast: str) -> List[Dict]:
        """Generate a curated color palette for the user."""
        palettes = {
            "Spring_Warm": [
                {"hex": "#FF8C00", "name": "Dark Orange", "use": "Statement pieces"},
                {"hex": "#DAA520", "name": "Goldenrod", "use": "Accessories"},
                {"hex": "#228B22", "name": "Forest Green", "use": "Everyday wear"},
                {"hex": "#FF6347", "name": "Tomato", "use": "Accent color"},
                {"hex": "#FFFDD0", "name": "Cream", "use": "Base/Neutrals"},
            ],
            "Spring_Cool": [
                {"hex": "#87CEEB", "name": "Sky Blue", "use": "Everyday wear"},
                {"hex": "#FFB6C1", "name": "Light Pink", "use": "Tops"},
                {"hex": "#98FB98", "name": "Pale Green", "use": "Accents"},
                {"hex": "#DDA0DD", "name": "Plum", "use": "Evening wear"},
                {"hex": "#FFFFF0", "name": "Ivory", "use": "Base/Neutrals"},
            ],
            "Summer_Cool": [
                {"hex": "#4682B4", "name": "Steel Blue", "use": "Professional wear"},
                {"hex": "#DB7093", "name": "Pale Violet Red", "use": "Statement pieces"},
                {"hex": "#5F9EA0", "name": "Cadet Blue", "use": "Everyday wear"},
                {"hex": "#D8BFD8", "name": "Thistle", "use": "Light layers"},
                {"hex": "#F5F5F5", "name": "White Smoke", "use": "Base/Neutrals"},
            ],
            "Summer_Warm": [
                {"hex": "#BC8F8F", "name": "Rosy Brown", "use": "Everyday wear"},
                {"hex": "#6B8E23", "name": "Olive Drab", "use": "Casual wear"},
                {"hex": "#CD853F", "name": "Peru", "use": "Accessories"},
                {"hex": "#708090", "name": "Slate Gray", "use": "Professional wear"},
                {"hex": "#FAF0E6", "name": "Linen", "use": "Base/Neutrals"},
            ],
            "Autumn_Warm": [
                {"hex": "#8B4513", "name": "Saddle Brown", "use": "Outerwear"},
                {"hex": "#B8860B", "name": "Dark Goldenrod", "use": "Statement pieces"},
                {"hex": "#556B2F", "name": "Dark Olive Green", "use": "Everyday wear"},
                {"hex": "#D2691E", "name": "Chocolate", "use": "Accessories"},
                {"hex": "#F5DEB3", "name": "Wheat", "use": "Base/Neutrals"},
            ],
            "Autumn_Cool": [
                {"hex": "#2F4F4F", "name": "Dark Slate Gray", "use": "Professional wear"},
                {"hex": "#800000", "name": "Maroon", "use": "Statement pieces"},
                {"hex": "#006400", "name": "Dark Green", "use": "Outerwear"},
                {"hex": "#4B0082", "name": "Indigo", "use": "Evening wear"},
                {"hex": "#DEB887", "name": "Burlywood", "use": "Base/Neutrals"},
            ],
            "Winter_Cool": [
                {"hex": "#000080", "name": "Navy", "use": "Professional wear"},
                {"hex": "#DC143C", "name": "Crimson", "use": "Statement pieces"},
                {"hex": "#4169E1", "name": "Royal Blue", "use": "Everyday wear"},
                {"hex": "#8A2BE2", "name": "Blue Violet", "use": "Evening wear"},
                {"hex": "#FFFFFF", "name": "Pure White", "use": "Base/Neutrals"},
            ],
            "Winter_Warm": [
                {"hex": "#191970", "name": "Midnight Blue", "use": "Professional wear"},
                {"hex": "#8B0000", "name": "Dark Red", "use": "Statement pieces"},
                {"hex": "#006400", "name": "Dark Green", "use": "Outerwear"},
                {"hex": "#4B0082", "name": "Indigo", "use": "Evening wear"},
                {"hex": "#F8F8FF", "name": "Ghost White", "use": "Base/Neutrals"},
            ],
        }

        key = f"{season}_{undertone}"
        return palettes.get(key, palettes.get(f"{season}_Cool", []))

    def _generate_styling_tips(
        self, season: str, undertone: str, contrast: str, category: Optional[str]
    ) -> List[str]:
        """Generate context-specific styling tips."""
        tips = []

        # General season tips
        if season == "Spring":
            tips.append("Layer warm neutrals (camel, tan) with pops of coral or turquoise")
        elif season == "Summer":
            tips.append("Pair soft blues and lavenders with rose or dusty pink")
        elif season == "Autumn":
            tips.append("Mix earthy tones like olive, rust, and burgundy for a rich palette")
        elif season == "Winter":
            tips.append("Create impact with bold color blocking — navy with white, or red with black")

        # Category-specific tips
        if category == "tops":
            tips.append("Choose neckline colors that brighten your face")
            tips.append("Patterns work best when they include your recommended colors")
        elif category == "bottoms":
            tips.append("Neutral bottoms in your palette create versatile outfit foundations")
            tips.append("Match your belt and shoes for a polished look")
        elif category == "dresses":
            tips.append("Solid dresses in your best color make a strong statement")
            tips.append("Print dresses should have your recommended colors as the dominant hue")

        # Contrast tips
        if contrast == "High":
            tips.append("Bold prints and high-contrast color combos mirror your natural coloring")
        elif contrast == "Low":
            tips.append("Tonal dressing (shades of one color family) creates a sophisticated look")

        return tips
