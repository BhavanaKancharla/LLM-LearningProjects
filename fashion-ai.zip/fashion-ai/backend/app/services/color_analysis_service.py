"""
Color Analysis Service
Analyzes user's skin tone, hair, and eye color to determine their seasonal color type.
Uses OpenCV DNN face detector + K-Means clustering for color extraction.
Works on Windows, Linux, and Mac without mediapipe solutions dependency.
"""

import cv2
import numpy as np
from sklearn.cluster import KMeans
from PIL import Image
from typing import Tuple, Dict, List
import colorsys
import urllib.request
import os


class ColorAnalysisService:
    """Service for personal color analysis using computer vision."""

    # Path to store the face detection model
    MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "models")
    FACE_MODEL = "face_detection_yunet_2023mar.onnx"
    FACE_MODEL_URL = "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx"

    # Seasonal color palettes (hex colors)
    SEASON_PALETTES = {
        "Spring": {
            "Light Spring": {
                "colors": ["#FFDB58", "#98FB98", "#87CEEB", "#FFB6C1", "#FFDAB9",
                           "#F0E68C", "#DDA0DD", "#FA8072", "#40E0D0", "#FF6347"],
                "avoid": ["#000000", "#1C1C1C", "#4B0082", "#800000", "#2F4F4F"],
            },
            "Warm Spring": {
                "colors": ["#FF8C00", "#DAA520", "#CD853F", "#FF6347", "#228B22",
                           "#FF4500", "#B8860B", "#D2691E", "#6B8E23", "#BC8F8F"],
                "avoid": ["#000080", "#4B0082", "#C0C0C0", "#808080", "#191970"],
            },
            "Clear Spring": {
                "colors": ["#FF0000", "#00FF00", "#FF69B4", "#1E90FF", "#FFD700",
                           "#FF4500", "#00CED1", "#FF1493", "#32CD32", "#FF8C00"],
                "avoid": ["#808080", "#A9A9A9", "#D3D3D3", "#696969", "#2F4F4F"],
            },
        },
        "Summer": {
            "Light Summer": {
                "colors": ["#B0C4DE", "#DDA0DD", "#98FB98", "#FFB6C1", "#E6E6FA",
                           "#87CEEB", "#F0E68C", "#FFC0CB", "#ADD8E6", "#D8BFD8"],
                "avoid": ["#FF0000", "#FF8C00", "#000000", "#8B4513", "#FF4500"],
            },
            "Cool Summer": {
                "colors": ["#4682B4", "#6A5ACD", "#DB7093", "#5F9EA0", "#BC8F8F",
                           "#708090", "#9370DB", "#CD5C5C", "#4169E1", "#8B4789"],
                "avoid": ["#FF8C00", "#FFD700", "#FF4500", "#8B4513", "#DAA520"],
            },
            "Soft Summer": {
                "colors": ["#708090", "#BC8F8F", "#8FBC8F", "#D8BFD8", "#B0C4DE",
                           "#9370DB", "#6B8E23", "#CD853F", "#778899", "#DEB887"],
                "avoid": ["#FF0000", "#00FF00", "#0000FF", "#FF00FF", "#FFD700"],
            },
        },
        "Autumn": {
            "Soft Autumn": {
                "colors": ["#D2B48C", "#8FBC8F", "#BC8F8F", "#DEB887", "#9ACD32",
                           "#CD853F", "#DAA520", "#808000", "#BDB76B", "#F4A460"],
                "avoid": ["#FF00FF", "#00FFFF", "#FF69B4", "#0000FF", "#FF1493"],
            },
            "Warm Autumn": {
                "colors": ["#8B4513", "#B8860B", "#556B2F", "#8B0000", "#D2691E",
                           "#A0522D", "#6B4423", "#808000", "#704214", "#CC5500"],
                "avoid": ["#FF69B4", "#87CEEB", "#E6E6FA", "#00FFFF", "#DDA0DD"],
            },
            "Deep Autumn": {
                "colors": ["#800000", "#006400", "#191970", "#4B0082", "#8B4513",
                           "#2F4F4F", "#800080", "#B22222", "#228B22", "#483D8B"],
                "avoid": ["#FFB6C1", "#E6E6FA", "#F0E68C", "#FFDAB9", "#ADD8E6"],
            },
        },
        "Winter": {
            "Deep Winter": {
                "colors": ["#000080", "#8B0000", "#006400", "#4B0082", "#2F4F4F",
                           "#191970", "#800000", "#004040", "#36013F", "#1C1C1C"],
                "avoid": ["#FFD700", "#FF8C00", "#FFDAB9", "#F5DEB3", "#DEB887"],
            },
            "Cool Winter": {
                "colors": ["#0000FF", "#FF00FF", "#4169E1", "#C71585", "#00008B",
                           "#8A2BE2", "#DC143C", "#4682B4", "#9400D3", "#1E90FF"],
                "avoid": ["#DAA520", "#D2691E", "#8B4513", "#CD853F", "#DEB887"],
            },
            "Clear Winter": {
                "colors": ["#FF0000", "#0000FF", "#FF00FF", "#00FF00", "#FFD700",
                           "#FF1493", "#00BFFF", "#FF4500", "#7FFF00", "#FF69B4"],
                "avoid": ["#808080", "#A9A9A9", "#696969", "#D3D3D3", "#C0C0C0"],
            },
        },
    }

    def __init__(self):
        """Initialize OpenCV DNN face detector."""
        os.makedirs(self.MODEL_DIR, exist_ok=True)
        model_path = os.path.join(self.MODEL_DIR, self.FACE_MODEL)

        # Download model if not present
        if not os.path.exists(model_path):
            print(f"[INFO] Downloading face detection model...")
            urllib.request.urlretrieve(self.FACE_MODEL_URL, model_path)
            print(f"[INFO] Model downloaded to {model_path}")

        self.face_detector = cv2.FaceDetectorYN.create(
            model_path, "", (300, 300), 0.5, 0.3, 5000
        )

    def analyze(self, image_path: str) -> Dict:
        """Perform complete color analysis on a user's photo."""
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError("Could not read image file")

        h, w, _ = image.shape
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Detect face
        self.face_detector.setInputSize((w, h))
        _, faces = self.face_detector.detect(image)

        if faces is None or len(faces) == 0:
            raise ValueError("No face detected in the image. Please upload a clear face photo.")

        face = faces[0]  # First detected face
        # face format: [x, y, w, h, right_eye_x, right_eye_y, left_eye_x, left_eye_y, nose_x, nose_y, mouth_right_x, mouth_right_y, mouth_left_x, mouth_left_y, score]
        fx, fy, fw, fh = int(face[0]), int(face[1]), int(face[2]), int(face[3])

        # Extract color regions
        skin_color = self._extract_skin_color(image_rgb, fx, fy, fw, fh, face)
        hair_color = self._extract_hair_color(image_rgb, fx, fy, fw, fh)
        eye_color = self._extract_eye_color(image_rgb, face, w, h)

        # Determine undertone
        undertone = self._determine_undertone(skin_color)

        # Determine contrast level
        contrast = self._determine_contrast(skin_color, hair_color, eye_color)

        # Classify season
        season, sub_season = self._classify_season(skin_color, undertone, contrast)

        # Get recommended and avoid colors
        palette_data = self.SEASON_PALETTES[season][sub_season]
        recommended = self._format_colors(palette_data["colors"])
        avoid = self._format_colors(palette_data["avoid"])

        # Generate style tips
        tips = self._generate_style_tips(season, sub_season, undertone, contrast)

        return {
            "skin_tone": {
                "hex": self._rgb_to_hex(skin_color),
                "rgb": list(map(int, skin_color)),
                "name": self._get_color_name(skin_color),
            },
            "hair_color": {
                "hex": self._rgb_to_hex(hair_color),
                "rgb": list(map(int, hair_color)),
                "name": self._get_color_name(hair_color),
            },
            "eye_color": {
                "hex": self._rgb_to_hex(eye_color),
                "rgb": list(map(int, eye_color)),
                "name": self._get_color_name(eye_color),
            },
            "season": season,
            "sub_season": sub_season,
            "undertone": undertone,
            "contrast_level": contrast,
            "recommended_colors": recommended,
            "avoid_colors": avoid,
            "style_tips": tips,
        }

    def _extract_skin_color(self, image: np.ndarray, fx, fy, fw, fh, face) -> np.ndarray:
        """Extract dominant skin color from cheek regions."""
        # Sample from mid-face (cheek area)
        cheek_y = fy + int(fh * 0.55)
        cheek_h = int(fh * 0.2)

        # Left cheek
        left_x = fx + int(fw * 0.15)
        left_w = int(fw * 0.2)

        # Right cheek
        right_x = fx + int(fw * 0.65)
        right_w = int(fw * 0.2)

        skin_pixels = []
        for region in [(left_x, cheek_y, left_w, cheek_h), (right_x, cheek_y, right_w, cheek_h)]:
            rx, ry, rw, rh = region
            roi = image[max(0, ry):ry + rh, max(0, rx):rx + rw]
            if roi.size > 0:
                skin_pixels.extend(roi.reshape(-1, 3).tolist())

        if not skin_pixels:
            return np.array([200, 170, 140])

        pixels = np.array(skin_pixels)
        kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
        kmeans.fit(pixels)

        labels, counts = np.unique(kmeans.labels_, return_counts=True)
        dominant_idx = labels[np.argmax(counts)]
        return kmeans.cluster_centers_[dominant_idx].astype(int)

    def _extract_hair_color(self, image: np.ndarray, fx, fy, fw, fh) -> np.ndarray:
        """Extract hair color from above the face."""
        hair_y = max(0, fy - int(fh * 0.3))
        hair_h = int(fh * 0.25)
        hair_x = fx + int(fw * 0.2)
        hair_w = int(fw * 0.6)

        region = image[hair_y:hair_y + hair_h, hair_x:hair_x + hair_w]
        if region.size == 0:
            return np.array([60, 40, 20])

        pixels = region.reshape(-1, 3)
        kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
        kmeans.fit(pixels)

        # Pick the darker cluster (more likely hair)
        centers = kmeans.cluster_centers_
        luminances = [0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2] for c in centers]
        hair_idx = np.argmin(luminances)
        return centers[hair_idx].astype(int)

    def _extract_eye_color(self, image: np.ndarray, face, w, h) -> np.ndarray:
        """Extract eye color from eye landmarks."""
        # Use right eye landmark from YuNet (index 4,5)
        eye_x, eye_y = int(face[4]), int(face[5])

        # Sample small region around eye
        region = image[max(0, eye_y - 5):eye_y + 5, max(0, eye_x - 5):eye_x + 5]
        if region.size == 0:
            return np.array([100, 80, 60])

        pixels = region.reshape(-1, 3)
        # Filter out very dark (pupil) and very bright (white)
        mask = (pixels.mean(axis=1) > 40) & (pixels.mean(axis=1) < 180)
        filtered = pixels[mask]

        if len(filtered) < 5:
            return np.array([100, 80, 60])

        kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
        kmeans.fit(filtered)

        # Pick the more saturated cluster (iris color)
        centers = kmeans.cluster_centers_
        saturations = []
        for c in centers:
            _, s, _ = colorsys.rgb_to_hsv(c[0] / 255, c[1] / 255, c[2] / 255)
            saturations.append(s)
        eye_idx = np.argmax(saturations)
        return centers[eye_idx].astype(int)

    def _determine_undertone(self, skin_color: np.ndarray) -> str:
        """Determine if skin has warm, cool, or neutral undertone."""
        r, g, b = skin_color
        h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        hue_degrees = h * 360

        if 15 <= hue_degrees <= 45:
            if r > b + 30:
                return "Warm"
            elif abs(r - b) < 15:
                return "Neutral"
            else:
                return "Cool"
        elif hue_degrees > 45 or hue_degrees < 15:
            if b > r - 10:
                return "Cool"
            else:
                return "Neutral"
        else:
            return "Neutral"

    def _determine_contrast(self, skin: np.ndarray, hair: np.ndarray, eye: np.ndarray) -> str:
        """Determine contrast level between skin, hair, and eyes."""
        skin_lum = 0.299 * skin[0] + 0.587 * skin[1] + 0.114 * skin[2]
        hair_lum = 0.299 * hair[0] + 0.587 * hair[1] + 0.114 * hair[2]
        eye_lum = 0.299 * eye[0] + 0.587 * eye[1] + 0.114 * eye[2]

        lums = [skin_lum, hair_lum, eye_lum]
        contrast_range = max(lums) - min(lums)

        if contrast_range > 120:
            return "High"
        elif contrast_range > 60:
            return "Medium"
        else:
            return "Low"

    def _classify_season(self, skin_color: np.ndarray, undertone: str, contrast: str) -> Tuple[str, str]:
        """Classify user into a seasonal color type."""
        skin_lum = 0.299 * skin_color[0] + 0.587 * skin_color[1] + 0.114 * skin_color[2]
        is_light = skin_lum > 160
        is_dark = skin_lum < 100

        if undertone == "Warm":
            if is_light:
                return ("Spring", "Clear Spring") if contrast == "High" else ("Spring", "Light Spring")
            elif is_dark:
                return "Autumn", "Deep Autumn"
            else:
                return ("Autumn", "Soft Autumn") if contrast == "Low" else ("Autumn", "Warm Autumn")
        elif undertone == "Cool":
            if is_light:
                return ("Winter", "Clear Winter") if contrast == "High" else ("Summer", "Light Summer")
            elif is_dark:
                return "Winter", "Deep Winter"
            else:
                return ("Winter", "Cool Winter") if contrast == "High" else ("Summer", "Cool Summer")
        else:
            if is_light:
                return "Summer", "Soft Summer"
            elif is_dark:
                return "Autumn", "Deep Autumn"
            else:
                return ("Winter", "Clear Winter") if contrast == "High" else ("Spring", "Warm Spring")

    def _rgb_to_hex(self, rgb: np.ndarray) -> str:
        return "#{:02x}{:02x}{:02x}".format(int(rgb[0]), int(rgb[1]), int(rgb[2]))

    def _get_color_name(self, rgb: np.ndarray) -> str:
        r, g, b = int(rgb[0]), int(rgb[1]), int(rgb[2])
        h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        h_deg = h * 360

        if v < 0.15:
            return "Black"
        elif s < 0.1 and v > 0.9:
            return "White"
        elif s < 0.15:
            return "Light Gray" if v > 0.7 else ("Gray" if v > 0.4 else "Dark Gray")

        if h_deg < 15 or h_deg >= 345:
            base = "Red"
        elif h_deg < 45:
            base = "Orange"
        elif h_deg < 70:
            base = "Yellow"
        elif h_deg < 150:
            base = "Green"
        elif h_deg < 210:
            base = "Cyan"
        elif h_deg < 270:
            base = "Blue"
        else:
            base = "Purple"

        if v < 0.4:
            return f"Dark {base}"
        elif s < 0.5:
            return f"Light {base}"
        return base

    def _format_colors(self, hex_list: List[str]) -> List[Dict]:
        result = []
        for hex_color in hex_list:
            r = int(hex_color[1:3], 16)
            g = int(hex_color[3:5], 16)
            b = int(hex_color[5:7], 16)
            name = self._get_color_name(np.array([r, g, b]))
            result.append({"hex": hex_color, "name": name, "rgb": [r, g, b]})
        return result

    def _generate_style_tips(self, season: str, sub_season: str, undertone: str, contrast: str) -> List[str]:
        tips = []
        season_tips = {
            "Spring": [
                "Opt for warm, clear colors that mirror the freshness of spring",
                "Gold jewelry complements your warm undertone beautifully",
                "Avoid heavy, dark colors that can overwhelm your natural brightness",
            ],
            "Summer": [
                "Soft, muted colors with blue undertones are your best friends",
                "Silver and rose gold jewelry enhance your cool coloring",
                "Avoid stark black — try charcoal or navy instead",
            ],
            "Autumn": [
                "Rich, earthy tones bring out the warmth in your coloring",
                "Gold and bronze accessories complement your undertone",
                "Avoid icy pastels and neon colors",
            ],
            "Winter": [
                "Bold, high-contrast colors make you shine",
                "Silver and platinum jewelry enhance your cool undertone",
                "You can wear black and white confidently",
            ],
        }
        tips.extend(season_tips.get(season, []))

        if contrast == "High":
            tips.append("High contrast patterns (like black & white stripes) suit you well")
        elif contrast == "Low":
            tips.append("Monochromatic or tone-on-tone outfits create an elegant look for you")
        else:
            tips.append("Medium contrast patterns with 2-3 colors work great on you")

        tips.append(f"As a {sub_season}, focus on colors that are "
                    f"{'bright and clear' if 'Clear' in sub_season else 'soft and muted' if 'Soft' in sub_season else 'deep and rich' if 'Deep' in sub_season else 'light and delicate' if 'Light' in sub_season else 'warm and golden' if 'Warm' in sub_season else 'cool and elegant'}")

        return tips
