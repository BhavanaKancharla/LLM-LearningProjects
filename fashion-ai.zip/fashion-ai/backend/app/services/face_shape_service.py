"""
Face Shape Analysis Service
Detects face shape (oval, round, square, heart, oblong, diamond)
by analyzing facial landmark proportions using MediaPipe Face Mesh.
"""

import cv2
import numpy as np
from typing import Dict, List, Tuple
import math
import os
import urllib.request


class FaceShapeService:
    """Classifies face shape using OpenCV face detection."""

    MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "models")
    FACE_MODEL = "face_detection_yunet_2023mar.onnx"
    FACE_MODEL_URL = "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx"


class FaceShapeService:
    """Classifies face shape from facial landmark measurements."""

    # Face shape characteristics
    FACE_SHAPES = {
        "Oval": {
            "description": "Balanced proportions, slightly longer than wide, gently rounded jawline",
            "characteristics": ["Forehead slightly wider than jaw", "Face length ~1.5x width", "Soft curves"],
        },
        "Round": {
            "description": "Equal width and length, full cheeks, rounded chin",
            "characteristics": ["Width ≈ Length", "Full cheekbones", "Rounded jawline and chin"],
        },
        "Square": {
            "description": "Strong angular jaw, forehead and jaw similar width",
            "characteristics": ["Prominent jawline", "Angular features", "Forehead ≈ Jaw width"],
        },
        "Heart": {
            "description": "Wider forehead, high cheekbones, narrow pointed chin",
            "characteristics": ["Wide forehead", "Narrow chin", "High cheekbones"],
        },
        "Oblong": {
            "description": "Significantly longer than wide, similar widths throughout",
            "characteristics": ["Face length > 1.6x width", "Uniform width", "Long straight cheeks"],
        },
        "Diamond": {
            "description": "Narrow forehead and jaw, widest at cheekbones",
            "characteristics": ["Narrow forehead", "Wide cheekbones", "Narrow jaw", "Angular"],
        },
    }

    def __init__(self):
        os.makedirs(self.MODEL_DIR, exist_ok=True)
        model_path = os.path.join(self.MODEL_DIR, self.FACE_MODEL)
        if not os.path.exists(model_path):
            urllib.request.urlretrieve(self.FACE_MODEL_URL, model_path)
        self.face_detector = cv2.FaceDetectorYN.create(model_path, "", (300, 300), 0.5, 0.3, 5000)

    def analyze(self, image_path: str) -> Dict:
        """Analyze face shape from an image using face bounding box proportions."""
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError("Could not read image file")

        h, w, _ = image.shape
        self.face_detector.setInputSize((w, h))
        _, faces = self.face_detector.detect(image)

        if faces is None or len(faces) == 0:
            raise ValueError("No face detected. Please upload a clear face photo.")

        face = faces[0]
        fx, fy, fw, fh = int(face[0]), int(face[1]), int(face[2]), int(face[3])

        # Use face bounding box ratio and landmark positions for classification
        measurements = {
            "forehead_width": round(fw * 0.85, 1),
            "cheekbone_width": round(float(fw), 1),
            "jaw_width": round(fw * 0.75, 1),
            "face_length": round(float(fh), 1),
            "jaw_angle": 140.0,
            "forehead_height": round(fh * 0.3, 1),
        }

        # Use landmarks if available (YuNet provides 5 landmarks)
        # Estimate jaw width from mouth landmarks
        if len(face) >= 14:
            mouth_r_x, mouth_l_x = face[10], face[12]
            jaw_estimate = abs(mouth_l_x - mouth_r_x) * 1.4
            measurements["jaw_width"] = round(float(jaw_estimate), 1)

        face_shape = self._classify_shape(measurements)
        proportions = self._get_proportions(measurements)

        return {
            "face_shape": face_shape,
            "description": self.FACE_SHAPES[face_shape]["description"],
            "characteristics": self.FACE_SHAPES[face_shape]["characteristics"],
            "measurements": measurements,
            "proportions": proportions,
            "confidence": 0.75,
        }

    def analyze(self, image_path: str) -> Dict:
        """
        Analyze face shape from an image.

        Returns face shape classification with measurements and proportions.
        """
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError("Could not read image file")

        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = self.face_mesh.process(image_rgb)

        if not results.multi_face_landmarks:
            raise ValueError("No face detected. Please upload a clear face photo.")

        landmarks = results.multi_face_landmarks[0]
        h, w, _ = image.shape

        # Extract key measurements
        measurements = self._get_measurements(landmarks, w, h)

        # Classify face shape
        face_shape = self._classify_shape(measurements)

        # Get proportions
        proportions = self._get_proportions(measurements)

        return {
            "face_shape": face_shape,
            "description": self.FACE_SHAPES[face_shape]["description"],
            "characteristics": self.FACE_SHAPES[face_shape]["characteristics"],
            "measurements": measurements,
            "proportions": proportions,
            "confidence": self._get_confidence(measurements, face_shape),
        }

    def _get_measurements(self, landmarks, w: int, h: int) -> Dict:
        """Extract facial measurements from landmarks."""
        lm = landmarks.landmark

        # Key landmark indices for face shape
        # Forehead width (temples)
        forehead_left = self._point(lm[54], w, h)
        forehead_right = self._point(lm[284], w, h)
        forehead_width = self._distance(forehead_left, forehead_right)

        # Cheekbone width (widest part)
        cheek_left = self._point(lm[234], w, h)
        cheek_right = self._point(lm[454], w, h)
        cheekbone_width = self._distance(cheek_left, cheek_right)

        # Jawline width
        jaw_left = self._point(lm[172], w, h)
        jaw_right = self._point(lm[397], w, h)
        jaw_width = self._distance(jaw_left, jaw_right)

        # Face length (forehead to chin)
        top = self._point(lm[10], w, h)
        bottom = self._point(lm[152], w, h)
        face_length = self._distance(top, bottom)

        # Jaw angle (sharpness)
        chin = self._point(lm[152], w, h)
        jaw_angle = self._calculate_jaw_angle(jaw_left, chin, jaw_right)

        # Forehead height
        forehead_top = self._point(lm[10], w, h)
        brow_center = self._point(lm[9], w, h)
        forehead_height = self._distance(forehead_top, brow_center)

        return {
            "forehead_width": round(forehead_width, 1),
            "cheekbone_width": round(cheekbone_width, 1),
            "jaw_width": round(jaw_width, 1),
            "face_length": round(face_length, 1),
            "jaw_angle": round(jaw_angle, 1),
            "forehead_height": round(forehead_height, 1),
        }

    def _classify_shape(self, measurements: Dict) -> str:
        """Classify face shape based on proportional measurements."""
        fw = measurements["forehead_width"]
        cw = measurements["cheekbone_width"]
        jw = measurements["jaw_width"]
        fl = measurements["face_length"]
        ja = measurements["jaw_angle"]

        # Calculate ratios
        length_to_width = fl / max(cw, 1)
        forehead_to_jaw = fw / max(jw, 1)
        cheek_to_jaw = cw / max(jw, 1)
        forehead_to_cheek = fw / max(cw, 1)

        # Classification logic
        scores = {
            "Oval": 0,
            "Round": 0,
            "Square": 0,
            "Heart": 0,
            "Oblong": 0,
            "Diamond": 0,
        }

        # Length-to-width ratio
        if 1.35 <= length_to_width <= 1.55:
            scores["Oval"] += 3
        elif length_to_width < 1.25:
            scores["Round"] += 3
        elif length_to_width > 1.6:
            scores["Oblong"] += 3
        elif 1.25 <= length_to_width <= 1.35:
            scores["Square"] += 2
            scores["Round"] += 1

        # Forehead vs jaw width
        if forehead_to_jaw > 1.2:
            scores["Heart"] += 3
        elif 0.9 <= forehead_to_jaw <= 1.1:
            scores["Square"] += 2
            scores["Oval"] += 1
        elif forehead_to_jaw < 0.85:
            scores["Diamond"] += 1

        # Cheekbone dominance
        if cheek_to_jaw > 1.3 and forehead_to_cheek < 0.9:
            scores["Diamond"] += 3
        elif cheek_to_jaw > 1.2:
            scores["Heart"] += 1
            scores["Diamond"] += 1

        # Jaw angle (angular vs round)
        if ja < 130:
            scores["Square"] += 2
        elif ja > 155:
            scores["Round"] += 2
            scores["Oval"] += 1
        else:
            scores["Oval"] += 2
            scores["Heart"] += 1

        # Width similarity (all widths close = round/oblong)
        width_variance = np.std([fw, cw, jw]) / np.mean([fw, cw, jw])
        if width_variance < 0.08:
            scores["Round"] += 2
            scores["Oblong"] += 2

        return max(scores, key=scores.get)

    def _get_proportions(self, measurements: Dict) -> Dict:
        """Calculate meaningful proportions."""
        cw = measurements["cheekbone_width"]
        fl = measurements["face_length"]

        return {
            "length_to_width_ratio": round(fl / max(cw, 1), 2),
            "forehead_to_jaw_ratio": round(
                measurements["forehead_width"] / max(measurements["jaw_width"], 1), 2
            ),
            "cheekbone_to_jaw_ratio": round(cw / max(measurements["jaw_width"], 1), 2),
            "forehead_to_cheekbone_ratio": round(
                measurements["forehead_width"] / max(cw, 1), 2
            ),
        }

    def _get_confidence(self, measurements: Dict, face_shape: str) -> float:
        """Estimate classification confidence."""
        # Simple heuristic based on how clearly the measurements match
        fl = measurements["face_length"]
        cw = measurements["cheekbone_width"]
        ratio = fl / max(cw, 1)

        if face_shape == "Oval" and 1.4 <= ratio <= 1.5:
            return 0.9
        elif face_shape == "Round" and ratio < 1.2:
            return 0.85
        elif face_shape == "Oblong" and ratio > 1.65:
            return 0.85
        elif face_shape == "Square" and measurements["jaw_angle"] < 125:
            return 0.85
        else:
            return 0.7

    def _point(self, landmark, w, h) -> Tuple[float, float]:
        return (landmark.x * w, landmark.y * h)

    def _distance(self, p1: Tuple, p2: Tuple) -> float:
        return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)

    def _calculate_jaw_angle(self, left: Tuple, chin: Tuple, right: Tuple) -> float:
        """Calculate angle at the chin between jaw points."""
        v1 = (left[0] - chin[0], left[1] - chin[1])
        v2 = (right[0] - chin[0], right[1] - chin[1])

        dot = v1[0] * v2[0] + v1[1] * v2[1]
        mag1 = math.sqrt(v1[0] ** 2 + v1[1] ** 2)
        mag2 = math.sqrt(v2[0] ** 2 + v2[1] ** 2)

        if mag1 * mag2 == 0:
            return 140

        cos_angle = max(-1, min(1, dot / (mag1 * mag2)))
        return math.degrees(math.acos(cos_angle))
