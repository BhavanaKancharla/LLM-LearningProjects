"""
Comprehensive Style Report Service
Generates a complete style report combining:
- Face shape analysis
- Body type analysis
- Color analysis
- Hairstyle recommendations
- Outfit suitability scoring
- Personalized fashion suggestions
"""

from typing import Dict, List, Optional


def _get_color_service():
    from app.services.color_analysis_service import ColorAnalysisService
    return ColorAnalysisService()

def _get_face_shape_service():
    try:
        from app.services.face_shape_service import FaceShapeService
        return FaceShapeService()
    except Exception:
        return None

def _get_body_type_service():
    try:
        from app.services.body_type_service import BodyTypeService
        return BodyTypeService()
    except Exception:
        return None

def _get_hairstyle_service():
    from app.services.hairstyle_service import HairstyleService
    return HairstyleService()


class StyleReportService:
    """Generates comprehensive, personalized style reports."""

    def __init__(self):
        pass

    def generate_full_report(self, face_image_path: str,
                              body_image_path: Optional[str] = None) -> Dict:
        report = {
            "overall_style_score": 0,
            "sections": {},
            "summary": "",
            "key_recommendations": [],
        }

        color_result = None
        face_result = None
        body_result = None
        hairstyle_result = None

        # 1. Color Analysis
        try:
            svc = _get_color_service()
            color_result = svc.analyze(face_image_path)
            report["sections"]["color_analysis"] = {"status": "success", "data": color_result}
        except Exception as e:
            report["sections"]["color_analysis"] = {"status": "error", "message": str(e)}

        # 2. Face Shape Analysis
        try:
            svc = _get_face_shape_service()
            if svc:
                face_result = svc.analyze(face_image_path)
                report["sections"]["face_shape"] = {"status": "success", "data": face_result}
            else:
                report["sections"]["face_shape"] = {"status": "skipped", "message": "Face shape service unavailable"}
        except Exception as e:
            report["sections"]["face_shape"] = {"status": "error", "message": str(e)}

        # 3. Hairstyle Recommendations
        if face_result and color_result:
            try:
                svc = _get_hairstyle_service()
                hairstyle_result = svc.get_recommendations(
                    face_shape=face_result.get("face_shape", "Oval"),
                    season=color_result.get("season"),
                    undertone=color_result.get("undertone"),
                    hair_color_hex=color_result.get("hair_color", {}).get("hex"),
                )
                report["sections"]["hairstyle"] = {"status": "success", "data": hairstyle_result}
            except Exception as e:
                report["sections"]["hairstyle"] = {"status": "error", "message": str(e)}
        else:
            report["sections"]["hairstyle"] = {"status": "skipped", "message": "Requires face/color analysis"}

        # 4. Body Type Analysis
        if body_image_path:
            try:
                svc = _get_body_type_service()
                if svc:
                    body_result = svc.analyze(body_image_path)
                    report["sections"]["body_type"] = {"status": "success", "data": body_result}
                else:
                    report["sections"]["body_type"] = {"status": "skipped", "message": "Body type service unavailable"}
            except Exception as e:
                report["sections"]["body_type"] = {"status": "error", "message": str(e)}
        else:
            report["sections"]["body_type"] = {"status": "skipped", "message": "No full-body photo provided"}

        # 5. Score & Summary
        report["overall_style_score"] = self._calculate_style_score(color_result, face_result, body_result)
        report["sections"]["outfit_guidelines"] = {
            "status": "success",
            "data": self._generate_outfit_guidelines(color_result, face_result, body_result),
        }
        report["summary"] = self._generate_summary(color_result, face_result, body_result, hairstyle_result)
        report["key_recommendations"] = self._generate_key_recommendations(color_result, face_result, body_result, hairstyle_result)

        return report

    def evaluate_outfit(self, user_color_profile: Dict, user_body_type: str,
                        outfit_color_hex: str, outfit_category: str) -> Dict:
        """
        Evaluate how well a specific outfit suits the user.

        Returns suitability score, color compatibility, and suggestions.
        """
        # Color compatibility
        color_score = self._evaluate_color_compatibility(
            user_color_profile, outfit_color_hex
        )

        # Body type suitability
        body_score = self._evaluate_body_suitability(
            user_body_type, outfit_category
        )

        # Overall outfit score
        overall_score = (color_score * 0.6) + (body_score * 0.4)

        # Generate specific feedback
        feedback = self._generate_outfit_feedback(
            user_color_profile, user_body_type, outfit_color_hex,
            outfit_category, color_score, body_score
        )

        return {
            "overall_score": round(overall_score * 100),
            "color_compatibility": round(color_score * 100),
            "body_suitability": round(body_score * 100),
            "verdict": self._get_verdict(overall_score),
            "feedback": feedback,
        }

    def _calculate_style_score(self, color_result, face_result, body_result) -> int:
        """Calculate an overall style analysis completeness score."""
        score = 0

        if color_result:
            score += 35
            if color_result.get("season"):
                score += 5
        if face_result:
            score += 25
            if face_result.get("confidence", 0) > 0.8:
                score += 5
        if body_result:
            score += 25
            if body_result.get("confidence", 0) > 0.8:
                score += 5

        return min(score, 100)

    def _generate_outfit_guidelines(self, color_result, face_result, body_result) -> Dict:
        """Generate outfit guidelines combining all analyses."""
        guidelines = {
            "necklines": [],
            "silhouettes": [],
            "patterns": [],
            "fabrics": [],
            "accessories": [],
            "colors_for_tops": [],
            "colors_for_bottoms": [],
        }

        # Body-type based necklines and silhouettes
        if body_result:
            bt = body_result["body_type"]
            neckline_map = {
                "Hourglass": ["V-neck", "Wrap", "Scoop neck", "Sweetheart"],
                "Pear": ["Boat neck", "Off-shoulder", "Square neck", "Wide V-neck"],
                "Apple": ["V-neck", "Wrap", "Empire waist", "Open collar"],
                "Rectangle": ["Scoop neck", "Off-shoulder", "Cowl neck", "Halter"],
                "Inverted Triangle": ["V-neck", "Deep scoop", "Halter", "Cowl neck"],
            }
            guidelines["necklines"] = neckline_map.get(bt, ["V-neck"])

            silhouette_map = {
                "Hourglass": ["Fitted", "Wrap", "Belted", "A-line"],
                "Pear": ["A-line", "Fit-and-flare", "Empire", "Full skirt"],
                "Apple": ["Empire waist", "A-line", "Wrap", "Shift dress"],
                "Rectangle": ["Peplum", "Belted", "Fit-and-flare", "Draped"],
                "Inverted Triangle": ["A-line", "Full skirt", "Wide-leg pants", "Soft drape"],
            }
            guidelines["silhouettes"] = silhouette_map.get(bt, ["A-line"])

        # Color-based clothing suggestions
        if color_result:
            season = color_result.get("season", "")
            undertone = color_result.get("undertone", "")
            contrast = color_result.get("contrast_level", "")

            # Pattern recommendations
            if contrast == "High":
                guidelines["patterns"] = ["Bold prints", "High-contrast stripes", "Geometric", "Color blocking"]
            elif contrast == "Low":
                guidelines["patterns"] = ["Tone-on-tone", "Subtle texture", "Monochromatic", "Watercolor prints"]
            else:
                guidelines["patterns"] = ["Medium-scale prints", "Paisley", "Floral", "Abstract"]

            # Fabric recommendations by season
            fabric_map = {
                "Spring": ["Cotton", "Linen", "Silk", "Light knits", "Chambray"],
                "Summer": ["Chiffon", "Soft knits", "Matte jersey", "Suede", "Lace"],
                "Autumn": ["Tweed", "Corduroy", "Leather", "Suede", "Heavy cotton"],
                "Winter": ["Satin", "Crisp cotton", "Wool crepe", "Patent leather", "Sequins"],
            }
            guidelines["fabrics"] = fabric_map.get(season, ["Cotton", "Linen"])

            # Accessory metals
            if undertone == "Warm":
                guidelines["accessories"] = ["Gold jewelry", "Bronze/copper", "Warm tortoiseshell", "Tan leather"]
            elif undertone == "Cool":
                guidelines["accessories"] = ["Silver jewelry", "Platinum", "Cool-toned metals", "Black leather"]
            else:
                guidelines["accessories"] = ["Rose gold", "Mixed metals", "Both gold and silver work"]

            # Top vs bottom color strategy
            rec_colors = color_result.get("recommended_colors", [])
            if len(rec_colors) >= 5:
                guidelines["colors_for_tops"] = [c["hex"] if isinstance(c, dict) else c for c in rec_colors[:5]]
                guidelines["colors_for_bottoms"] = ["#1C1C1C", "#000080", "#2F4F4F", "#36454F", "#FFFDD0"]

        return guidelines

    def _generate_summary(self, color_result, face_result, body_result, hairstyle_result) -> str:
        """Generate a human-readable style summary."""
        parts = []

        if color_result:
            parts.append(
                f"You are a **{color_result.get('sub_season', '')}** with a "
                f"**{color_result.get('undertone', '')}** undertone and "
                f"**{color_result.get('contrast_level', '')}** contrast."
            )

        if face_result:
            parts.append(
                f"Your **{face_result.get('face_shape', '')}** face shape "
                f"is complemented by styles that "
                f"{self._get_shape_advice_brief(face_result.get('face_shape', ''))}."
            )

        if body_result:
            parts.append(
                f"With an **{body_result.get('body_type', '')}** body type, "
                f"focus on {self._get_body_advice_brief(body_result.get('body_type', ''))}."
            )

        if not parts:
            return "Upload your photos to receive a personalized style analysis."

        return " ".join(parts)

    def _generate_key_recommendations(self, color_result, face_result,
                                       body_result, hairstyle_result) -> List[str]:
        """Generate top 5 key actionable recommendations."""
        recs = []

        if color_result:
            season = color_result.get("season", "")
            recs.append(f"Build your wardrobe around your {season} palette — these colors will always make you look vibrant")

        if face_result:
            shape = face_result.get("face_shape", "")
            if shape == "Round":
                recs.append("Choose V-necklines and angular accessories to add structure")
            elif shape == "Square":
                recs.append("Soft, rounded necklines and flowing fabrics will complement your strong features")
            elif shape == "Heart":
                recs.append("Balance your look with V-necks or scoop necks that mirror your chin shape")
            else:
                recs.append("Your face shape is versatile — experiment with different neckline styles")

        if body_result:
            bt = body_result.get("body_type", "")
            if bt == "Pear":
                recs.append("Draw attention upward with statement tops, keep bottoms sleek and dark")
            elif bt == "Apple":
                recs.append("Empire waists and A-line shapes will be your most flattering silhouettes")
            elif bt == "Hourglass":
                recs.append("Always define your waist — belts, wraps, and fitted styles showcase your proportions")
            elif bt == "Rectangle":
                recs.append("Create curves with peplums, belts, and layered outfits")
            elif bt == "Inverted Triangle":
                recs.append("Balance shoulders with full skirts, wide-leg pants, and hip-volume styles")

        if hairstyle_result:
            top_style = hairstyle_result.get("recommended_styles", [{}])[0]
            if top_style:
                recs.append(f"Try a '{top_style.get('name', '')}' hairstyle — it's ideal for your face shape")

        if color_result and color_result.get("undertone") == "Warm":
            recs.append("Stick to gold jewelry and warm-toned accessories for a cohesive look")
        elif color_result and color_result.get("undertone") == "Cool":
            recs.append("Silver and platinum accessories will always complement your cool coloring")

        return recs[:6]

    def _evaluate_color_compatibility(self, color_profile: Dict, outfit_hex: str) -> float:
        """Score how well an outfit color matches user's palette."""
        recommended = color_profile.get("recommended_colors", [])
        avoid = color_profile.get("avoid_colors", [])

        if not outfit_hex:
            return 0.5

        # Check if it's in avoid list
        for color in avoid:
            c = color if isinstance(color, str) else color.get("hex", "")
            if self._color_distance_quick(outfit_hex, c) < 30:
                return 0.2

        # Check proximity to recommended colors
        best_match = 0
        for color in recommended:
            c = color if isinstance(color, str) else color.get("hex", "")
            distance = self._color_distance_quick(outfit_hex, c)
            match = max(0, 1 - (distance / 150))
            best_match = max(best_match, match)

        return best_match

    def _evaluate_body_suitability(self, body_type: str, category: str) -> float:
        """Score how well a clothing category suits the body type."""
        # Simplified suitability matrix
        suitability = {
            "Hourglass": {"tops": 0.85, "bottoms": 0.85, "dresses": 0.95, "accessories": 0.8},
            "Pear": {"tops": 0.9, "bottoms": 0.7, "dresses": 0.85, "accessories": 0.8},
            "Apple": {"tops": 0.75, "bottoms": 0.85, "dresses": 0.8, "accessories": 0.8},
            "Rectangle": {"tops": 0.8, "bottoms": 0.8, "dresses": 0.85, "accessories": 0.85},
            "Inverted Triangle": {"tops": 0.75, "bottoms": 0.9, "dresses": 0.8, "accessories": 0.8},
        }

        return suitability.get(body_type, {}).get(category, 0.75)

    def _generate_outfit_feedback(self, color_profile, body_type, outfit_hex,
                                   category, color_score, body_score) -> List[str]:
        """Generate specific outfit feedback."""
        feedback = []

        if color_score > 0.8:
            feedback.append("✓ Excellent color match for your palette!")
        elif color_score > 0.5:
            feedback.append("○ Good color choice, works with your palette")
        else:
            feedback.append("✗ This color may not be your most flattering — consider alternatives from your recommended palette")

        if body_score > 0.85:
            feedback.append(f"✓ Great {category} choice for your {body_type} body type")
        elif body_score > 0.7:
            feedback.append(f"○ This {category} works for your shape, but check fit carefully")
        else:
            feedback.append(f"✗ Consider a different style of {category} that's more flattering for {body_type} shapes")

        return feedback

    def _color_distance_quick(self, hex1: str, hex2: str) -> float:
        """Quick RGB color distance."""
        try:
            r1, g1, b1 = int(hex1[1:3], 16), int(hex1[3:5], 16), int(hex1[5:7], 16)
            r2, g2, b2 = int(hex2[1:3], 16), int(hex2[3:5], 16), int(hex2[5:7], 16)
            return ((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2) ** 0.5
        except (ValueError, IndexError):
            return 100

    def _get_verdict(self, score: float) -> str:
        if score >= 0.8:
            return "Excellent Match"
        elif score >= 0.6:
            return "Good Choice"
        elif score >= 0.4:
            return "Moderate Fit"
        else:
            return "Consider Alternatives"

    def _get_shape_advice_brief(self, face_shape: str) -> str:
        advice = {
            "Oval": "work with almost any style",
            "Round": "add angles and length",
            "Square": "soften with curves and waves",
            "Heart": "balance width at the chin",
            "Oblong": "add width and break up length",
            "Diamond": "add volume at forehead and chin",
        }
        return advice.get(face_shape, "suit your features")

    def _get_body_advice_brief(self, body_type: str) -> str:
        advice = {
            "Hourglass": "defining your waist and following your natural curves",
            "Pear": "broadening the shoulder line and keeping lower body sleek",
            "Apple": "elongating the torso with V-lines and empire waists",
            "Rectangle": "creating the illusion of curves with structure and layers",
            "Inverted Triangle": "adding volume below the waist to balance shoulders",
        }
        return advice.get(body_type, "flattering your proportions")
