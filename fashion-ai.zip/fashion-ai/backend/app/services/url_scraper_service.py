"""
URL Scraper Service
Extracts clothing item images and metadata from shopping website URLs.
Supports common e-commerce patterns and OG meta tags.
"""

import requests
from bs4 import BeautifulSoup
from typing import Dict, Optional
from urllib.parse import urlparse
import re
import os
import uuid


class URLScraperService:
    """Extracts clothing product data from shopping URLs."""

    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
    }

    def extract_from_url(self, url: str) -> Dict:
        """
        Extract product information from a shopping URL.

        Attempts to extract:
        - Product image
        - Product name/title
        - Price (if available)
        - Description
        - Color information

        Returns dictionary with extracted data.
        """
        # Validate URL
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            raise ValueError("Invalid URL. Please provide a complete URL (https://...)")

        try:
            response = requests.get(url, headers=self.HEADERS, timeout=15)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Could not access URL: {str(e)}")

        soup = BeautifulSoup(response.text, "lxml")

        # Extract product data using multiple strategies
        product_data = {
            "url": url,
            "domain": parsed.netloc,
            "title": self._extract_title(soup),
            "description": self._extract_description(soup),
            "image_url": self._extract_image(soup, url),
            "price": self._extract_price(soup),
            "color": self._extract_color(soup),
        }

        # Download the product image
        if product_data["image_url"]:
            local_path = self._download_image(product_data["image_url"])
            product_data["local_image_path"] = local_path

        return product_data

    def _extract_title(self, soup: BeautifulSoup) -> str:
        """Extract product title."""
        # Try OG title first
        og_title = soup.find("meta", property="og:title")
        if og_title and og_title.get("content"):
            return og_title["content"].strip()

        # Try common product title selectors
        title_selectors = [
            "h1.product-title",
            "h1.product-name",
            "h1[data-testid='product-title']",
            "h1.pdp-title",
            ".product-title h1",
            "#productTitle",
            "h1",
        ]
        for selector in title_selectors:
            el = soup.select_one(selector)
            if el and el.get_text(strip=True):
                return el.get_text(strip=True)[:200]

        # Fallback to page title
        title_tag = soup.find("title")
        if title_tag:
            return title_tag.get_text(strip=True)[:200]

        return "Unknown Product"

    def _extract_description(self, soup: BeautifulSoup) -> str:
        """Extract product description."""
        # OG description
        og_desc = soup.find("meta", property="og:description")
        if og_desc and og_desc.get("content"):
            return og_desc["content"].strip()[:500]

        # Meta description
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc and meta_desc.get("content"):
            return meta_desc["content"].strip()[:500]

        # Common description selectors
        desc_selectors = [
            ".product-description",
            "#product-description",
            "[data-testid='product-description']",
            ".pdp-description",
        ]
        for selector in desc_selectors:
            el = soup.select_one(selector)
            if el:
                return el.get_text(strip=True)[:500]

        return ""

    def _extract_image(self, soup: BeautifulSoup, base_url: str) -> Optional[str]:
        """Extract main product image URL."""
        # OG image (most reliable)
        og_image = soup.find("meta", property="og:image")
        if og_image and og_image.get("content"):
            return self._normalize_url(og_image["content"], base_url)

        # Twitter card image
        twitter_img = soup.find("meta", attrs={"name": "twitter:image"})
        if twitter_img and twitter_img.get("content"):
            return self._normalize_url(twitter_img["content"], base_url)

        # Common image selectors
        img_selectors = [
            ".product-image img",
            ".pdp-image img",
            "#product-image img",
            "[data-testid='product-image'] img",
            ".gallery-image img",
            ".main-image img",
            "img.product-img",
        ]
        for selector in img_selectors:
            el = soup.select_one(selector)
            if el:
                src = el.get("src") or el.get("data-src") or el.get("data-lazy-src")
                if src:
                    return self._normalize_url(src, base_url)

        # Fallback: first large image
        for img in soup.find_all("img"):
            src = img.get("src", "")
            if any(keyword in src.lower() for keyword in ["product", "item", "pdp", "main"]):
                return self._normalize_url(src, base_url)

        return None

    def _extract_price(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract product price."""
        # Schema.org price
        price_meta = soup.find("meta", attrs={"itemprop": "price"})
        if price_meta and price_meta.get("content"):
            return price_meta["content"]

        # OG price
        og_price = soup.find("meta", property="product:price:amount")
        if og_price and og_price.get("content"):
            return og_price["content"]

        # Common price selectors
        price_selectors = [
            ".product-price",
            ".price",
            "[data-testid='product-price']",
            ".pdp-price",
            "#product-price",
            "span.price",
        ]
        for selector in price_selectors:
            el = soup.select_one(selector)
            if el:
                text = el.get_text(strip=True)
                # Extract price with regex
                match = re.search(r'[\$£€₹]\s*[\d,]+\.?\d*', text)
                if match:
                    return match.group()

        return None

    def _extract_color(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract product color information."""
        # Common color selectors
        color_selectors = [
            ".selected-color",
            ".product-color",
            "[data-testid='selected-color']",
            ".color-name",
            "span.color",
        ]
        for selector in color_selectors:
            el = soup.select_one(selector)
            if el:
                return el.get_text(strip=True)

        # Look for color in text
        page_text = soup.get_text()
        color_patterns = [
            r"Color[:\s]+([A-Za-z\s]+)",
            r"Colour[:\s]+([A-Za-z\s]+)",
        ]
        for pattern in color_patterns:
            match = re.search(pattern, page_text)
            if match:
                return match.group(1).strip()[:50]

        return None

    def _normalize_url(self, url: str, base_url: str) -> str:
        """Normalize a potentially relative URL."""
        if url.startswith("//"):
            return "https:" + url
        elif url.startswith("/"):
            parsed = urlparse(base_url)
            return f"{parsed.scheme}://{parsed.netloc}{url}"
        elif not url.startswith("http"):
            return base_url.rstrip("/") + "/" + url
        return url

    def _download_image(self, image_url: str) -> Optional[str]:
        """Download product image to local uploads directory."""
        try:
            response = requests.get(image_url, headers=self.HEADERS, timeout=15, stream=True)
            response.raise_for_status()

            # Determine extension from content-type
            content_type = response.headers.get("content-type", "")
            if "png" in content_type:
                ext = "png"
            elif "webp" in content_type:
                ext = "webp"
            else:
                ext = "jpg"

            filename = f"scraped_{uuid.uuid4().hex[:8]}.{ext}"
            filepath = os.path.join("uploads", filename)

            with open(filepath, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            return filepath

        except Exception:
            return None
