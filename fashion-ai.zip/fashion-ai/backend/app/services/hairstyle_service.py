"""
Hairstyle Recommendation Service
Recommends hairstyles based on face shape, facial features,
hair type, and color season analysis.
"""

from typing import Dict, List


class HairstyleService:
    """Recommends hairstyles personalized to the user's facial features."""

    # Hairstyle recommendations by face shape
    HAIRSTYLE_DATABASE = {
        "Oval": {
            "description": "Most versatile face shape — almost any hairstyle works!",
            "recommended": [
                {
                    "name": "Long Layers",
                    "description": "Face-framing layers that enhance your balanced proportions",
                    "length": "Long",
                    "suitability": 0.95,
                },
                {
                    "name": "Bob with Side Part",
                    "description": "Classic bob that highlights your symmetrical features",
                    "length": "Medium",
                    "suitability": 0.92,
                },
                {
                    "name": "Pixie Cut",
                    "description": "Short and chic, showcases your balanced face shape",
                    "length": "Short",
                    "suitability": 0.88,
                },
                {
                    "name": "Soft Waves",
                    "description": "Romantic waves that add movement and dimension",
                    "length": "Medium-Long",
                    "suitability": 0.93,
                },
                {
                    "name": "Curtain Bangs",
                    "description": "Trendy face-framing bangs that enhance your bone structure",
                    "length": "Any",
                    "suitability": 0.90,
                },
                {
                    "name": "Sleek Ponytail",
                    "description": "Pulled back style that shows off your balanced proportions",
                    "length": "Long",
                    "suitability": 0.87,
                },
            ],
            "avoid": [
                "Extremely voluminous styles that overwhelm your features",
                "Very heavy, blunt bangs that hide your forehead",
            ],
            "styling_tips": [
                "You have the most versatile face shape — experiment freely!",
                "Both center and side parts work well for you",
                "You can pull off both sleek and voluminous styles",
            ],
        },
        "Round": {
            "description": "Add height and angles to elongate and slim the face",
            "recommended": [
                {
                    "name": "Long Layered Cut",
                    "description": "Layers below the chin create length and slimming effect",
                    "length": "Long",
                    "suitability": 0.94,
                },
                {
                    "name": "Side-Swept Bangs",
                    "description": "Angled bangs add asymmetry and length to the face",
                    "length": "Any",
                    "suitability": 0.91,
                },
                {
                    "name": "Lob (Long Bob)",
                    "description": "Below-chin length with layers to elongate",
                    "length": "Medium",
                    "suitability": 0.90,
                },
                {
                    "name": "Volume at Crown",
                    "description": "Height on top creates the illusion of a longer face",
                    "length": "Medium-Long",
                    "suitability": 0.89,
                },
                {
                    "name": "Deep Side Part",
                    "description": "Creates asymmetry that counteracts roundness",
                    "length": "Any",
                    "suitability": 0.88,
                },
                {
                    "name": "Textured Shag",
                    "description": "Layered shag with movement that adds angles",
                    "length": "Medium",
                    "suitability": 0.87,
                },
            ],
            "avoid": [
                "Chin-length bobs that emphasize width",
                "Center parts with no volume",
                "Very curly short styles that add width",
                "Round-shaped bobs",
            ],
            "styling_tips": [
                "Add height at the crown to elongate your face",
                "Keep sides sleek to avoid adding width",
                "Layers below the chin are most flattering",
                "Asymmetric styles work great for you",
            ],
        },
        "Square": {
            "description": "Soften angular features with waves, layers, and texture",
            "recommended": [
                {
                    "name": "Soft Waves",
                    "description": "Waves soften your strong jawline beautifully",
                    "length": "Medium-Long",
                    "suitability": 0.94,
                },
                {
                    "name": "Side-Swept Long Layers",
                    "description": "Layers that fall around the jaw soften angles",
                    "length": "Long",
                    "suitability": 0.92,
                },
                {
                    "name": "Textured Lob",
                    "description": "Below-jaw length with texture reduces angularity",
                    "length": "Medium",
                    "suitability": 0.90,
                },
                {
                    "name": "Wispy Bangs",
                    "description": "Soft, wispy fringe softens the strong forehead",
                    "length": "Any",
                    "suitability": 0.88,
                },
                {
                    "name": "Off-Center Part",
                    "description": "Breaks up symmetry and softens square features",
                    "length": "Any",
                    "suitability": 0.87,
                },
                {
                    "name": "Messy Updo",
                    "description": "Loose, romantic updos with face-framing tendrils",
                    "length": "Long",
                    "suitability": 0.85,
                },
            ],
            "avoid": [
                "Blunt, straight-across cuts at the jaw",
                "Very short crops that expose jawline",
                "Geometric, angular cuts",
                "Slicked back styles that show all angles",
            ],
            "styling_tips": [
                "Waves and curls are your best friends — they soften angles",
                "Keep length below the jaw for the most flattering look",
                "Side parts work better than center parts",
                "Face-framing layers around the jaw are key",
            ],
        },
        "Heart": {
            "description": "Balance a wider forehead with volume at the chin/jaw area",
            "recommended": [
                {
                    "name": "Chin-Length Bob",
                    "description": "Adds width at the jaw to balance the forehead",
                    "length": "Medium",
                    "suitability": 0.94,
                },
                {
                    "name": "Side-Swept Bangs",
                    "description": "Minimizes forehead width with an angled fringe",
                    "length": "Any",
                    "suitability": 0.92,
                },
                {
                    "name": "Long with Volume at Ends",
                    "description": "Flipped or curled ends add width at the narrow chin",
                    "length": "Long",
                    "suitability": 0.91,
                },
                {
                    "name": "Curtain Bangs",
                    "description": "Frame the forehead and cheekbones beautifully",
                    "length": "Any",
                    "suitability": 0.90,
                },
                {
                    "name": "Layered Mid-Length",
                    "description": "Layers starting at the cheekbone add balance",
                    "length": "Medium",
                    "suitability": 0.88,
                },
                {
                    "name": "Textured Pixie",
                    "description": "Short with volume on top and wispy sides",
                    "length": "Short",
                    "suitability": 0.82,
                },
            ],
            "avoid": [
                "Styles with volume at the temples/forehead",
                "Slicked-back styles that expose the wide forehead",
                "Very short styles with no bangs",
                "High ponytails that emphasize forehead width",
            ],
            "styling_tips": [
                "Bangs are your friend — they balance the forehead",
                "Add volume and width around the chin area",
                "Keep the top relatively flat, volume at the bottom",
                "Chin-length styles are particularly flattering",
            ],
        },
        "Oblong": {
            "description": "Add width and reduce apparent length with layers and bangs",
            "recommended": [
                {
                    "name": "Blunt Bob",
                    "description": "Horizontal line adds width and breaks up length",
                    "length": "Medium",
                    "suitability": 0.93,
                },
                {
                    "name": "Full Bangs",
                    "description": "Shortens the appearance of face length",
                    "length": "Any",
                    "suitability": 0.92,
                },
                {
                    "name": "Waves and Curls",
                    "description": "Volume at the sides adds width to balance length",
                    "length": "Medium",
                    "suitability": 0.91,
                },
                {
                    "name": "Layered with Side Volume",
                    "description": "Layers that add fullness at cheekbone level",
                    "length": "Medium-Long",
                    "suitability": 0.89,
                },
                {
                    "name": "Chin-Length with Volume",
                    "description": "Adds horizontal emphasis to counter vertical length",
                    "length": "Medium",
                    "suitability": 0.88,
                },
                {
                    "name": "Side Part with Volume",
                    "description": "Creates width asymmetrically",
                    "length": "Any",
                    "suitability": 0.86,
                },
            ],
            "avoid": [
                "Very long, straight hair with no layers",
                "Styles that add height on top",
                "Center parts with flat sides",
                "Extra long face-framing layers",
            ],
            "styling_tips": [
                "Bangs are great for reducing apparent face length",
                "Add volume at the sides, not on top",
                "Shoulder-length cuts are ideal",
                "Waves and curls add the width you want",
            ],
        },
        "Diamond": {
            "description": "Balance narrow forehead/chin with volume at those areas",
            "recommended": [
                {
                    "name": "Side-Swept Bangs",
                    "description": "Adds width to the narrow forehead area",
                    "length": "Any",
                    "suitability": 0.93,
                },
                {
                    "name": "Chin-Length Layers",
                    "description": "Volume at chin balances narrow jaw",
                    "length": "Medium",
                    "suitability": 0.91,
                },
                {
                    "name": "Tucked Behind Ears",
                    "description": "Minimizes cheekbone width, shows jawline",
                    "length": "Medium-Long",
                    "suitability": 0.88,
                },
                {
                    "name": "Volume at Forehead",
                    "description": "Adds fullness where the face is narrow",
                    "length": "Any",
                    "suitability": 0.87,
                },
                {
                    "name": "Textured Long Layers",
                    "description": "Movement and texture throughout for balance",
                    "length": "Long",
                    "suitability": 0.86,
                },
                {
                    "name": "Half-Up Style",
                    "description": "Shows forehead while framing cheekbones",
                    "length": "Long",
                    "suitability": 0.84,
                },
            ],
            "avoid": [
                "Styles that add width at cheekbones",
                "Slicked back with no volume",
                "Very wide, voluminous middle sections",
                "Flat tops with wide sides",
            ],
            "styling_tips": [
                "Add volume at forehead and chin, keep sides sleeker",
                "Bangs help widen the narrow forehead",
                "Chin-length pieces add balance at the jaw",
                "Avoid extreme width at cheekbone level",
            ],
        },
    }

    def get_recommendations(self, face_shape: str, season: str = None,
                            undertone: str = None, hair_color_hex: str = None) -> Dict:
        """
        Get personalized hairstyle recommendations.

        Args:
            face_shape: Detected face shape
            season: User's color season (optional, for color suggestions)
            undertone: User's undertone (optional)
            hair_color_hex: Current hair color (optional)

        Returns:
            Complete hairstyle recommendation with styles, tips, and color advice
        """
        if face_shape not in self.HAIRSTYLE_DATABASE:
            face_shape = "Oval"  # Default fallback

        shape_data = self.HAIRSTYLE_DATABASE[face_shape]

        # Get hair color recommendations based on season
        color_recommendations = self._get_hair_color_suggestions(
            season, undertone, hair_color_hex
        )

        return {
            "face_shape": face_shape,
            "description": shape_data["description"],
            "recommended_styles": shape_data["recommended"],
            "styles_to_avoid": shape_data["avoid"],
            "styling_tips": shape_data["styling_tips"],
            "hair_color_suggestions": color_recommendations,
            "total_recommendations": len(shape_data["recommended"]),
        }

    def _get_hair_color_suggestions(self, season: str, undertone: str,
                                     current_color: str) -> List[Dict]:
        """Suggest flattering hair colors based on color season."""
        suggestions = []

        season_colors = {
            "Spring": [
                {"color": "Golden Blonde", "hex": "#DAA520", "reason": "Enhances warm undertone with sun-kissed warmth"},
                {"color": "Strawberry Blonde", "hex": "#CC7722", "reason": "Warm copper tones complement spring coloring"},
                {"color": "Honey Brown", "hex": "#A0522D", "reason": "Rich, warm brown flatters your natural warmth"},
                {"color": "Caramel Highlights", "hex": "#FFD700", "reason": "Golden highlights brighten your complexion"},
            ],
            "Summer": [
                {"color": "Ash Blonde", "hex": "#C0B283", "reason": "Cool-toned blonde suits your cool undertone"},
                {"color": "Mushroom Brown", "hex": "#8B7D6B", "reason": "Soft neutral-cool brown enhances your coloring"},
                {"color": "Rose Gold", "hex": "#B76E79", "reason": "Soft pink tones complement summer palettes"},
                {"color": "Platinum Blonde", "hex": "#E5E4E2", "reason": "Cool and icy, mirrors your cool undertone"},
            ],
            "Autumn": [
                {"color": "Auburn", "hex": "#A52A2A", "reason": "Rich red-brown enhances warm, deep coloring"},
                {"color": "Copper", "hex": "#B87333", "reason": "Vibrant copper makes autumn features glow"},
                {"color": "Dark Chocolate", "hex": "#3C1414", "reason": "Deep warm brown enriches your palette"},
                {"color": "Chestnut", "hex": "#954535", "reason": "Warm, rich tone with red undertones suits you"},
            ],
            "Winter": [
                {"color": "Blue-Black", "hex": "#0D0D2B", "reason": "Cool, dramatic black suits high-contrast winter"},
                {"color": "Espresso", "hex": "#3C2415", "reason": "Cool dark brown with no warm tones"},
                {"color": "Burgundy", "hex": "#800020", "reason": "Cool-toned red adds drama to winter coloring"},
                {"color": "Icy Blonde", "hex": "#FFFAFA", "reason": "Stark, cool blonde for high-contrast winters"},
            ],
        }

        if season and season in season_colors:
            suggestions = season_colors[season]
        else:
            # Generic suggestions
            suggestions = [
                {"color": "Natural Enhancement", "hex": "#8B7355", "reason": "Stay close to your natural shade for low maintenance"},
                {"color": "Subtle Highlights", "hex": "#D4A76A", "reason": "Face-framing highlights brighten any complexion"},
            ]

        return suggestions
