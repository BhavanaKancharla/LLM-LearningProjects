"""
Body Type Analysis Service
Detects body type/shape (apple, pear, hourglass, rectangle, inverted triangle)
by analyzing body proportions using MediaPipe Pose landmarks.
"""

import cv2
import numpy as np
import mediapipe.solutions.pose as mp_pose_module
from typing import Dict, List, Tuple
import math


class BodyTypeService:
    """Classifies body type from pose landmark measurements."""

    BODY_TYPES = {
        "Hourglass": {
            "description": "Balanced shoulders and hips with a defined waist",
            "characteristics": [
                "Shoulders ≈ Hips width",
                "Clearly defined waist",
                "Waist significantly narrower than shoulders/hips",
            ],
            "best_styles": [
                "Wrap dresses and tops",
                "Belted coats and jackets",
                "High-waisted bottoms",
                "Fitted silhouettes that follow your curves",
                "V-necklines and scoop necks",
            ],
            "avoid": [
                "Boxy, shapeless clothing",
                "Empire waist dresses",
                "Overly loose tops",
            ],
        },
        "Pear": {
            "description": "Hips wider than shoulders, defined waist",
            "characteristics": [
                "Shoulders narrower than hips",
                "Fuller hips and thighs",
                "Defined waistline",
            ],
            "best_styles": [
                "A-line skirts and dresses",
                "Boat neck and off-shoulder tops",
                "Statement necklaces to draw eye up",
                "Structured shoulders",
                "Dark-colored bottoms with lighter tops",
            ],
            "avoid": [
                "Skinny jeans without tunic top",
                "Pleated or gathered skirts at hip",
                "Ankle straps that shorten legs",
            ],
        },
        "Apple": {
            "description": "Wider midsection, shoulders and hips similar width",
            "characteristics": [
                "Fuller midsection",
                "Less defined waistline",
                "Often slimmer legs",
            ],
            "best_styles": [
                "Empire waist dresses",
                "V-neck tops that elongate torso",
                "A-line and wrap dresses",
                "Structured jackets",
                "Bootcut or straight-leg pants",
            ],
            "avoid": [
                "Tight-fitting tops around midsection",
                "Clingy fabrics",
                "Wide belts at natural waist",
            ],
        },
        "Rectangle": {
            "description": "Shoulders, waist, and hips similar width, athletic build",
            "characteristics": [
                "Uniform width throughout torso",
                "Less defined waistline",
                "Straight silhouette",
            ],
            "best_styles": [
                "Peplum tops to create waist definition",
                "Belted dresses and coats",
                "Layered outfits",
                "Ruffles and volume at bust or hips",
                "Off-shoulder necklines",
            ],
            "avoid": [
                "Boxy, straight-cut clothes",
                "Shapeless shift dresses",
                "Overly baggy clothing",
            ],
        },
        "Inverted Triangle": {
            "description": "Broader shoulders, narrower hips",
            "characteristics": [
                "Shoulders wider than hips",
                "Athletic upper body",
                "Narrower hip area",
            ],
            "best_styles": [
                "V-neck and scoop necks to soften shoulders",
                "A-line skirts to add hip volume",
                "Wide-leg pants",
                "Patterned/lighter colored bottoms",
                "Raglan sleeves",
            ],
            "avoid": [
                "Shoulder pads",
                "Boat necks and strapless tops",
                "Heavy embellishments on shoulders",
            ],
        },
    }

    def __init__(self):
        self.mp_pose = mp_pose_module
        self.pose = mp_pose_module.Pose(
            static_image_mode=True,
            model_complexity=2,
            min_detection_confidence=0.5,
        )

    def analyze(self, image_path: str) -> Dict:
        """
        Analyze body type from a full-body image.

        Returns body type classification with measurements, proportions, and style advice.
        """
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError("Could not read image file")

        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = self.pose.process(image_rgb)

        if not results.pose_landmarks:
            raise ValueError("Could not detect body pose. Please upload a clear full-body photo.")

        landmarks = results.pose_landmarks.landmark
        h, w, _ = image.shape

        # Extract measurements
        measurements = self._get_measurements(landmarks, w, h)

        # Classify body type
        body_type = self._classify_body_type(measurements)

        # Get proportions
        proportions = self._get_proportions(measurements)

        body_info = self.BODY_TYPES[body_type]

        return {
            "body_type": body_type,
            "description": body_info["description"],
            "characteristics": body_info["characteristics"],
            "best_styles": body_info["best_styles"],
            "avoid_styles": body_info["avoid"],
            "measurements": measurements,
            "proportions": proportions,
            "confidence": self._get_confidence(measurements, body_type),
        }

    def _get_measurements(self, landmarks, w: int, h: int) -> Dict:
        """Extract body measurements from pose landmarks."""
        lm = landmarks

        # Shoulder width
        l_shoulder = self._point(lm[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value], w, h)
        r_shoulder = self._point(lm[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value], w, h)
        shoulder_width = self._distance(l_shoulder, r_shoulder)

        # Hip width
        l_hip = self._point(lm[self.mp_pose.PoseLandmark.LEFT_HIP.value], w, h)
        r_hip = self._point(lm[self.mp_pose.PoseLandmark.RIGHT_HIP.value], w, h)
        hip_width = self._distance(l_hip, r_hip)

        # Estimate waist (midpoint between shoulders and hips, slightly inward)
        waist_y = (l_shoulder[1] + l_hip[1]) / 2
        # Approximate waist as narrower than the wider of shoulders/hips
        waist_width = min(shoulder_width, hip_width) * 0.85

        # Torso length
        shoulder_mid_y = (l_shoulder[1] + r_shoulder[1]) / 2
        hip_mid_y = (l_hip[1] + r_hip[1]) / 2
        torso_length = abs(hip_mid_y - shoulder_mid_y)

        # Leg length
        l_ankle = self._point(lm[self.mp_pose.PoseLandmark.LEFT_ANKLE.value], w, h)
        r_ankle = self._point(lm[self.mp_pose.PoseLandmark.RIGHT_ANKLE.value], w, h)
        ankle_mid_y = (l_ankle[1] + r_ankle[1]) / 2
        leg_length = abs(ankle_mid_y - hip_mid_y)

        # Total height estimate
        head_top = self._point(lm[self.mp_pose.PoseLandmark.NOSE.value], w, h)
        total_height = abs(ankle_mid_y - head_top[1]) + (shoulder_mid_y - head_top[1]) * 0.5

        return {
            "shoulder_width": round(shoulder_width, 1),
            "hip_width": round(hip_width, 1),
            "waist_width_estimate": round(waist_width, 1),
            "torso_length": round(torso_length, 1),
            "leg_length": round(leg_length, 1),
            "total_height_estimate": round(total_height, 1),
        }

    def _classify_body_type(self, measurements: Dict) -> str:
        """Classify body type based on proportions."""
        sw = measurements["shoulder_width"]
        hw = measurements["hip_width"]
        ww = measurements["waist_width_estimate"]

        # Ratios
        shoulder_to_hip = sw / max(hw, 1)
        waist_to_shoulder = ww / max(sw, 1)
        waist_to_hip = ww / max(hw, 1)

        scores = {
            "Hourglass": 0,
            "Pear": 0,
            "Apple": 0,
            "Rectangle": 0,
            "Inverted Triangle": 0,
        }

        # Shoulder vs Hip comparison
        if 0.92 <= shoulder_to_hip <= 1.08:
            # Shoulders and hips similar
            if waist_to_shoulder < 0.75:
                scores["Hourglass"] += 4
            elif waist_to_shoulder > 0.9:
                scores["Apple"] += 3
            else:
                scores["Rectangle"] += 3
        elif shoulder_to_hip < 0.92:
            # Hips wider
            scores["Pear"] += 4
            if waist_to_hip < 0.75:
                scores["Hourglass"] += 2
        else:
            # Shoulders wider
            scores["Inverted Triangle"] += 4

        # Waist definition
        avg_width = (sw + hw) / 2
        waist_ratio = ww / max(avg_width, 1)

        if waist_ratio < 0.7:
            scores["Hourglass"] += 3
        elif waist_ratio < 0.8:
            scores["Hourglass"] += 1
            scores["Pear"] += 1
        elif waist_ratio > 0.9:
            scores["Rectangle"] += 2
            scores["Apple"] += 2
        else:
            scores["Rectangle"] += 1

        # Torso vs leg proportions
        tl = measurements["torso_length"]
        ll = measurements["leg_length"]
        if ll > 0:
            torso_to_leg = tl / ll
            if torso_to_leg > 0.7:
                scores["Apple"] += 1  # Longer torso common in apple

        return max(scores, key=scores.get)

    def _get_proportions(self, measurements: Dict) -> Dict:
        """Calculate meaningful body proportions."""
        sw = measurements["shoulder_width"]
        hw = measurements["hip_width"]
        ww = measurements["waist_width_estimate"]
        tl = measurements["torso_length"]
        ll = measurements["leg_length"]

        return {
            "shoulder_to_hip_ratio": round(sw / max(hw, 1), 2),
            "waist_to_hip_ratio": round(ww / max(hw, 1), 2),
            "waist_to_shoulder_ratio": round(ww / max(sw, 1), 2),
            "torso_to_leg_ratio": round(tl / max(ll, 1), 2),
            "shoulder_hip_difference": round(abs(sw - hw), 1),
        }

    def _get_confidence(self, measurements: Dict, body_type: str) -> float:
        """Estimate classification confidence."""
        sw = measurements["shoulder_width"]
        hw = measurements["hip_width"]
        ratio = sw / max(hw, 1)

        if body_type == "Pear" and ratio < 0.85:
            return 0.88
        elif body_type == "Inverted Triangle" and ratio > 1.15:
            return 0.88
        elif body_type == "Hourglass":
            return 0.82
        else:
            return 0.75

    def _point(self, landmark, w, h) -> Tuple[float, float]:
        return (landmark.x * w, landmark.y * h)

    def _distance(self, p1: Tuple, p2: Tuple) -> float:
        return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
