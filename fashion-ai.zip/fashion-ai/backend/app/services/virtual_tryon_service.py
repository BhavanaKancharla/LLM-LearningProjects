"""
Virtual Try-On Service
Overlays clothing items onto user photos using body segmentation and pose estimation.
Uses MediaPipe for body landmark detection and OpenCV for image compositing.
"""

import cv2
import numpy as np
import mediapipe.solutions.pose as mp_pose_module
import mediapipe.solutions.selfie_segmentation as mp_selfie_module
from PIL import Image
from typing import Tuple, Dict
import os


class VirtualTryOnService:
    """Service for virtual clothing try-on using body pose estimation."""

    def __init__(self):
        """Initialize MediaPipe pose and selfie segmentation."""
        self.mp_pose = mp_pose_module
        self.mp_selfie_segmentation = mp_selfie_module
        self.pose = mp_pose_module.Pose(
            static_image_mode=True,
            model_complexity=2,
            min_detection_confidence=0.5,
        )
        self.segmentation = mp_selfie_module.SelfieSegmentation(
            model_selection=1
        )

    def try_on(self, user_image_path: str, clothing_image_path: str, category: str = "tops") -> Dict:
        """
        Overlay a clothing item onto the user's body.

        Args:
            user_image_path: Path to the user's full body photo
            clothing_image_path: Path to the clothing item image (with transparency)
            category: Type of clothing (tops, bottoms, dresses)

        Returns:
            Dictionary with result image path and metadata
        """
        # Read images
        user_img = cv2.imread(user_image_path)
        if user_img is None:
            raise ValueError("Could not read user image")

        clothing_img = cv2.imread(clothing_image_path, cv2.IMREAD_UNCHANGED)
        if clothing_img is None:
            raise ValueError("Could not read clothing image")

        user_rgb = cv2.cvtColor(user_img, cv2.COLOR_BGR2RGB)

        # Detect body pose
        pose_results = self.pose.process(user_rgb)
        if not pose_results.pose_landmarks:
            raise ValueError("Could not detect body pose. Please upload a clear full-body photo.")

        landmarks = pose_results.pose_landmarks.landmark
        h, w, _ = user_img.shape

        # Get body segmentation mask
        seg_results = self.segmentation.process(user_rgb)
        seg_mask = (seg_results.segmentation_mask > 0.5).astype(np.uint8)

        # Get key body points based on clothing category
        if category == "tops":
            result = self._overlay_top(user_img, clothing_img, landmarks, w, h)
        elif category == "bottoms":
            result = self._overlay_bottom(user_img, clothing_img, landmarks, w, h)
        elif category == "dresses":
            result = self._overlay_dress(user_img, clothing_img, landmarks, w, h)
        else:
            result = self._overlay_top(user_img, clothing_img, landmarks, w, h)

        # Save result
        result_filename = f"tryon_result_{os.urandom(4).hex()}.jpg"
        result_path = os.path.join("uploads", result_filename)
        cv2.imwrite(result_path, result)

        return {
            "result_image_url": f"/uploads/{result_filename}",
            "fit_score": self._calculate_fit_score(landmarks, category),
            "color_match_score": 0.0,  # Will be calculated with color profile
            "suggestions": self._get_fit_suggestions(landmarks, category),
        }

    def _overlay_top(self, user_img: np.ndarray, clothing_img: np.ndarray,
                     landmarks, w: int, h: int) -> np.ndarray:
        """Overlay a top/shirt onto the upper body."""
        result = user_img.copy()

        # Key points for top placement
        left_shoulder = landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value]
        right_shoulder = landmarks[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
        left_hip = landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value]
        right_hip = landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value]

        # Calculate placement dimensions
        shoulder_left_x = int(left_shoulder.x * w)
        shoulder_right_x = int(right_shoulder.x * w)
        shoulder_y = int(min(left_shoulder.y, right_shoulder.y) * h)
        hip_y = int(max(left_hip.y, right_hip.y) * h)

        # Add padding for natural look
        padding_x = int((shoulder_right_x - shoulder_left_x) * 0.15)
        target_x = shoulder_left_x - padding_x
        target_y = shoulder_y - int((hip_y - shoulder_y) * 0.05)
        target_w = (shoulder_right_x - shoulder_left_x) + 2 * padding_x
        target_h = hip_y - shoulder_y + int((hip_y - shoulder_y) * 0.1)

        # Resize clothing to fit
        clothing_resized = self._resize_clothing(clothing_img, target_w, target_h)

        # Overlay with alpha blending
        result = self._alpha_blend(result, clothing_resized, target_x, target_y)

        return result

    def _overlay_bottom(self, user_img: np.ndarray, clothing_img: np.ndarray,
                        landmarks, w: int, h: int) -> np.ndarray:
        """Overlay pants/skirt onto the lower body."""
        result = user_img.copy()

        left_hip = landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value]
        right_hip = landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value]
        left_ankle = landmarks[self.mp_pose.PoseLandmark.LEFT_ANKLE.value]
        right_ankle = landmarks[self.mp_pose.PoseLandmark.RIGHT_ANKLE.value]

        hip_left_x = int(left_hip.x * w)
        hip_right_x = int(right_hip.x * w)
        hip_y = int(min(left_hip.y, right_hip.y) * h)
        ankle_y = int(max(left_ankle.y, right_ankle.y) * h)

        padding_x = int((hip_right_x - hip_left_x) * 0.2)
        target_x = hip_left_x - padding_x
        target_y = hip_y
        target_w = (hip_right_x - hip_left_x) + 2 * padding_x
        target_h = ankle_y - hip_y

        clothing_resized = self._resize_clothing(clothing_img, target_w, target_h)
        result = self._alpha_blend(result, clothing_resized, target_x, target_y)

        return result

    def _overlay_dress(self, user_img: np.ndarray, clothing_img: np.ndarray,
                       landmarks, w: int, h: int) -> np.ndarray:
        """Overlay a dress from shoulders to knees/ankles."""
        result = user_img.copy()

        left_shoulder = landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value]
        right_shoulder = landmarks[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
        left_knee = landmarks[self.mp_pose.PoseLandmark.LEFT_KNEE.value]
        right_knee = landmarks[self.mp_pose.PoseLandmark.RIGHT_KNEE.value]

        shoulder_left_x = int(left_shoulder.x * w)
        shoulder_right_x = int(right_shoulder.x * w)
        shoulder_y = int(min(left_shoulder.y, right_shoulder.y) * h)
        knee_y = int(max(left_knee.y, right_knee.y) * h)

        padding_x = int((shoulder_right_x - shoulder_left_x) * 0.2)
        target_x = shoulder_left_x - padding_x
        target_y = shoulder_y - int((knee_y - shoulder_y) * 0.03)
        target_w = (shoulder_right_x - shoulder_left_x) + 2 * padding_x
        target_h = knee_y - shoulder_y + int((knee_y - shoulder_y) * 0.15)

        clothing_resized = self._resize_clothing(clothing_img, target_w, target_h)
        result = self._alpha_blend(result, clothing_resized, target_x, target_y)

        return result

    def _resize_clothing(self, clothing_img: np.ndarray, target_w: int, target_h: int) -> np.ndarray:
        """Resize clothing image to target dimensions while maintaining aspect ratio."""
        if target_w <= 0 or target_h <= 0:
            return clothing_img

        return cv2.resize(clothing_img, (target_w, target_h), interpolation=cv2.INTER_AREA)

    def _alpha_blend(self, background: np.ndarray, overlay: np.ndarray,
                     x: int, y: int) -> np.ndarray:
        """Blend overlay image onto background using alpha channel."""
        result = background.copy()
        bh, bw = background.shape[:2]

        # Ensure coordinates are within bounds
        x = max(0, x)
        y = max(0, y)

        oh, ow = overlay.shape[:2]

        # Calculate valid region
        x_end = min(x + ow, bw)
        y_end = min(y + oh, bh)
        overlay_w = x_end - x
        overlay_h = y_end - y

        if overlay_w <= 0 or overlay_h <= 0:
            return result

        overlay_crop = overlay[:overlay_h, :overlay_w]

        if overlay_crop.shape[2] == 4:
            # Has alpha channel
            alpha = overlay_crop[:, :, 3:4] / 255.0
            rgb = overlay_crop[:, :, :3]

            roi = result[y:y_end, x:x_end]
            blended = (rgb * alpha + roi * (1 - alpha)).astype(np.uint8)
            result[y:y_end, x:x_end] = blended
        else:
            # No alpha, direct overlay
            result[y:y_end, x:x_end] = overlay_crop[:, :, :3]

        return result

    def _calculate_fit_score(self, landmarks, category: str) -> float:
        """Calculate a fit confidence score based on pose detection quality."""
        relevant_landmarks = {
            "tops": [
                self.mp_pose.PoseLandmark.LEFT_SHOULDER,
                self.mp_pose.PoseLandmark.RIGHT_SHOULDER,
                self.mp_pose.PoseLandmark.LEFT_HIP,
                self.mp_pose.PoseLandmark.RIGHT_HIP,
            ],
            "bottoms": [
                self.mp_pose.PoseLandmark.LEFT_HIP,
                self.mp_pose.PoseLandmark.RIGHT_HIP,
                self.mp_pose.PoseLandmark.LEFT_ANKLE,
                self.mp_pose.PoseLandmark.RIGHT_ANKLE,
            ],
            "dresses": [
                self.mp_pose.PoseLandmark.LEFT_SHOULDER,
                self.mp_pose.PoseLandmark.RIGHT_SHOULDER,
                self.mp_pose.PoseLandmark.LEFT_KNEE,
                self.mp_pose.PoseLandmark.RIGHT_KNEE,
            ],
        }

        required = relevant_landmarks.get(category, relevant_landmarks["tops"])
        visibilities = [landmarks[lm.value].visibility for lm in required]
        avg_visibility = sum(visibilities) / len(visibilities)

        return round(min(avg_visibility * 1.2, 1.0), 2)

    def _get_fit_suggestions(self, landmarks, category: str) -> list:
        """Generate fit suggestions based on body proportions."""
        suggestions = []

        left_shoulder = landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value]
        right_shoulder = landmarks[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
        left_hip = landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value]
        right_hip = landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value]

        shoulder_width = abs(right_shoulder.x - left_shoulder.x)
        hip_width = abs(right_hip.x - left_hip.x)

        ratio = shoulder_width / max(hip_width, 0.01)

        if ratio > 1.3:
            suggestions.append("V-necklines and A-line silhouettes balance your proportions")
            suggestions.append("Try darker colors on top with lighter bottoms")
        elif ratio < 0.9:
            suggestions.append("Boat necks and off-shoulder styles broaden your shoulders")
            suggestions.append("Structured shoulders add visual balance")
        else:
            suggestions.append("Your balanced proportions work well with most styles")
            suggestions.append("Try belted styles to emphasize your waistline")

        return suggestions
