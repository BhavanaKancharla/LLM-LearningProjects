"""Database models and connection setup."""

from sqlalchemy import create_engine, Column, Integer, String, Float, JSON, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime

DATABASE_URL = "sqlite:///./fashion_ai.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Color analysis results
    color_profile = relationship("ColorProfile", back_populates="user", uselist=False)
    wishlist = relationship("WishlistItem", back_populates="user")


class ColorProfile(Base):
    __tablename__ = "color_profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    skin_tone_hex = Column(String)
    hair_color_hex = Column(String)
    eye_color_hex = Column(String)
    season = Column(String)  # Spring, Summer, Autumn, Winter
    sub_season = Column(String)  # e.g., Light Spring, Deep Winter
    undertone = Column(String)  # Warm, Cool, Neutral
    contrast_level = Column(String)  # Low, Medium, High
    recommended_colors = Column(JSON)  # List of hex colors
    avoid_colors = Column(JSON)  # List of hex colors to avoid
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="color_profile")


class CatalogItem(Base):
    __tablename__ = "catalog_items"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    category = Column(String)  # tops, bottoms, dresses, accessories
    color_hex = Column(String)
    color_name = Column(String)
    image_url = Column(String)
    price = Column(Float)
    description = Column(String)
    tags = Column(JSON)  # List of style tags


class WishlistItem(Base):
    __tablename__ = "wishlist_items"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    catalog_item_id = Column(Integer, ForeignKey("catalog_items.id"))
    added_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="wishlist")
    catalog_item = relationship("CatalogItem")
