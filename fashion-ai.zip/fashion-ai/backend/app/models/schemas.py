"""Pydantic schemas for request/response validation."""

from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime


# Auth Schemas
class UserCreate(BaseModel):
    username: str
    email: str
    password: str


class UserLogin(BaseModel):
    username: str
    password: str


class UserResponse(BaseModel):
    id: int
    username: str
    email: str

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str


# Color Analysis Schemas
class ColorAnalysisResult(BaseModel):
    skin_tone: dict  # hex, rgb, name
    hair_color: dict
    eye_color: dict
    season: str
    sub_season: str
    undertone: str
    contrast_level: str
    recommended_colors: List[dict]  # [{hex, name, category}]
    avoid_colors: List[dict]
    style_tips: List[str]


# Catalog Schemas
class CatalogItemSchema(BaseModel):
    id: int
    name: str
    category: str
    color_hex: str
    color_name: str
    image_url: str
    price: float
    description: str
    tags: List[str]
    match_score: Optional[float] = None

    class Config:
        from_attributes = True


class CatalogItemCreate(BaseModel):
    name: str
    category: str
    color_hex: str
    color_name: str
    image_url: str
    price: float
    description: str
    tags: List[str]


# Recommendation Schemas
class RecommendationRequest(BaseModel):
    season: str
    undertone: str
    contrast_level: str
    category: Optional[str] = None


class RecommendationResponse(BaseModel):
    items: List[CatalogItemSchema]
    color_palette: List[dict]
    styling_tips: List[str]


# Virtual Try-On Schemas
class TryOnResult(BaseModel):
    result_image_url: str
    fit_score: float
    color_match_score: float
    suggestions: List[str]
