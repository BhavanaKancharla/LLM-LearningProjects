"""Recommendations API endpoints."""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional

from app.models.database import get_db, ColorProfile, User
from app.services.recommendation_service import RecommendationService
from app.api.auth import get_current_user

router = APIRouter()
recommendation_service = RecommendationService()


@router.get("/get")
def get_recommendations(
    category: Optional[str] = Query(None, description="Filter by category: tops, bottoms, dresses, accessories"),
    limit: int = Query(20, ge=1, le=50),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Get personalized clothing recommendations based on user's color profile.

    Requires a color analysis to be completed first.
    Returns scored catalog items, a curated palette, and styling tips.
    """
    # Get user's color profile
    profile = db.query(ColorProfile).filter(
        ColorProfile.user_id == current_user.id
    ).first()

    if not profile:
        raise HTTPException(
            status_code=404,
            detail="No color profile found. Please complete a color analysis first.",
        )

    # Get recommendations
    result = recommendation_service.get_recommendations(
        db=db,
        season=profile.season,
        undertone=profile.undertone,
        contrast_level=profile.contrast_level,
        recommended_colors=profile.recommended_colors or [],
        category=category,
        limit=limit,
    )

    return result


@router.get("/palette")
def get_personal_palette(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get user's personal color palette with usage suggestions."""
    profile = db.query(ColorProfile).filter(
        ColorProfile.user_id == current_user.id
    ).first()

    if not profile:
        raise HTTPException(
            status_code=404,
            detail="No color profile found. Please complete a color analysis first.",
        )

    palette = recommendation_service._generate_palette(
        profile.season, profile.undertone, profile.contrast_level
    )

    return {
        "season": profile.season,
        "sub_season": profile.sub_season,
        "undertone": profile.undertone,
        "palette": palette,
        "recommended_colors": profile.recommended_colors,
        "avoid_colors": profile.avoid_colors,
    }
