"""Body Type Analysis API endpoints."""

from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
import os
import uuid

from app.models.database import get_db, User
from app.api.auth import get_current_user

router = APIRouter()
body_type_service = None

def get_body_type_service():
    global body_type_service
    if body_type_service is None:
        from app.services.body_type_service import BodyTypeService
        body_type_service = BodyTypeService()
    return body_type_service


@router.post("/analyze")
async def analyze_body_type(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    """
    Analyze body type from a full-body photo.

    Detects body type (Hourglass, Pear, Apple, Rectangle, Inverted Triangle)
    by measuring body proportions from pose landmarks.
    Returns classification, measurements, proportions, and style advice.
    """
    allowed_types = ["image/jpeg", "image/png", "image/webp"]
    if file.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Only JPEG, PNG, and WebP images are supported")

    file_ext = file.filename.split(".")[-1]
    filename = f"{uuid.uuid4()}.{file_ext}"
    filepath = os.path.join("uploads", filename)

    with open(filepath, "wb") as f:
        content = await file.read()
        f.write(content)

    try:
        result = get_body_type_service().analyze(filepath)
        return result
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    finally:
        if os.path.exists(filepath):
            os.remove(filepath)
