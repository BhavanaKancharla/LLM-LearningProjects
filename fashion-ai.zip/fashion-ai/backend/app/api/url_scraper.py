"""URL Scraper API endpoints."""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional

from app.models.database import User
from app.api.auth import get_current_user

router = APIRouter()

def get_scraper_service():
    from app.services.url_scraper_service import URLScraperService
    return URLScraperService()


class ScrapeRequest(BaseModel):
    url: str


@router.post("/extract")
async def extract_from_url(
    request: ScrapeRequest,
    current_user: User = Depends(get_current_user),
):
    """
    Extract clothing item from a shopping website URL.

    Provide a product URL from any e-commerce website.
    The system will extract the product image, title, price,
    and color information for use in virtual try-on or analysis.
    """
    try:
        result = get_scraper_service().extract_from_url(request.url)
        return result
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to extract data: {str(e)}")
