"""Style Report API endpoints."""

from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
import os
import uuid

from app.models.database import get_db, User, ColorProfile
from app.api.auth import get_current_user

router = APIRouter()
_style_report_service = None

def get_style_report_service():
    global _style_report_service
    if _style_report_service is None:
        from app.services.style_report_service import StyleReportService
        _style_report_service = StyleReportService()
    return _style_report_service


@router.post("/generate")
async def generate_style_report(
    face_photo: UploadFile = File(...),
    body_photo: Optional[UploadFile] = File(None),
    current_user: User = Depends(get_current_user),
):
    """
    Generate a comprehensive style report.

    Upload a face photo (required) and optionally a full-body photo.
    Returns a complete analysis including:
    - Color season & palette
    - Face shape analysis
    - Body type (if body photo provided)
    - Hairstyle recommendations
    - Outfit guidelines
    - Overall style score
    - Personalized key recommendations
    """
    allowed_types = ["image/jpeg", "image/png", "image/webp"]

    if face_photo.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Only JPEG, PNG, and WebP images are supported")

    # Save face photo
    face_ext = face_photo.filename.split(".")[-1]
    face_filename = f"face_{uuid.uuid4()}.{face_ext}"
    face_filepath = os.path.join("uploads", face_filename)

    with open(face_filepath, "wb") as f:
        f.write(await face_photo.read())

    # Save body photo if provided
    body_filepath = None
    if body_photo and body_photo.filename:
        if body_photo.content_type not in allowed_types:
            os.remove(face_filepath)
            raise HTTPException(status_code=400, detail="Body photo must be JPEG, PNG, or WebP")

        body_ext = body_photo.filename.split(".")[-1]
        body_filename = f"body_{uuid.uuid4()}.{body_ext}"
        body_filepath = os.path.join("uploads", body_filename)

        with open(body_filepath, "wb") as f:
            f.write(await body_photo.read())

    try:
        report = get_style_report_service().generate_full_report(
            face_image_path=face_filepath,
            body_image_path=body_filepath,
        )
        return report

    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
    finally:
        # Cleanup
        if os.path.exists(face_filepath):
            os.remove(face_filepath)
        if body_filepath and os.path.exists(body_filepath):
            os.remove(body_filepath)


@router.post("/evaluate-outfit")
async def evaluate_outfit(
    outfit_color_hex: str = Form(...),
    outfit_category: str = Form(...),
    body_type: str = Form(default="Rectangle"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Evaluate how well a specific outfit suits the user.

    Requires a completed color analysis. Provide the outfit's
    dominant color and category to get a suitability score.
    """
    # Get user's color profile
    color_profile = db.query(ColorProfile).filter(
        ColorProfile.user_id == current_user.id
    ).first()

    if not color_profile:
        raise HTTPException(
            status_code=404,
            detail="No color profile found. Complete a color analysis first."
        )

    profile_data = {
        "season": color_profile.season,
        "undertone": color_profile.undertone,
        "recommended_colors": color_profile.recommended_colors or [],
        "avoid_colors": color_profile.avoid_colors or [],
    }

    result = get_style_report_service().evaluate_outfit(
        user_color_profile=profile_data,
        user_body_type=body_type,
        outfit_color_hex=outfit_color_hex,
        outfit_category=outfit_category,
    )

    return result
