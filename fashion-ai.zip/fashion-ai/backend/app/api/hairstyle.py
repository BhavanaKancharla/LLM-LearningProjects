"""Hairstyle Recommendation API endpoints."""

from fastapi import APIRouter, UploadFile, File, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
import os
import uuid

from app.models.database import get_db, User, ColorProfile
from app.api.auth import get_current_user

router = APIRouter()

def get_face_shape_svc():
    from app.services.face_shape_service import FaceShapeService
    return FaceShapeService()

def get_hairstyle_svc():
    from app.services.hairstyle_service import HairstyleService
    return HairstyleService()


@router.post("/recommend")
async def get_hairstyle_recommendations(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Get personalized hairstyle recommendations.

    Upload a face photo to detect face shape, then combines with
    color profile (if available) to recommend ideal hairstyles
    and hair color suggestions.
    """
    allowed_types = ["image/jpeg", "image/png", "image/webp"]
    if file.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Only JPEG, PNG, and WebP images are supported")

    file_ext = file.filename.split(".")[-1]
    filename = f"{uuid.uuid4()}.{file_ext}"
    filepath = os.path.join("uploads", filename)

    with open(filepath, "wb") as f:
        content = await file.read()
        f.write(content)

    try:
        # Detect face shape
        face_result = get_face_shape_svc().analyze(filepath)

        # Get color profile if exists
        color_profile = db.query(ColorProfile).filter(
            ColorProfile.user_id == current_user.id
        ).first()

        season = None
        undertone = None
        hair_color = None

        if color_profile:
            season = color_profile.season
            undertone = color_profile.undertone
            hair_color = color_profile.hair_color_hex

        # Get hairstyle recommendations
        hairstyle_result = get_hairstyle_svc().get_recommendations(
            face_shape=face_result["face_shape"],
            season=season,
            undertone=undertone,
            hair_color_hex=hair_color,
        )

        return {
            "face_shape_analysis": face_result,
            "hairstyle_recommendations": hairstyle_result,
        }

    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    finally:
        if os.path.exists(filepath):
            os.remove(filepath)


@router.get("/by-shape")
def get_recommendations_by_shape(
    face_shape: str = Query(..., description="Face shape: Oval, Round, Square, Heart, Oblong, Diamond"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get hairstyle recommendations for a known face shape."""
    valid_shapes = ["Oval", "Round", "Square", "Heart", "Oblong", "Diamond"]
    if face_shape not in valid_shapes:
        raise HTTPException(status_code=400, detail=f"Invalid face shape. Must be one of: {valid_shapes}")

    color_profile = db.query(ColorProfile).filter(
        ColorProfile.user_id == current_user.id
    ).first()

    season = color_profile.season if color_profile else None
    undertone = color_profile.undertone if color_profile else None

    return get_hairstyle_svc().get_recommendations(
        face_shape=face_shape,
        season=season,
        undertone=undertone,
    )
