"""Color Analysis API endpoints."""

from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
import os
import uuid

from app.models.database import get_db, ColorProfile, User
from app.models.schemas import ColorAnalysisResult
from app.api.auth import get_current_user

router = APIRouter()
color_service = None

def get_color_service():
    global color_service
    if color_service is None:
        from app.services.color_analysis_service import ColorAnalysisService
        color_service = ColorAnalysisService()
    return color_service


@router.post("/analyze", response_model=ColorAnalysisResult)
async def analyze_colors(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Analyze user's photo to determine their personal color season.

    Upload a clear, well-lit face photo for best results.
    Returns skin tone, hair color, eye color, season classification,
    and personalized color recommendations.
    """
    # Validate file type
    allowed_types = ["image/jpeg", "image/png", "image/webp"]
    if file.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Only JPEG, PNG, and WebP images are supported")

    # Save uploaded file
    file_ext = file.filename.split(".")[-1]
    filename = f"{uuid.uuid4()}.{file_ext}"
    filepath = os.path.join("uploads", filename)

    with open(filepath, "wb") as f:
        content = await file.read()
        f.write(content)

    try:
        # Run color analysis
        result = get_color_service().analyze(filepath)

        # Save to user profile
        existing_profile = db.query(ColorProfile).filter(
            ColorProfile.user_id == current_user.id
        ).first()

        if existing_profile:
            # Update existing profile
            existing_profile.skin_tone_hex = result["skin_tone"]["hex"]
            existing_profile.hair_color_hex = result["hair_color"]["hex"]
            existing_profile.eye_color_hex = result["eye_color"]["hex"]
            existing_profile.season = result["season"]
            existing_profile.sub_season = result["sub_season"]
            existing_profile.undertone = result["undertone"]
            existing_profile.contrast_level = result["contrast_level"]
            existing_profile.recommended_colors = [c["hex"] for c in result["recommended_colors"]]
            existing_profile.avoid_colors = [c["hex"] for c in result["avoid_colors"]]
        else:
            # Create new profile
            profile = ColorProfile(
                user_id=current_user.id,
                skin_tone_hex=result["skin_tone"]["hex"],
                hair_color_hex=result["hair_color"]["hex"],
                eye_color_hex=result["eye_color"]["hex"],
                season=result["season"],
                sub_season=result["sub_season"],
                undertone=result["undertone"],
                contrast_level=result["contrast_level"],
                recommended_colors=[c["hex"] for c in result["recommended_colors"]],
                avoid_colors=[c["hex"] for c in result["avoid_colors"]],
            )
            db.add(profile)

        db.commit()
        return result

    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    finally:
        # Clean up uploaded file
        if os.path.exists(filepath):
            os.remove(filepath)


@router.get("/profile")
def get_color_profile(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get the user's saved color profile."""
    profile = db.query(ColorProfile).filter(
        ColorProfile.user_id == current_user.id
    ).first()

    if not profile:
        raise HTTPException(status_code=404, detail="No color profile found. Please analyze a photo first.")

    return {
        "skin_tone_hex": profile.skin_tone_hex,
        "hair_color_hex": profile.hair_color_hex,
        "eye_color_hex": profile.eye_color_hex,
        "season": profile.season,
        "sub_season": profile.sub_season,
        "undertone": profile.undertone,
        "contrast_level": profile.contrast_level,
        "recommended_colors": profile.recommended_colors,
        "avoid_colors": profile.avoid_colors,
    }
