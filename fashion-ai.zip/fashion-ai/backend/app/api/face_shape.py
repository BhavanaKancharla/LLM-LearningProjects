"""Face Shape Analysis API endpoints."""

from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
import os
import uuid

from app.models.database import get_db, User
from app.api.auth import get_current_user

router = APIRouter()
face_shape_service = None

def get_face_shape_service():
    global face_shape_service
    if face_shape_service is None:
        from app.services.face_shape_service import FaceShapeService
        face_shape_service = FaceShapeService()
    return face_shape_service


@router.post("/analyze")
async def analyze_face_shape(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    """
    Analyze face shape from a selfie.

    Detects face shape (Oval, Round, Square, Heart, Oblong, Diamond)
    by measuring facial proportions from landmarks.
    Returns shape classification, measurements, and proportions.
    """
    allowed_types = ["image/jpeg", "image/png", "image/webp"]
    if file.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Only JPEG, PNG, and WebP images are supported")

    file_ext = file.filename.split(".")[-1]
    filename = f"{uuid.uuid4()}.{file_ext}"
    filepath = os.path.join("uploads", filename)

    with open(filepath, "wb") as f:
        content = await file.read()
        f.write(content)

    try:
        result = get_face_shape_service().analyze(filepath)
        return result
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    finally:
        if os.path.exists(filepath):
            os.remove(filepath)
