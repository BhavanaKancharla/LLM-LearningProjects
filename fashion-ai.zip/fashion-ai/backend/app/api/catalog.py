"""Catalog API endpoints."""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, List

from app.models.database import get_db, CatalogItem, WishlistItem, User
from app.models.schemas import CatalogItemSchema, CatalogItemCreate
from app.api.auth import get_current_user

router = APIRouter()


@router.get("/items", response_model=List[CatalogItemSchema])
def list_catalog_items(
    category: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    min_price: Optional[float] = Query(None),
    max_price: Optional[float] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    """List catalog items with optional filters."""
    query = db.query(CatalogItem)

    if category:
        query = query.filter(CatalogItem.category == category)
    if search:
        query = query.filter(CatalogItem.name.ilike(f"%{search}%"))
    if min_price is not None:
        query = query.filter(CatalogItem.price >= min_price)
    if max_price is not None:
        query = query.filter(CatalogItem.price <= max_price)

    items = query.offset(skip).limit(limit).all()
    return items


@router.get("/items/{item_id}", response_model=CatalogItemSchema)
def get_catalog_item(item_id: int, db: Session = Depends(get_db)):
    """Get a specific catalog item."""
    item = db.query(CatalogItem).filter(CatalogItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@router.post("/items", response_model=CatalogItemSchema)
def create_catalog_item(item: CatalogItemCreate, db: Session = Depends(get_db)):
    """Add a new item to the catalog."""
    db_item = CatalogItem(**item.model_dump())
    db.add(db_item)
    db.commit()
    db.refresh(db_item)
    return db_item


@router.get("/categories")
def list_categories(db: Session = Depends(get_db)):
    """List all available categories."""
    categories = db.query(CatalogItem.category).distinct().all()
    return [c[0] for c in categories]


# Wishlist endpoints
@router.post("/wishlist/{item_id}")
def add_to_wishlist(
    item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Add an item to user's wishlist."""
    # Check if item exists
    item = db.query(CatalogItem).filter(CatalogItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")

    # Check if already in wishlist
    existing = db.query(WishlistItem).filter(
        WishlistItem.user_id == current_user.id,
        WishlistItem.catalog_item_id == item_id,
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Item already in wishlist")

    wishlist_item = WishlistItem(user_id=current_user.id, catalog_item_id=item_id)
    db.add(wishlist_item)
    db.commit()
    return {"message": "Added to wishlist"}


@router.delete("/wishlist/{item_id}")
def remove_from_wishlist(
    item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Remove an item from user's wishlist."""
    item = db.query(WishlistItem).filter(
        WishlistItem.user_id == current_user.id,
        WishlistItem.catalog_item_id == item_id,
    ).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not in wishlist")

    db.delete(item)
    db.commit()
    return {"message": "Removed from wishlist"}


@router.get("/wishlist")
def get_wishlist(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get user's wishlist."""
    wishlist = db.query(WishlistItem).filter(
        WishlistItem.user_id == current_user.id
    ).all()

    items = []
    for wi in wishlist:
        item = db.query(CatalogItem).filter(CatalogItem.id == wi.catalog_item_id).first()
        if item:
            items.append(item)
    return items
