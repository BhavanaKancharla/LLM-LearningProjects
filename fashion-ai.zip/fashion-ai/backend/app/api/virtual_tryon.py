"""Virtual Try-On API endpoints."""

from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy.orm import Session
import os
import uuid

from app.models.database import get_db, CatalogItem, User
from app.models.schemas import TryOnResult
from app.api.auth import get_current_user

router = APIRouter()
tryon_service = None

def get_tryon_service():
    global tryon_service
    if tryon_service is None:
        from app.services.virtual_tryon_service import VirtualTryOnService
        tryon_service = VirtualTryOnService()
    return tryon_service


@router.post("/try-on", response_model=TryOnResult)
async def virtual_try_on(
    user_photo: UploadFile = File(...),
    catalog_item_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Virtual try-on: overlay a catalog clothing item onto the user's photo.

    Upload a full-body photo and specify the catalog item ID to try on.
    Returns the composite image with the clothing overlaid.
    """
    # Validate file
    allowed_types = ["image/jpeg", "image/png", "image/webp"]
    if user_photo.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Only JPEG, PNG, and WebP images are supported")

    # Get catalog item
    catalog_item = db.query(CatalogItem).filter(CatalogItem.id == catalog_item_id).first()
    if not catalog_item:
        raise HTTPException(status_code=404, detail="Catalog item not found")

    # Save user photo
    file_ext = user_photo.filename.split(".")[-1]
    user_filename = f"user_{uuid.uuid4()}.{file_ext}"
    user_filepath = os.path.join("uploads", user_filename)

    with open(user_filepath, "wb") as f:
        content = await user_photo.read()
        f.write(content)

    try:
        # Get clothing image path
        clothing_path = catalog_item.image_url.lstrip("/")
        if not os.path.exists(clothing_path):
            raise HTTPException(status_code=404, detail="Clothing image not found on server")

        # Perform try-on
        result = get_tryon_service().try_on(
            user_image_path=user_filepath,
            clothing_image_path=clothing_path,
            category=catalog_item.category,
        )

        return result

    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    finally:
        # Clean up user photo (keep result)
        if os.path.exists(user_filepath):
            os.remove(user_filepath)


@router.post("/try-on-upload")
async def virtual_try_on_with_upload(
    user_photo: UploadFile = File(...),
    clothing_photo: UploadFile = File(...),
    category: str = Form(default="tops"),
    current_user: User = Depends(get_current_user),
):
    """
    Virtual try-on with custom clothing image upload.

    Upload both a full-body photo and a clothing item image.
    The clothing image should ideally have a transparent background.
    """
    # Save both images
    user_ext = user_photo.filename.split(".")[-1]
    user_filename = f"user_{uuid.uuid4()}.{user_ext}"
    user_filepath = os.path.join("uploads", user_filename)

    clothing_ext = clothing_photo.filename.split(".")[-1]
    clothing_filename = f"clothing_{uuid.uuid4()}.{clothing_ext}"
    clothing_filepath = os.path.join("uploads", clothing_filename)

    with open(user_filepath, "wb") as f:
        f.write(await user_photo.read())

    with open(clothing_filepath, "wb") as f:
        f.write(await clothing_photo.read())

    try:
        result = get_tryon_service().try_on(
            user_image_path=user_filepath,
            clothing_image_path=clothing_filepath,
            category=category,
        )
        return result

    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    finally:
        if os.path.exists(user_filepath):
            os.remove(user_filepath)
        if os.path.exists(clothing_filepath):
            os.remove(clothing_filepath)
