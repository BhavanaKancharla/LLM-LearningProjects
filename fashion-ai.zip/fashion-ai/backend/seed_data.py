"""
Seed script to populate the catalog with sample clothing items.
Run this once to add demo data: python seed_data.py
"""

from app.models.database import SessionLocal, Base, engine, CatalogItem

# Create tables
Base.metadata.create_all(bind=engine)

# Sample catalog items
SAMPLE_ITEMS = [
    # Tops
    {"name": "Classic White Blouse", "category": "tops", "color_hex": "#FFFFFF", "color_name": "White", "image_url": "/static/catalog/white_blouse.png", "price": 45.99, "description": "Crisp white button-down blouse perfect for any season", "tags": ["classic", "professional", "versatile"]},
    {"name": "Navy Blue Silk Top", "category": "tops", "color_hex": "#000080", "color_name": "Navy", "image_url": "/static/catalog/navy_top.png", "price": 65.00, "description": "Elegant navy silk blouse for winter and summer types", "tags": ["elegant", "professional", "cool-tones"]},
    {"name": "Coral Wrap Top", "category": "tops", "color_hex": "#FF7F50", "color_name": "Coral", "image_url": "/static/catalog/coral_top.png", "price": 38.99, "description": "Warm coral wrap top ideal for spring and autumn types", "tags": ["warm", "casual", "flattering"]},
    {"name": "Forest Green Turtleneck", "category": "tops", "color_hex": "#228B22", "color_name": "Forest Green", "image_url": "/static/catalog/green_turtleneck.png", "price": 52.00, "description": "Rich forest green turtleneck for autumn and winter seasons", "tags": ["cozy", "winter", "rich-tones"]},
    {"name": "Dusty Rose Peplum", "category": "tops", "color_hex": "#DCAE96", "color_name": "Dusty Rose", "image_url": "/static/catalog/dusty_rose_top.png", "price": 42.50, "description": "Soft dusty rose peplum top for summer types", "tags": ["feminine", "soft", "cool-tones"]},
    {"name": "Mustard Yellow Blouse", "category": "tops", "color_hex": "#FFDB58", "color_name": "Mustard", "image_url": "/static/catalog/mustard_blouse.png", "price": 35.00, "description": "Cheerful mustard blouse perfect for spring types", "tags": ["bright", "casual", "warm-tones"]},
    {"name": "Burgundy V-Neck", "category": "tops", "color_hex": "#800020", "color_name": "Burgundy", "image_url": "/static/catalog/burgundy_vneck.png", "price": 48.00, "description": "Deep burgundy V-neck for autumn and deep winter", "tags": ["rich", "versatile", "deep-tones"]},
    {"name": "Lavender Chiffon Top", "category": "tops", "color_hex": "#E6E6FA", "color_name": "Lavender", "image_url": "/static/catalog/lavender_top.png", "price": 55.00, "description": "Delicate lavender chiffon top for summer types", "tags": ["delicate", "feminine", "cool-tones"]},
    {"name": "Terracotta Linen Shirt", "category": "tops", "color_hex": "#CC4E24", "color_name": "Terracotta", "image_url": "/static/catalog/terracotta_shirt.png", "price": 58.00, "description": "Earthy terracotta linen shirt for autumn types", "tags": ["earthy", "natural", "warm-tones"]},
    {"name": "Royal Blue Satin Blouse", "category": "tops", "color_hex": "#4169E1", "color_name": "Royal Blue", "image_url": "/static/catalog/royal_blue_top.png", "price": 62.00, "description": "Bold royal blue satin for winter types", "tags": ["bold", "statement", "cool-tones"]},

    # Bottoms
    {"name": "Classic Black Trousers", "category": "bottoms", "color_hex": "#1C1C1C", "color_name": "Black", "image_url": "/static/catalog/black_trousers.png", "price": 68.00, "description": "Tailored black trousers - a winter type essential", "tags": ["classic", "professional", "versatile"]},
    {"name": "Camel Wide-Leg Pants", "category": "bottoms", "color_hex": "#C19A6B", "color_name": "Camel", "image_url": "/static/catalog/camel_pants.png", "price": 72.00, "description": "Warm camel wide-leg pants for autumn and spring", "tags": ["warm", "elegant", "trendy"]},
    {"name": "Olive Cargo Pants", "category": "bottoms", "color_hex": "#556B2F", "color_name": "Olive", "image_url": "/static/catalog/olive_pants.png", "price": 55.00, "description": "Earthy olive cargo pants for autumn types", "tags": ["casual", "earthy", "warm-tones"]},
    {"name": "Charcoal Pencil Skirt", "category": "bottoms", "color_hex": "#36454F", "color_name": "Charcoal", "image_url": "/static/catalog/charcoal_skirt.png", "price": 58.00, "description": "Sophisticated charcoal skirt for summer types (instead of black)", "tags": ["professional", "sophisticated", "neutral"]},
    {"name": "Cream Linen Pants", "category": "bottoms", "color_hex": "#FFFDD0", "color_name": "Cream", "image_url": "/static/catalog/cream_pants.png", "price": 62.00, "description": "Light cream linen pants for spring types", "tags": ["light", "summer", "casual"]},
    {"name": "Navy Tailored Shorts", "category": "bottoms", "color_hex": "#000080", "color_name": "Navy", "image_url": "/static/catalog/navy_shorts.png", "price": 45.00, "description": "Smart navy shorts for cool-toned types", "tags": ["smart-casual", "summer", "cool-tones"]},

    # Dresses
    {"name": "Emerald Green Midi Dress", "category": "dresses", "color_hex": "#50C878", "color_name": "Emerald", "image_url": "/static/catalog/emerald_dress.png", "price": 89.00, "description": "Stunning emerald midi dress for clear spring and winter", "tags": ["statement", "elegant", "occasion"]},
    {"name": "Dusty Blue Maxi Dress", "category": "dresses", "color_hex": "#6699CC", "color_name": "Dusty Blue", "image_url": "/static/catalog/dusty_blue_dress.png", "price": 95.00, "description": "Flowing dusty blue maxi dress for summer types", "tags": ["flowy", "romantic", "cool-tones"]},
    {"name": "Rust Red Wrap Dress", "category": "dresses", "color_hex": "#B7410E", "color_name": "Rust", "image_url": "/static/catalog/rust_dress.png", "price": 78.00, "description": "Warm rust wrap dress ideal for autumn types", "tags": ["warm", "flattering", "versatile"]},
    {"name": "Black Cocktail Dress", "category": "dresses", "color_hex": "#000000", "color_name": "Black", "image_url": "/static/catalog/black_dress.png", "price": 120.00, "description": "Classic black cocktail dress for winter types", "tags": ["classic", "evening", "bold"]},
    {"name": "Peach Sundress", "category": "dresses", "color_hex": "#FFDAB9", "color_name": "Peach", "image_url": "/static/catalog/peach_dress.png", "price": 55.00, "description": "Light peach sundress for light spring types", "tags": ["light", "casual", "warm-tones"]},
    {"name": "Plum A-Line Dress", "category": "dresses", "color_hex": "#8E4585", "color_name": "Plum", "image_url": "/static/catalog/plum_dress.png", "price": 85.00, "description": "Rich plum A-line dress for cool winter and deep autumn", "tags": ["rich", "elegant", "deep-tones"]},

    # Accessories
    {"name": "Gold Statement Necklace", "category": "accessories", "color_hex": "#FFD700", "color_name": "Gold", "image_url": "/static/catalog/gold_necklace.png", "price": 35.00, "description": "Gold necklace perfect for warm undertones", "tags": ["warm", "statement", "jewelry"]},
    {"name": "Silver Hoop Earrings", "category": "accessories", "color_hex": "#C0C0C0", "color_name": "Silver", "image_url": "/static/catalog/silver_earrings.png", "price": 28.00, "description": "Silver hoops for cool undertones", "tags": ["cool", "classic", "jewelry"]},
    {"name": "Tan Leather Belt", "category": "accessories", "color_hex": "#D2B48C", "color_name": "Tan", "image_url": "/static/catalog/tan_belt.png", "price": 42.00, "description": "Warm tan leather belt for spring and autumn", "tags": ["warm", "classic", "leather"]},
    {"name": "Burgundy Silk Scarf", "category": "accessories", "color_hex": "#800020", "color_name": "Burgundy", "image_url": "/static/catalog/burgundy_scarf.png", "price": 48.00, "description": "Rich burgundy scarf for autumn and deep winter", "tags": ["rich", "versatile", "layering"]},
]


def seed_database():
    """Populate the database with sample catalog items."""
    db = SessionLocal()

    # Check if data already exists
    existing = db.query(CatalogItem).count()
    if existing > 0:
        print(f"Database already has {existing} items. Skipping seed.")
        db.close()
        return

    for item_data in SAMPLE_ITEMS:
        item = CatalogItem(**item_data)
        db.add(item)

    db.commit()
    print(f"Successfully seeded {len(SAMPLE_ITEMS)} catalog items!")
    db.close()


if __name__ == "__main__":
    seed_database()
