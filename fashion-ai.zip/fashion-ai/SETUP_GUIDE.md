# Fashion AI - Setup Guide
## Complete Installation & Running Instructions

---

## Prerequisites

Before starting, ensure you have installed:

| Software | Version | Download |
|----------|---------|----------|
| Python | 3.10+ | https://www.python.org/downloads/ |
| Node.js | 18+ | https://nodejs.org/ |
| pip | (comes with Python) | - |
| npm | (comes with Node.js) | - |

---

## Step 1: Extract the Project

Extract the zip file to your desired location. You should have:
```
fashion-ai/
├── backend/
├── frontend/
├── docker-compose.yml
├── README.md
├── DOCUMENTATION.md
└── SETUP_GUIDE.md (this file)
```

---

## Step 2: Backend Setup

### 2.1 Open Terminal & Navigate to Backend
```bash
cd fashion-ai/backend
```

### 2.2 Create Virtual Environment
```bash
python -m venv venv
```

### 2.3 Activate Virtual Environment

**Windows (PowerShell):**
```powershell
.\venv\Scripts\Activate
```

**Windows (CMD):**
```cmd
venv\Scripts\activate.bat
```

**Linux/Mac:**
```bash
source venv/bin/activate
```

You should see `(venv)` appear in your terminal prompt.

### 2.4 Install Python Dependencies

**Standard install (if you have direct internet access):**
```bash
pip install -r requirements.txt
```

**If behind corporate proxy/firewall (use public PyPI):**
```bash
pip install --index-url https://pypi.org/simple/ --trusted-host pypi.org --trusted-host files.pythonhosted.org -r requirements.txt
```

**If mediapipe causes issues on Windows, install without it:**
```bash
pip install --index-url https://pypi.org/simple/ --trusted-host pypi.org --trusted-host files.pythonhosted.org fastapi uvicorn python-multipart sqlalchemy "python-jose[cryptography]" pydantic python-dotenv aiosqlite opencv-python numpy scikit-learn Pillow beautifulsoup4 requests lxml httpx
```

### 2.5 Seed the Database
```bash
python seed_data.py
```
Expected output: `Successfully seeded 26 catalog items!`

### 2.6 Start the Backend Server
```bash
python -m uvicorn app.main:app --port 8000
```

**On Windows, if uvicorn isn't found, use:**
```bash
.\venv\Scripts\python.exe -m uvicorn app.main:app --port 8000
```

Expected output:
```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
```

### 2.7 Verify Backend
Open browser: http://localhost:8000
You should see: `{"message": "Fashion AI - Personalized Fashion Advisor", "version": "2.0.0", ...}`

API Documentation: http://localhost:8000/docs

---

## Step 3: Frontend Setup

### 3.1 Open a NEW Terminal & Navigate to Frontend
```bash
cd fashion-ai/frontend
```

### 3.2 Install Node.js Dependencies
```bash
npm install
```
This downloads ~200MB of packages (React, Tailwind, Vite, etc.)

### 3.3 Start the Frontend Dev Server
```bash
npm run dev
```

Expected output:
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:3000/
```

---

## Step 4: Use the Application

1. Open browser: **http://localhost:3000**
2. Click **"Sign Up"** → create an account
3. Navigate to **"Color Analysis"** → upload a selfie
4. Navigate to **"Style Report"** → get full analysis
5. Browse **"Catalog"** → see items with match scores
6. Navigate to **"For You"** → personalized recommendations

---

## Troubleshooting

### "Registration failed"
- Ensure backend is running on port 8000
- Check backend terminal for error messages

### "No module named 'xxx'"
- Ensure venv is activated (you see `(venv)` in terminal)
- Re-run: `pip install -r requirements.txt`

### "CORS error" in browser console
- Backend must be running BEFORE making requests
- Restart backend after any code changes

### "Port 8000 already in use"
```bash
# Windows - kill process using port 8000
taskkill /F /IM python.exe
```

### "mediapipe solutions not found" (Windows)
- This is a known issue on Windows with newer mediapipe versions
- The app uses OpenCV DNN as fallback — Color Analysis still works
- For full mediapipe support, use Linux/Mac

### "npm install fails"
- Ensure Node.js 18+ is installed: `node --version`
- Clear npm cache: `npm cache clean --force`
- Try again: `npm install`

---

## Required Libraries (Python)

| Package | Purpose |
|---------|---------|
| fastapi | Web framework |
| uvicorn | ASGI server |
| python-multipart | File upload handling |
| Pillow | Image processing |
| numpy | Numerical operations |
| opencv-python | Computer vision, face detection |
| scikit-learn | K-Means clustering |
| pydantic | Data validation |
| python-jose[cryptography] | JWT token auth |
| sqlalchemy | Database ORM |
| aiosqlite | Async SQLite support |
| python-dotenv | Environment variables |
| beautifulsoup4 | Web scraping |
| requests | HTTP client for scraping |
| lxml | HTML parser |
| httpx | Async HTTP client |

## Required Libraries (Node.js)

| Package | Purpose |
|---------|---------|
| react | UI framework |
| react-dom | React rendering |
| react-router-dom | Client-side routing |
| axios | HTTP client |
| lucide-react | Icons |
| react-dropzone | File drag & drop |
| tailwindcss | CSS framework |
| vite | Build tool |
| @vitejs/plugin-react | React support for Vite |
| autoprefixer | CSS vendor prefixes |
| postcss | CSS processing |

---

## Running Both Services (Summary)

| Terminal | Command | URL |
|----------|---------|-----|
| Terminal 1 (Backend) | `cd backend && .\venv\Scripts\python.exe -m uvicorn app.main:app --port 8000` | http://localhost:8000 |
| Terminal 2 (Frontend) | `cd frontend && npm run dev` | http://localhost:3000 |

---

## Docker (Alternative)

If you have Docker installed, run both services with one command:
```bash
cd fashion-ai
docker-compose up --build
```

---

## Project by
**AI-Powered Personalized Fashion Advisor**
Built with Python, React, OpenCV, and scikit-learn
