# 🎨 Fashion AI - Personalized Fashion Advisor with Virtual Try-On & Style Recommendation

An end-to-end AI/ML application that provides a comprehensive personalized fashion advisory system. It analyzes users' facial features, body proportions, and personal coloring to recommend hairstyles, clothing styles, and colors — with virtual try-on capability.

![Python](https://img.shields.io/badge/Python-3.11-blue)
![React](https://img.shields.io/badge/React-18-61DAFB)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104-009688)
![OpenCV](https://img.shields.io/badge/OpenCV-4.8-5C3EE8)
![MediaPipe](https://img.shields.io/badge/MediaPipe-0.10-00A98F)
![scikit--learn](https://img.shields.io/badge/scikit--learn-1.3-F7931E)

---

## 🌟 Features

### 1. 📊 Comprehensive Style Report
- **One-click full analysis** combining all modules
- Overall style score (0-100)
- Personalized key recommendations
- Outfit guidelines (necklines, silhouettes, patterns, fabrics, accessories)

### 2. 🎨 Personal Color Analysis
- **Face Detection** — MediaPipe Face Mesh (468 landmarks)
- **Skin Tone Extraction** — K-Means clustering on cheek/forehead regions
- **Hair & Eye Color Detection** — Region-specific sampling
- **Season Classification** — 12 sub-seasons (Spring/Summer/Autumn/Winter)
- **Undertone Detection** — Warm / Cool / Neutral via HSV analysis
- **Contrast Level** — Low / Medium / High

### 3. 👤 Face Shape Analysis
- Detects **6 face shapes**: Oval, Round, Square, Heart, Oblong, Diamond
- Measures forehead width, cheekbone width, jaw width, face length, jaw angle
- Calculates facial proportions and ratios
- Provides confidence score

### 4. 💇 Hairstyle Recommendations
- Personalized to face shape + color season
- 6 recommended styles per face shape with suitability scores
- Styles to avoid
- Styling tips
- **Hair color suggestions** matched to seasonal palette

### 5. 👗 Body Type Analysis
- Detects **5 body types**: Hourglass, Pear, Apple, Rectangle, Inverted Triangle
- Uses pose landmark body measurements (shoulders, waist, hips)
- Returns best clothing styles and styles to avoid
- Body proportion ratios

### 6. 🪄 Virtual Try-On
- **Body Pose Estimation** — 33 body landmarks
- **Body Segmentation** — Person/background separation
- **Clothing Overlay** — Alpha blending with proper sizing
- Supports tops, bottoms, and dresses
- Fit score + styling suggestions

### 7. 🔗 Try-On from URL
- Paste any e-commerce product URL
- AI extracts product image, title, price, color
- Download and overlay onto your body
- Supports most major shopping websites

### 8. 🛍️ Smart Recommendations
- **CIE Lab color distance** for perceptually accurate matching
- Match scoring (0-100%) per catalog item
- Personalized palette with usage suggestions
- Category-specific styling tips

### 9. 📋 Outfit Evaluation
- Score any outfit against your profile
- Color compatibility percentage
- Body type suitability percentage
- Specific feedback and verdict

---

## 🏗️ Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                        Frontend (React + Tailwind)                 │
│  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐        │
│  │ Style  │ │ Color  │ │  Hair  │ │  Body  │ │ Try-On │ ...     │
│  │ Report │ │Analysis│ │ Styles │ │  Type  │ │  /URL  │         │
│  └───┬────┘ └───┬────┘ └───┬────┘ └───┬────┘ └───┬────┘        │
└──────┼──────────┼──────────┼──────────┼──────────┼──────────────┘
       │          │          │          │          │
       ▼          ▼          ▼          ▼          ▼
┌──────────────────────────────────────────────────────────────────┐
│                      Backend (FastAPI)                             │
│                                                                    │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │                      API Layer (10 routers)                   │ │
│  └──────────────────────────┬──────────────────────────────────┘ │
│                             │                                      │
│  ┌──────────────────────────▼──────────────────────────────────┐ │
│  │                    Service Layer (7 services)                 │ │
│  │                                                               │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │ │
│  │  │    Color     │  │  Face Shape  │  │   Body Type  │       │ │
│  │  │   Analysis   │  │   Analysis   │  │   Analysis   │       │ │
│  │  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘       │ │
│  │         │                  │                  │               │ │
│  │  ┌──────▼───────┐  ┌──────▼───────┐  ┌──────▼───────┐       │ │
│  │  │  Hairstyle   │  │   Virtual    │  │    Style     │       │ │
│  │  │   Service    │  │   Try-On     │  │    Report    │       │ │
│  │  └──────────────┘  └──────────────┘  └──────────────┘       │ │
│  │                                                               │ │
│  │  ┌──────────────┐  ┌──────────────┐                          │ │
│  │  │ Recommend-   │  │ URL Scraper  │                          │ │
│  │  │  ation Eng.  │  │   Service    │                          │ │
│  │  └──────────────┘  └──────────────┘                          │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                    │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │               ML Pipeline                                     │ │
│  │  • MediaPipe Face Mesh (468 landmarks)                        │ │
│  │  • MediaPipe Pose (33 body landmarks)                         │ │
│  │  • MediaPipe Selfie Segmentation                              │ │
│  │  • K-Means Clustering (color extraction)                      │ │
│  │  • CIE Lab Color Distance (matching)                          │ │
│  │  • HSV/LAB Color Space Analysis                               │ │
│  │  • Geometric Proportion Analysis (face/body)                  │ │
│  │  • BeautifulSoup Web Scraping                                 │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                    │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  Database (SQLite) — Users, ColorProfiles, Catalog, Wishlist  │ │
│  └─────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| **Frontend** | React 18, Tailwind CSS, Vite, React Router, Axios |
| **Backend** | Python 3.11, FastAPI, SQLAlchemy, Pydantic |
| **ML/CV** | MediaPipe, OpenCV, scikit-learn, NumPy, Pillow |
| **Web Scraping** | BeautifulSoup4, Requests, lxml |
| **Database** | SQLite (easily swappable to PostgreSQL) |
| **Auth** | JWT (python-jose), bcrypt (passlib) |
| **Deployment** | Docker, Docker Compose |

---

## 🚀 Getting Started

### Prerequisites
- Python 3.10+
- Node.js 18+
- pip

### Backend Setup

```bash
cd fashion-ai/backend

# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate
# macOS/Linux: source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Seed the database with sample catalog
python seed_data.py

# Start server
uvicorn app.main:app --reload --port 8000
```

API docs: `http://localhost:8000/docs`

### Frontend Setup

```bash
cd fashion-ai/frontend

npm install
npm run dev
```

App: `http://localhost:3000`

### Docker (Both at once)

```bash
cd fashion-ai
docker-compose up --build
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| **Auth** | | |
| POST | `/api/auth/register` | Create user |
| POST | `/api/auth/login` | Get JWT token |
| GET | `/api/auth/me` | Current user |
| **Color Analysis** | | |
| POST | `/api/color-analysis/analyze` | Analyze photo → color season |
| GET | `/api/color-analysis/profile` | Get saved profile |
| **Face Shape** | | |
| POST | `/api/face-shape/analyze` | Detect face shape |
| **Body Type** | | |
| POST | `/api/body-type/analyze` | Detect body type |
| **Hairstyle** | | |
| POST | `/api/hairstyle/recommend` | Photo → hairstyle recommendations |
| GET | `/api/hairstyle/by-shape` | Get styles for known shape |
| **Virtual Try-On** | | |
| POST | `/api/tryon/try-on` | Try on catalog item |
| POST | `/api/tryon/try-on-upload` | Try on custom image |
| **URL Scraper** | | |
| POST | `/api/scraper/extract` | Extract product from URL |
| **Style Report** | | |
| POST | `/api/style-report/generate` | Full comprehensive report |
| POST | `/api/style-report/evaluate-outfit` | Score an outfit |
| **Catalog** | | |
| GET | `/api/catalog/items` | List items (filters) |
| POST | `/api/catalog/wishlist/{id}` | Add to wishlist |
| **Recommendations** | | |
| GET | `/api/recommendations/get` | Personalized items |
| GET | `/api/recommendations/palette` | Personal palette |

---

## 🧠 AI/ML Techniques Used

1. **MediaPipe Face Mesh** — 468-point facial landmark detection
2. **MediaPipe Pose** — 33-point body pose estimation
3. **MediaPipe Selfie Segmentation** — Person/background separation
4. **K-Means Clustering** — Dominant color extraction
5. **CIE Lab Color Space** — Perceptually uniform color distance
6. **HSV Color Analysis** — Undertone classification via hue angles
7. **Geometric Proportion Analysis** — Face shape & body type classification
8. **Luminance Calculation** — Contrast level determination
9. **Alpha Compositing** — Realistic clothing overlay
10. **Web Scraping (BeautifulSoup)** — Product extraction from URLs
11. **Decision Tree Classification** — Season & shape determination
12. **Color Theory Engine** — 12-season palette system

---

## 📁 Project Structure

```
fashion-ai/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth.py                 # JWT authentication
│   │   │   ├── body_type.py            # Body type endpoint
│   │   │   ├── catalog.py              # Catalog CRUD + wishlist
│   │   │   ├── color_analysis.py       # Color analysis endpoint
│   │   │   ├── face_shape.py           # Face shape endpoint
│   │   │   ├── hairstyle.py            # Hairstyle recommendations
│   │   │   ├── recommendations.py      # Outfit recommendations
│   │   │   ├── style_report.py         # Full report + outfit eval
│   │   │   ├── url_scraper.py          # URL extraction endpoint
│   │   │   └── virtual_tryon.py        # Try-on endpoint
│   │   ├── models/
│   │   │   ├── database.py             # SQLAlchemy models
│   │   │   └── schemas.py             # Pydantic schemas
│   │   ├── services/
│   │   │   ├── body_type_service.py    # Body type ML
│   │   │   ├── color_analysis_service.py # Color ML
│   │   │   ├── face_shape_service.py   # Face shape ML
│   │   │   ├── hairstyle_service.py    # Hairstyle engine
│   │   │   ├── recommendation_service.py # Color matching
│   │   │   ├── style_report_service.py # Report generator
│   │   │   ├── url_scraper_service.py  # Web scraper
│   │   │   └── virtual_tryon_service.py # Body overlay
│   │   └── main.py                     # FastAPI entry point
│   ├── requirements.txt
│   ├── seed_data.py
│   ├── Dockerfile
│   └── .env
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx
│   │   │   ├── ColorSwatch.jsx
│   │   │   └── ImageUpload.jsx
│   │   ├── pages/
│   │   │   ├── HomePage.jsx
│   │   │   ├── StyleReportPage.jsx     # Full analysis page
│   │   │   ├── ColorAnalysisPage.jsx
│   │   │   ├── HairstylePage.jsx       # Hair recommendations
│   │   │   ├── BodyAnalysisPage.jsx    # Body type page
│   │   │   ├── VirtualTryOnPage.jsx
│   │   │   ├── URLTryOnPage.jsx        # Try-on from URL
│   │   │   ├── CatalogPage.jsx
│   │   │   ├── RecommendationsPage.jsx
│   │   │   ├── LoginPage.jsx
│   │   │   └── RegisterPage.jsx
│   │   ├── services/
│   │   │   ├── api.js
│   │   │   └── auth.js
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
├── docker-compose.yml
├── .gitignore
└── README.md
```

---

## 📊 Resume Talking Points

- Built an **AI-Powered Personalized Fashion Advisor** integrating AI, Computer Vision, and Machine Learning
- Implemented **face shape analysis** using geometric proportions from 468 facial landmarks (MediaPipe)
- Developed **body type classification** (5 types) using pose estimation landmark ratios
- Created **hairstyle recommendation engine** personalized to face shape and color season
- Built **virtual try-on** using body segmentation, pose estimation, and alpha compositing
- Implemented **product URL scraping** to extract clothing items from e-commerce websites
- Designed a **comprehensive style report** system combining all analyses into a unified score
- Applied **CIE Lab color distance** for perceptually accurate clothing-to-palette matching
- Classified users into **12 seasonal color sub-types** using K-Means clustering and color theory
- Developed **full-stack application** with React/Tailwind frontend and FastAPI backend
- Created **RESTful API** with JWT auth, file upload handling, and 10+ endpoints
- Deployed with **Docker Compose** for reproducible environments

---

## 🔮 Future Enhancements

- [ ] AR live camera try-on (WebRTC + TensorFlow.js)
- [ ] GAN-based clothing texture transfer
- [ ] Size recommendation from body measurements
- [ ] Multi-item outfit builder
- [ ] Social sharing of virtual outfits
- [ ] E-commerce integration (Shopify, WooCommerce)
- [ ] Mobile app (React Native)
- [ ] Advanced avatar generation (3D mesh)
- [ ] Seasonal wardrobe planner
- [ ] AI-powered style trend analysis

---

## 📜 License

MIT License — free to use for portfolio!
