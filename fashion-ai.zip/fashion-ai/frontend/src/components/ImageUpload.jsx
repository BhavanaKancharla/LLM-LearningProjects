import React, { useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { Upload, Image as ImageIcon } from 'lucide-react'

function ImageUpload({ onUpload, preview, label = 'Upload a photo', accept = 'image/*' }) {
  const onDrop = useCallback((acceptedFiles) => {
    if (acceptedFiles.length > 0) {
      onUpload(acceptedFiles[0])
    }
  }, [onUpload])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': ['.jpeg', '.jpg', '.png', '.webp'] },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024, // 10MB
  })

  return (
    <div
      {...getRootProps()}
      className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 ${
        isDragActive
          ? 'border-purple-500 bg-purple-50'
          : 'border-gray-200 hover:border-purple-300 hover:bg-purple-50/50'
      }`}
    >
      <input {...getInputProps()} />

      {preview ? (
        <div className="space-y-4">
          <img
            src={preview}
            alt="Preview"
            className="mx-auto max-h-64 rounded-xl object-cover shadow-md"
          />
          <p className="text-sm text-gray-500">Click or drag to replace</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="mx-auto w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center">
            {isDragActive ? (
              <ImageIcon className="w-8 h-8 text-purple-600" />
            ) : (
              <Upload className="w-8 h-8 text-purple-600" />
            )}
          </div>
          <div>
            <p className="text-lg font-medium text-gray-700">{label}</p>
            <p className="text-sm text-gray-500 mt-1">
              {isDragActive ? 'Drop your image here' : 'Drag & drop or click to browse'}
            </p>
            <p className="text-xs text-gray-400 mt-2">JPEG, PNG, WebP • Max 10MB</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default ImageUpload
