import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Sparkles, Menu, X, ChevronDown } from 'lucide-react'

function Navbar({ isAuthenticated, onLogout }) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [analysisOpen, setAnalysisOpen] = useState(false)
  const location = useLocation()

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/style-report', label: 'Style Report', auth: true },
    {
      label: 'Analysis',
      auth: true,
      dropdown: [
        { path: '/color-analysis', label: 'Color Analysis' },
        { path: '/hairstyle', label: 'Hairstyles' },
        { path: '/body-analysis', label: 'Body Type' },
      ],
    },
    {
      label: 'Try On',
      auth: true,
      dropdown: [
        { path: '/try-on', label: 'Upload & Try' },
        { path: '/url-tryon', label: 'From URL' },
      ],
    },
    { path: '/catalog', label: 'Catalog' },
    { path: '/recommendations', label: 'For You', auth: true },
  ]

  const isActive = (path) => location.pathname === path

  return (
    <nav className="bg-white/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <Sparkles className="w-7 h-7 text-purple-600" />
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-500 bg-clip-text text-transparent">
              Fashion AI
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link, index) => {
              if (link.auth && !isAuthenticated) return null

              // Dropdown menu
              if (link.dropdown) {
                return (
                  <div key={index} className="relative group">
                    <button className="px-4 py-2 rounded-lg text-sm font-medium text-gray-600 hover:text-purple-600 hover:bg-purple-50 transition-colors flex items-center gap-1">
                      {link.label}
                      <ChevronDown className="w-3 h-3" />
                    </button>
                    <div className="absolute top-full left-0 mt-1 bg-white rounded-xl shadow-lg border border-gray-100 py-2 min-w-[160px] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                      {link.dropdown.map((item) => (
                        <Link
                          key={item.path}
                          to={item.path}
                          className={`block px-4 py-2 text-sm transition-colors ${
                            isActive(item.path)
                              ? 'bg-purple-50 text-purple-700'
                              : 'text-gray-600 hover:bg-purple-50 hover:text-purple-600'
                          }`}
                        >
                          {item.label}
                        </Link>
                      ))}
                    </div>
                  </div>
                )
              }

              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive(link.path)
                      ? 'bg-purple-100 text-purple-700'
                      : 'text-gray-600 hover:text-purple-600 hover:bg-purple-50'
                  }`}
                >
                  {link.label}
                </Link>
              )
            })}
          </div>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center gap-3">
            {isAuthenticated ? (
              <button onClick={onLogout} className="btn-secondary text-sm py-2">
                Logout
              </button>
            ) : (
              <>
                <Link to="/login" className="btn-secondary text-sm py-2">
                  Login
                </Link>
                <Link to="/register" className="btn-primary text-sm py-2">
                  Sign Up
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle navigation menu"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            {navLinks.map((link, index) => {
              if (link.auth && !isAuthenticated) return null

              if (link.dropdown) {
                return (
                  <div key={index}>
                    <p className="px-4 py-2 text-xs font-semibold text-gray-400 uppercase">{link.label}</p>
                    {link.dropdown.map((item) => (
                      <Link
                        key={item.path}
                        to={item.path}
                        onClick={() => setMobileOpen(false)}
                        className={`block px-6 py-2 text-sm ${
                          isActive(item.path) ? 'bg-purple-100 text-purple-700' : 'text-gray-600'
                        }`}
                      >
                        {item.label}
                      </Link>
                    ))}
                  </div>
                )
              }

              return (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setMobileOpen(false)}
                  className={`block px-4 py-3 rounded-lg text-sm font-medium ${
                    isActive(link.path) ? 'bg-purple-100 text-purple-700' : 'text-gray-600'
                  }`}
                >
                  {link.label}
                </Link>
              )
            })}
            <div className="mt-4 pt-4 border-t border-gray-100 flex gap-3 px-4">
              {isAuthenticated ? (
                <button onClick={onLogout} className="btn-secondary text-sm py-2 w-full">
                  Logout
                </button>
              ) : (
                <>
                  <Link to="/login" className="btn-secondary text-sm py-2 w-full text-center">Login</Link>
                  <Link to="/register" className="btn-primary text-sm py-2 w-full text-center">Sign Up</Link>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

export default Navbar
