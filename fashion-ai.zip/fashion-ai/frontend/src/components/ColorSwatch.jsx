import React from 'react'

function ColorSwatch({ color, name, size = 'md', showLabel = true, onClick }) {
  const sizes = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
  }

  return (
    <div
      className={`flex flex-col items-center gap-1 ${onClick ? 'cursor-pointer' : ''}`}
      onClick={onClick}
    >
      <div
        className={`${sizes[size]} rounded-full border-2 border-white shadow-md transition-transform hover:scale-110`}
        style={{ backgroundColor: color }}
        title={name || color}
      />
      {showLabel && name && (
        <span className="text-xs text-gray-500 text-center max-w-16 truncate">
          {name}
        </span>
      )}
    </div>
  )
}

export default ColorSwatch
