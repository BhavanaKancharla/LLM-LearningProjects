/**
 * API service - centralized HTTP client with auth headers.
 */

import axios from 'axios'
import { getToken } from './auth'

const API_BASE = 'http://localhost:8000'

const api = axios.create({
  baseURL: API_BASE,
})

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = getToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Auth
export const login = (username, password) =>
  api.post('/api/auth/login', { username, password })

export const register = (username, email, password) =>
  api.post('/api/auth/register', { username, email, password })

export const getMe = () => api.get('/api/auth/me')

// Color Analysis
export const analyzeColors = (formData) =>
  api.post('/api/color-analysis/analyze', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

export const getColorProfile = () => api.get('/api/color-analysis/profile')

// Face Shape Analysis
export const analyzeFaceShape = (formData) =>
  api.post('/api/face-shape/analyze', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

// Body Type Analysis
export const analyzeBodyType = (formData) =>
  api.post('/api/body-type/analyze', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

// Hairstyle Recommendations
export const getHairstyleRecommendations = (formData) =>
  api.post('/api/hairstyle/recommend', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

export const getHairstyleByShape = (faceShape) =>
  api.get('/api/hairstyle/by-shape', { params: { face_shape: faceShape } })

// Virtual Try-On
export const tryOn = (formData) =>
  api.post('/api/tryon/try-on', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

export const tryOnUpload = (formData) =>
  api.post('/api/tryon/try-on-upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

// Catalog
export const getCatalogItems = (params) => api.get('/api/catalog/items', { params })
export const getCatalogItem = (id) => api.get(`/api/catalog/items/${id}`)
export const getCategories = () => api.get('/api/catalog/categories')
export const addToWishlist = (itemId) => api.post(`/api/catalog/wishlist/${itemId}`)
export const removeFromWishlist = (itemId) => api.delete(`/api/catalog/wishlist/${itemId}`)
export const getWishlist = () => api.get('/api/catalog/wishlist')

// Recommendations
export const getRecommendations = (params) => api.get('/api/recommendations/get', { params })
export const getPersonalPalette = () => api.get('/api/recommendations/palette')

// URL Scraper
export const scrapeProductUrl = (url) =>
  api.post('/api/scraper/extract', { url })

// Style Report
export const generateStyleReport = (formData) =>
  api.post('/api/style-report/generate', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

export const evaluateOutfit = (formData) =>
  api.post('/api/style-report/evaluate-outfit', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

export default api
