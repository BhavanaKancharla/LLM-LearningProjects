/**
 * Authentication service - manages JWT tokens and auth state.
 */

const TOKEN_KEY = 'fashion_ai_token'

export function getToken() {
  return localStorage.getItem(TOKEN_KEY)
}

export function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token)
}

export function removeToken() {
  localStorage.removeItem(TOKEN_KEY)
}
