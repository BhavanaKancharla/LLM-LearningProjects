import React, { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import HomePage from './pages/HomePage'
import ColorAnalysisPage from './pages/ColorAnalysisPage'
import VirtualTryOnPage from './pages/VirtualTryOnPage'
import CatalogPage from './pages/CatalogPage'
import RecommendationsPage from './pages/RecommendationsPage'
import StyleReportPage from './pages/StyleReportPage'
import HairstylePage from './pages/HairstylePage'
import BodyAnalysisPage from './pages/BodyAnalysisPage'
import URLTryOnPage from './pages/URLTryOnPage'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import { getToken, removeToken } from './services/auth'

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(!!getToken())

  const handleLogin = () => setIsAuthenticated(true)
  const handleLogout = () => {
    removeToken()
    setIsAuthenticated(false)
  }

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50">
        <Navbar isAuthenticated={isAuthenticated} onLogout={handleLogout} />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage onLogin={handleLogin} />} />
            <Route path="/register" element={<RegisterPage onLogin={handleLogin} />} />
            <Route
              path="/color-analysis"
              element={isAuthenticated ? <ColorAnalysisPage /> : <Navigate to="/login" />}
            />
            <Route
              path="/style-report"
              element={isAuthenticated ? <StyleReportPage /> : <Navigate to="/login" />}
            />
            <Route
              path="/hairstyle"
              element={isAuthenticated ? <HairstylePage /> : <Navigate to="/login" />}
            />
            <Route
              path="/body-analysis"
              element={isAuthenticated ? <BodyAnalysisPage /> : <Navigate to="/login" />}
            />
            <Route
              path="/try-on"
              element={isAuthenticated ? <VirtualTryOnPage /> : <Navigate to="/login" />}
            />
            <Route
              path="/url-tryon"
              element={isAuthenticated ? <URLTryOnPage /> : <Navigate to="/login" />}
            />
            <Route path="/catalog" element={<CatalogPage />} />
            <Route
              path="/recommendations"
              element={isAuthenticated ? <RecommendationsPage /> : <Navigate to="/login" />}
            />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App
