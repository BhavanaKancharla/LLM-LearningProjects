import React, { useState } from 'react'
import { FileText, Upload, Star, Scissors, User, Palette, CheckCircle, XCircle, AlertCircle } from 'lucide-react'
import ImageUpload from '../components/ImageUpload'
import ColorSwatch from '../components/ColorSwatch'
import { generateStyleReport } from '../services/api'

function StyleReportPage() {
  const [faceFile, setFaceFile] = useState(null)
  const [facePreview, setFacePreview] = useState(null)
  const [bodyFile, setBodyFile] = useState(null)
  const [bodyPreview, setBodyPreview] = useState(null)
  const [report, setReport] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleFaceUpload = (file) => {
    setFaceFile(file)
    setFacePreview(URL.createObjectURL(file))
    setReport(null)
  }

  const handleBodyUpload = (file) => {
    setBodyFile(file)
    setBodyPreview(URL.createObjectURL(file))
  }

  const handleGenerate = async () => {
    if (!faceFile) return

    setLoading(true)
    setError(null)

    const formData = new FormData()
    formData.append('face_photo', faceFile)
    if (bodyFile) {
      formData.append('body_photo', bodyFile)
    }

    try {
      const response = await generateStyleReport(formData)
      setReport(response.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to generate report')
    } finally {
      setLoading(false)
    }
  }

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600'
    if (score >= 60) return 'text-yellow-600'
    return 'text-red-500'
  }

  const getScoreBg = (score) => {
    if (score >= 80) return 'bg-green-50 border-green-200'
    if (score >= 60) return 'bg-yellow-50 border-yellow-200'
    return 'bg-red-50 border-red-200'
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Comprehensive Style Report</h1>
        <p className="text-gray-600">
          Get a complete analysis of your colors, face shape, body type, and personalized style advice
        </p>
      </div>

      {/* Upload Section */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <div className="card">
          <h3 className="font-semibold mb-2">Face Photo <span className="text-red-500">*</span></h3>
          <p className="text-sm text-gray-500 mb-4">Clear selfie showing face, hair, eyes</p>
          <ImageUpload onUpload={handleFaceUpload} preview={facePreview} label="Upload face photo" />
        </div>
        <div className="card">
          <h3 className="font-semibold mb-2">Full Body Photo <span className="text-gray-400">(optional)</span></h3>
          <p className="text-sm text-gray-500 mb-4">Standing straight, front-facing</p>
          <ImageUpload onUpload={handleBodyUpload} preview={bodyPreview} label="Upload body photo" />
        </div>
      </div>

      {/* Generate Button */}
      <div className="text-center mb-8">
        <button
          onClick={handleGenerate}
          disabled={!faceFile || loading}
          className="btn-primary text-lg px-10 py-4 disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center gap-2"
        >
          {loading ? (
            <>
              <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Generating Full Report...
            </>
          ) : (
            <>
              <FileText className="w-5 h-5" />
              Generate Style Report
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="max-w-lg mx-auto mb-8 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">
          {error}
        </div>
      )}

      {/* Report Results */}
      {report && (
        <div className="space-y-6">
          {/* Overall Score */}
          <div className={`card border-2 ${getScoreBg(report.overall_style_score)} text-center`}>
            <h2 className="text-lg font-medium mb-2">Overall Style Analysis Score</h2>
            <div className={`text-5xl font-bold ${getScoreColor(report.overall_style_score)}`}>
              {report.overall_style_score}/100
            </div>
            <p className="text-sm text-gray-600 mt-2">
              Based on completeness and clarity of analysis
            </p>
          </div>

          {/* Summary */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <Star className="w-5 h-5 text-yellow-500" />
              Your Style Summary
            </h3>
            <p className="text-gray-700 leading-relaxed">{report.summary}</p>
          </div>

          {/* Key Recommendations */}
          <div className="card bg-gradient-to-r from-purple-50 to-pink-50 border-purple-100">
            <h3 className="text-lg font-semibold mb-4">🎯 Key Recommendations</h3>
            <ul className="space-y-3">
              {report.key_recommendations.map((rec, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold">
                    {i + 1}
                  </span>
                  <span className="text-gray-700">{rec}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Color Analysis Section */}
          {report.sections.color_analysis?.status === 'success' && (
            <div className="card">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Palette className="w-5 h-5 text-blue-500" />
                Color Analysis
              </h3>
              <div className="grid md:grid-cols-3 gap-4 mb-4">
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <div
                    className="w-14 h-14 rounded-full mx-auto border-2 border-white shadow-md mb-2"
                    style={{ backgroundColor: report.sections.color_analysis.data.skin_tone.hex }}
                  />
                  <p className="text-sm font-medium">Skin: {report.sections.color_analysis.data.skin_tone.name}</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <div
                    className="w-14 h-14 rounded-full mx-auto border-2 border-white shadow-md mb-2"
                    style={{ backgroundColor: report.sections.color_analysis.data.hair_color.hex }}
                  />
                  <p className="text-sm font-medium">Hair: {report.sections.color_analysis.data.hair_color.name}</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <div
                    className="w-14 h-14 rounded-full mx-auto border-2 border-white shadow-md mb-2"
                    style={{ backgroundColor: report.sections.color_analysis.data.eye_color.hex }}
                  />
                  <p className="text-sm font-medium">Eyes: {report.sections.color_analysis.data.eye_color.name}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-4 text-sm">
                <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full font-medium">
                  {report.sections.color_analysis.data.sub_season}
                </span>
                <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full">
                  {report.sections.color_analysis.data.undertone} Undertone
                </span>
                <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
                  {report.sections.color_analysis.data.contrast_level} Contrast
                </span>
              </div>
            </div>
          )}

          {/* Face Shape Section */}
          {report.sections.face_shape?.status === 'success' && (
            <div className="card">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <User className="w-5 h-5 text-green-500" />
                Face Shape: {report.sections.face_shape.data.face_shape}
              </h3>
              <p className="text-gray-600 mb-3">{report.sections.face_shape.data.description}</p>
              <div className="flex flex-wrap gap-2">
                {report.sections.face_shape.data.characteristics.map((char, i) => (
                  <span key={i} className="text-xs bg-green-50 text-green-700 px-3 py-1 rounded-full">
                    {char}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Hairstyle Section */}
          {report.sections.hairstyle?.status === 'success' && (
            <div className="card">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Scissors className="w-5 h-5 text-pink-500" />
                Hairstyle Recommendations
              </h3>
              <div className="grid md:grid-cols-2 gap-3 mb-4">
                {report.sections.hairstyle.data.recommended_styles.slice(0, 4).map((style, i) => (
                  <div key={i} className="p-3 bg-pink-50 rounded-xl border border-pink-100">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-medium text-sm">{style.name}</h4>
                      <span className="text-xs bg-pink-200 text-pink-800 px-2 py-0.5 rounded-full">
                        {Math.round(style.suitability * 100)}%
                      </span>
                    </div>
                    <p className="text-xs text-gray-600">{style.description}</p>
                  </div>
                ))}
              </div>
              {report.sections.hairstyle.data.hair_color_suggestions && (
                <div>
                  <h4 className="font-medium text-sm mb-2">Hair Color Suggestions</h4>
                  <div className="flex flex-wrap gap-3">
                    {report.sections.hairstyle.data.hair_color_suggestions.map((color, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full border" style={{ backgroundColor: color.hex }} />
                        <span className="text-xs text-gray-600">{color.color}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Body Type Section */}
          {report.sections.body_type?.status === 'success' && (
            <div className="card">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <User className="w-5 h-5 text-orange-500" />
                Body Type: {report.sections.body_type.data.body_type}
              </h3>
              <p className="text-gray-600 mb-3">{report.sections.body_type.data.description}</p>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-sm text-green-700 mb-2 flex items-center gap-1">
                    <CheckCircle className="w-4 h-4" /> Best Styles
                  </h4>
                  <ul className="space-y-1">
                    {report.sections.body_type.data.best_styles.map((style, i) => (
                      <li key={i} className="text-sm text-gray-600 flex items-center gap-2">
                        <span className="text-green-500">•</span> {style}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-red-700 mb-2 flex items-center gap-1">
                    <XCircle className="w-4 h-4" /> Avoid
                  </h4>
                  <ul className="space-y-1">
                    {report.sections.body_type.data.avoid_styles.map((style, i) => (
                      <li key={i} className="text-sm text-gray-600 flex items-center gap-2">
                        <span className="text-red-500">•</span> {style}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Outfit Guidelines */}
          {report.sections.outfit_guidelines?.status === 'success' && (
            <div className="card">
              <h3 className="text-lg font-semibold mb-4">👗 Outfit Guidelines</h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {report.sections.outfit_guidelines.data.necklines?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Best Necklines</h4>
                    <div className="flex flex-wrap gap-1">
                      {report.sections.outfit_guidelines.data.necklines.map((n, i) => (
                        <span key={i} className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded">{n}</span>
                      ))}
                    </div>
                  </div>
                )}
                {report.sections.outfit_guidelines.data.silhouettes?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Best Silhouettes</h4>
                    <div className="flex flex-wrap gap-1">
                      {report.sections.outfit_guidelines.data.silhouettes.map((s, i) => (
                        <span key={i} className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded">{s}</span>
                      ))}
                    </div>
                  </div>
                )}
                {report.sections.outfit_guidelines.data.patterns?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Best Patterns</h4>
                    <div className="flex flex-wrap gap-1">
                      {report.sections.outfit_guidelines.data.patterns.map((p, i) => (
                        <span key={i} className="text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded">{p}</span>
                      ))}
                    </div>
                  </div>
                )}
                {report.sections.outfit_guidelines.data.fabrics?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Best Fabrics</h4>
                    <div className="flex flex-wrap gap-1">
                      {report.sections.outfit_guidelines.data.fabrics.map((f, i) => (
                        <span key={i} className="text-xs bg-orange-50 text-orange-700 px-2 py-1 rounded">{f}</span>
                      ))}
                    </div>
                  </div>
                )}
                {report.sections.outfit_guidelines.data.accessories?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Accessories</h4>
                    <div className="flex flex-wrap gap-1">
                      {report.sections.outfit_guidelines.data.accessories.map((a, i) => (
                        <span key={i} className="text-xs bg-yellow-50 text-yellow-700 px-2 py-1 rounded">{a}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default StyleReportPage
