import React, { useState } from 'react'
import { Scissors, Sparkles, Star, AlertTriangle } from 'lucide-react'
import ImageUpload from '../components/ImageUpload'
import { getHairstyleRecommendations } from '../services/api'

function HairstylePage() {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleUpload = (uploadedFile) => {
    setFile(uploadedFile)
    setPreview(URL.createObjectURL(uploadedFile))
    setResult(null)
    setError(null)
  }

  const handleAnalyze = async () => {
    if (!file) return
    setLoading(true)
    setError(null)

    const formData = new FormData()
    formData.append('file', file)

    try {
      const response = await getHairstyleRecommendations(formData)
      setResult(response.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Analysis failed. Please try a clearer photo.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Hairstyle Recommendations</h1>
        <p className="text-gray-600">Upload a selfie to discover hairstyles that flatter your face shape</p>
      </div>

      {/* Upload */}
      <div className="card mb-8">
        <ImageUpload onUpload={handleUpload} preview={preview} label="Upload your selfie" />
        {file && (
          <div className="mt-6 text-center">
            <button onClick={handleAnalyze} disabled={loading} className="btn-primary disabled:opacity-50">
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Analyzing...
                </span>
              ) : 'Find My Best Hairstyles'}
            </button>
          </div>
        )}
        {error && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">{error}</div>
        )}
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-6">
          {/* Face Shape Result */}
          <div className="card text-center">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-pink-100 to-purple-100 px-6 py-3 rounded-full mb-4">
              <Scissors className="w-5 h-5 text-pink-600" />
              <span className="text-lg font-semibold text-pink-700">
                {result.face_shape_analysis.face_shape} Face Shape
              </span>
            </div>
            <p className="text-gray-600">{result.face_shape_analysis.description}</p>
            <div className="flex flex-wrap justify-center gap-2 mt-3">
              {result.face_shape_analysis.characteristics.map((c, i) => (
                <span key={i} className="text-xs bg-gray-100 text-gray-600 px-3 py-1 rounded-full">{c}</span>
              ))}
            </div>
          </div>

          {/* Recommended Hairstyles */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Star className="w-5 h-5 text-yellow-500" />
              Recommended Hairstyles
            </h3>
            <p className="text-sm text-gray-500 mb-4">
              {result.hairstyle_recommendations.description}
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              {result.hairstyle_recommendations.recommended_styles.map((style, i) => (
                <div key={i} className="p-4 bg-gradient-to-br from-pink-50 to-purple-50 rounded-xl border border-pink-100">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-800">{style.name}</h4>
                    <div className="flex items-center gap-1">
                      <div className="w-full bg-gray-200 rounded-full h-2 w-16">
                        <div
                          className="bg-gradient-to-r from-pink-500 to-purple-500 h-2 rounded-full"
                          style={{ width: `${style.suitability * 100}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 ml-1">
                        {Math.round(style.suitability * 100)}%
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">{style.description}</p>
                  <span className="text-xs text-purple-600 mt-2 inline-block bg-purple-100 px-2 py-0.5 rounded">
                    {style.length}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Styles to Avoid */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" />
              Styles to Avoid
            </h3>
            <ul className="space-y-2">
              {result.hairstyle_recommendations.styles_to_avoid.map((style, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                  <span className="text-red-400 mt-0.5">✗</span>
                  {style}
                </li>
              ))}
            </ul>
          </div>

          {/* Styling Tips */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-500" />
              Styling Tips
            </h3>
            <ul className="space-y-2">
              {result.hairstyle_recommendations.styling_tips.map((tip, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                  <span className="text-purple-500">💡</span>
                  {tip}
                </li>
              ))}
            </ul>
          </div>

          {/* Hair Color Suggestions */}
          {result.hairstyle_recommendations.hair_color_suggestions?.length > 0 && (
            <div className="card">
              <h3 className="text-lg font-semibold mb-4">🎨 Hair Color Suggestions</h3>
              <div className="grid md:grid-cols-2 gap-3">
                {result.hairstyle_recommendations.hair_color_suggestions.map((color, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                    <div
                      className="w-12 h-12 rounded-full border-2 border-white shadow-md flex-shrink-0"
                      style={{ backgroundColor: color.hex }}
                    />
                    <div>
                      <p className="font-medium text-sm">{color.color}</p>
                      <p className="text-xs text-gray-500">{color.reason}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default HairstylePage
