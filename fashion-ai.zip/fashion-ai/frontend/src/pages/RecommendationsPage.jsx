import React, { useState, useEffect } from 'react'
import { Sparkles, Palette, Lightbulb, Heart } from 'lucide-react'
import ColorSwatch from '../components/ColorSwatch'
import { getRecommendations, getPersonalPalette, addToWishlist } from '../services/api'

function RecommendationsPage() {
  const [recommendations, setRecommendations] = useState(null)
  const [palette, setPalette] = useState(null)
  const [category, setCategory] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    loadData()
  }, [category])

  const loadData = async () => {
    setLoading(true)
    setError(null)
    try {
      const params = {}
      if (category) params.category = category

      const [recResponse, paletteResponse] = await Promise.all([
        getRecommendations(params),
        getPersonalPalette(),
      ])

      setRecommendations(recResponse.data)
      setPalette(paletteResponse.data)
    } catch (err) {
      if (err.response?.status === 404) {
        setError('Please complete a Color Analysis first to get personalized recommendations.')
      } else {
        setError('Failed to load recommendations.')
      }
    } finally {
      setLoading(false)
    }
  }

  const handleWishlist = async (itemId) => {
    try {
      await addToWishlist(itemId)
      alert('Added to wishlist!')
    } catch (err) {
      alert(err.response?.data?.detail || 'Failed to add')
    }
  }

  if (loading) {
    return (
      <div className="text-center py-20">
        <div className="animate-spin w-10 h-10 border-4 border-purple-200 border-t-purple-600 rounded-full mx-auto" />
        <p className="mt-4 text-gray-500">Loading your personalized recommendations...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="max-w-lg mx-auto text-center py-20">
        <Palette className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">No Color Profile Found</h2>
        <p className="text-gray-600 mb-6">{error}</p>
        <a href="/color-analysis" className="btn-primary">
          Start Color Analysis
        </a>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Recommended For You</h1>
        <p className="text-gray-600">
          Personalized picks based on your {palette?.sub_season} color profile
        </p>
      </div>

      {/* Personal Palette */}
      {palette && (
        <div className="card mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Palette className="w-5 h-5 text-purple-600" />
            <h3 className="text-lg font-semibold">Your Color Palette</h3>
            <span className="ml-auto text-sm bg-purple-100 text-purple-700 px-3 py-1 rounded-full">
              {palette.sub_season}
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {palette.palette.map((color, i) => (
              <div key={i} className="text-center">
                <div
                  className="w-full h-16 rounded-xl shadow-sm mb-2"
                  style={{ backgroundColor: color.hex }}
                />
                <p className="text-sm font-medium">{color.name}</p>
                <p className="text-xs text-gray-500">{color.use}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Category Filter */}
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {['', 'tops', 'bottoms', 'dresses', 'accessories'].map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`px-5 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors capitalize ${
              category === cat
                ? 'bg-purple-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-100 border'
            }`}
          >
            {cat || 'All Items'}
          </button>
        ))}
      </div>

      {/* Styling Tips */}
      {recommendations?.styling_tips && (
        <div className="card mb-8 bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-100">
          <div className="flex items-center gap-2 mb-3">
            <Lightbulb className="w-5 h-5 text-yellow-600" />
            <h3 className="font-semibold">Styling Tips</h3>
          </div>
          <ul className="space-y-2">
            {recommendations.styling_tips.map((tip, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                <Sparkles className="w-4 h-4 text-yellow-500 flex-shrink-0 mt-0.5" />
                {tip}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Recommended Items */}
      {recommendations?.items && recommendations.items.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {recommendations.items.map((item) => (
            <div key={item.id} className="card p-4 group relative">
              {/* Match Score Badge */}
              <div className="absolute top-6 left-6 z-10">
                <div className={`text-xs px-2 py-1 rounded-full font-medium ${
                  item.match_score >= 0.7 ? 'bg-green-500 text-white' :
                  item.match_score >= 0.4 ? 'bg-yellow-500 text-white' :
                  'bg-gray-400 text-white'
                }`}>
                  {Math.round(item.match_score * 100)}% match
                </div>
              </div>

              {/* Wishlist */}
              <button
                onClick={() => handleWishlist(item.id)}
                className="absolute top-6 right-6 z-10 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label={`Add ${item.name} to wishlist`}
              >
                <Heart className="w-4 h-4 text-pink-500" />
              </button>

              {/* Color Display */}
              <div className="aspect-square bg-gray-50 rounded-xl mb-3 flex items-center justify-center">
                <div
                  className="w-20 h-20 rounded-full shadow-lg"
                  style={{ backgroundColor: item.color_hex }}
                />
              </div>

              <h3 className="font-medium text-sm mb-1">{item.name}</h3>
              <div className="flex items-center justify-between">
                <span className="text-purple-600 font-semibold">${item.price}</span>
                <span className="text-xs text-gray-500 capitalize">{item.category}</span>
              </div>
              <p className="text-xs text-gray-400 mt-1 line-clamp-2">{item.description}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-500">No matching items found for this category.</p>
        </div>
      )}
    </div>
  )
}

export default RecommendationsPage
