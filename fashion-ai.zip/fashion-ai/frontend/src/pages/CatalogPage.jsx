import React, { useState, useEffect } from 'react'
import { Search, Filter, Heart, ShoppingBag } from 'lucide-react'
import { getCatalogItems, addToWishlist } from '../services/api'
import { getToken } from '../services/auth'

function CatalogPage() {
  const [items, setItems] = useState([])
  const [category, setCategory] = useState('')
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)

  const categories = ['', 'tops', 'bottoms', 'dresses', 'accessories']

  useEffect(() => {
    loadItems()
  }, [category])

  const loadItems = async () => {
    setLoading(true)
    try {
      const params = {}
      if (category) params.category = category
      if (search) params.search = search
      const response = await getCatalogItems(params)
      setItems(response.data)
    } catch (err) {
      console.error('Failed to load catalog:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e) => {
    e.preventDefault()
    loadItems()
  }

  const handleWishlist = async (itemId) => {
    if (!getToken()) {
      alert('Please login to add items to wishlist')
      return
    }
    try {
      await addToWishlist(itemId)
      alert('Added to wishlist!')
    } catch (err) {
      alert(err.response?.data?.detail || 'Failed to add to wishlist')
    }
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Clothing Catalog</h1>
        <p className="text-gray-600">Browse our collection — items are scored based on your color profile</p>
      </div>

      {/* Filters */}
      <div className="card mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <form onSubmit={handleSearch} className="flex-1 flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search items..."
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-200 focus:border-purple-400 outline-none"
              />
            </div>
            <button type="submit" className="btn-primary py-2 px-4 text-sm">
              Search
            </button>
          </form>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors capitalize ${
                  category === cat
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {cat || 'All'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Items Grid */}
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin w-8 h-8 border-4 border-purple-200 border-t-purple-600 rounded-full mx-auto" />
          <p className="mt-4 text-gray-500">Loading catalog...</p>
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-12">
          <ShoppingBag className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No items found. Try a different filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {items.map((item) => (
            <div key={item.id} className="card p-4 group">
              {/* Color Indicator */}
              <div className="relative mb-3">
                <div className="aspect-square bg-gray-100 rounded-xl flex items-center justify-center overflow-hidden">
                  <div
                    className="w-full h-full flex items-center justify-center"
                    style={{ backgroundColor: item.color_hex + '20' }}
                  >
                    <div
                      className="w-24 h-24 rounded-full shadow-lg"
                      style={{ backgroundColor: item.color_hex }}
                    />
                  </div>
                </div>
                {/* Wishlist Button */}
                <button
                  onClick={() => handleWishlist(item.id)}
                  className="absolute top-2 right-2 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md opacity-0 group-hover:opacity-100 transition-opacity hover:bg-pink-50"
                  aria-label={`Add ${item.name} to wishlist`}
                >
                  <Heart className="w-4 h-4 text-pink-500" />
                </button>

                {/* Match Score */}
                {item.match_score !== undefined && item.match_score !== null && (
                  <div className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                    {Math.round(item.match_score * 100)}% match
                  </div>
                )}
              </div>

              {/* Item Info */}
              <h3 className="font-medium text-sm mb-1 truncate">{item.name}</h3>
              <div className="flex items-center justify-between">
                <span className="text-purple-600 font-semibold">${item.price}</span>
                <div className="flex items-center gap-1">
                  <div
                    className="w-4 h-4 rounded-full border border-gray-200"
                    style={{ backgroundColor: item.color_hex }}
                  />
                  <span className="text-xs text-gray-500">{item.color_name}</span>
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-1 capitalize">{item.category}</p>

              {/* Tags */}
              {item.tags && item.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-2">
                  {item.tags.slice(0, 2).map((tag, i) => (
                    <span key={i} className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default CatalogPage
