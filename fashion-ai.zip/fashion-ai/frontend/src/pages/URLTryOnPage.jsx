import React, { useState } from 'react'
import { Link2, ShoppingBag, ExternalLink, Wand2 } from 'lucide-react'
import ImageUpload from '../components/ImageUpload'
import { scrapeProductUrl, tryOnUpload } from '../services/api'

function URLTryOnPage() {
  const [url, setUrl] = useState('')
  const [productData, setProductData] = useState(null)
  const [userPhoto, setUserPhoto] = useState(null)
  const [userPreview, setUserPreview] = useState(null)
  const [tryOnResult, setTryOnResult] = useState(null)
  const [loadingScrape, setLoadingScrape] = useState(false)
  const [loadingTryOn, setLoadingTryOn] = useState(false)
  const [error, setError] = useState(null)

  const handleScrape = async () => {
    if (!url.trim()) return
    setLoadingScrape(true)
    setError(null)
    setProductData(null)

    try {
      const response = await scrapeProductUrl(url)
      setProductData(response.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to extract product from URL')
    } finally {
      setLoadingScrape(false)
    }
  }

  const handleUserUpload = (file) => {
    setUserPhoto(file)
    setUserPreview(URL.createObjectURL(file))
    setTryOnResult(null)
  }

  const handleTryOn = async () => {
    if (!userPhoto || !productData?.local_image_path) return
    setLoadingTryOn(true)

    const formData = new FormData()
    formData.append('user_photo', userPhoto)

    // Fetch the scraped image as a blob and append
    try {
      const imgResponse = await fetch(`http://localhost:8000/${productData.local_image_path}`)
      const blob = await imgResponse.blob()
      formData.append('clothing_photo', blob, 'clothing.jpg')
      formData.append('category', 'tops')

      const response = await tryOnUpload(formData)
      setTryOnResult(response.data)
    } catch (err) {
      setError('Try-on failed. The extracted image may not be suitable.')
    } finally {
      setLoadingTryOn(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Try On from URL</h1>
        <p className="text-gray-600">Paste a product URL from any shopping website to extract and virtually try on the item</p>
      </div>

      {/* URL Input */}
      <div className="card mb-8">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Link2 className="w-5 h-5 text-blue-500" />
          Product URL
        </h3>
        <div className="flex gap-3">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://www.example.com/product/blue-dress"
            className="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-200 focus:border-purple-400 outline-none"
          />
          <button
            onClick={handleScrape}
            disabled={!url.trim() || loadingScrape}
            className="btn-primary disabled:opacity-50 whitespace-nowrap"
          >
            {loadingScrape ? 'Extracting...' : 'Extract Product'}
          </button>
        </div>
        <p className="text-xs text-gray-400 mt-2">
          Supports most e-commerce websites (Amazon, Zara, H&M, ASOS, etc.)
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">
          {error}
        </div>
      )}

      {/* Extracted Product */}
      {productData && (
        <div className="card mb-8">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-green-500" />
            Extracted Product
          </h3>
          <div className="flex flex-col md:flex-row gap-6">
            {productData.image_url && (
              <div className="flex-shrink-0">
                <img
                  src={productData.image_url}
                  alt={productData.title}
                  className="w-48 h-48 object-cover rounded-xl shadow-md"
                  onError={(e) => { e.target.style.display = 'none' }}
                />
              </div>
            )}
            <div className="flex-1">
              <h4 className="text-lg font-medium mb-2">{productData.title}</h4>
              {productData.price && (
                <p className="text-purple-600 font-semibold text-lg mb-2">{productData.price}</p>
              )}
              {productData.color && (
                <p className="text-sm text-gray-600 mb-2">Color: <strong>{productData.color}</strong></p>
              )}
              {productData.description && (
                <p className="text-sm text-gray-500 line-clamp-3">{productData.description}</p>
              )}
              <a
                href={productData.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-sm text-blue-600 hover:underline mt-3"
              >
                View on website <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Virtual Try-On with extracted product */}
      {productData?.local_image_path && (
        <div className="card mb-8">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-purple-500" />
            Try It On
          </h3>
          <p className="text-sm text-gray-500 mb-4">Upload your full-body photo to see how this item looks on you</p>
          <ImageUpload onUpload={handleUserUpload} preview={userPreview} label="Upload your full-body photo" />

          {userPhoto && (
            <div className="mt-6 text-center">
              <button
                onClick={handleTryOn}
                disabled={loadingTryOn}
                className="btn-primary disabled:opacity-50 inline-flex items-center gap-2"
              >
                {loadingTryOn ? (
                  <>
                    <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    Processing...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-5 h-5" />
                    Virtual Try-On
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Try-On Result */}
      {tryOnResult && (
        <div className="card">
          <h3 className="text-xl font-semibold mb-4 text-center">Try-On Result</h3>
          <div className="text-center">
            <img
              src={`http://localhost:8000${tryOnResult.result_image_url}`}
              alt="Try-on result"
              className="max-h-96 mx-auto rounded-xl shadow-md"
            />
          </div>
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="bg-green-50 rounded-xl p-3 text-center">
              <p className="text-sm text-green-600">Fit Score</p>
              <p className="text-xl font-bold text-green-700">{Math.round(tryOnResult.fit_score * 100)}%</p>
            </div>
            <div className="bg-purple-50 rounded-xl p-3 text-center">
              <p className="text-sm text-purple-600">Color Match</p>
              <p className="text-xl font-bold text-purple-700">{Math.round(tryOnResult.color_match_score * 100)}%</p>
            </div>
          </div>
        </div>
      )}

      {/* Supported Sites Info */}
      <div className="mt-8 card bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-100">
        <h3 className="font-semibold mb-3">How It Works</h3>
        <ol className="space-y-2 text-sm text-gray-600 list-decimal list-inside">
          <li>Paste a product URL from any clothing website</li>
          <li>Our AI extracts the product image, title, price, and color</li>
          <li>Upload your full-body photo</li>
          <li>See the clothing virtually overlaid on your body</li>
        </ol>
        <p className="text-xs text-gray-400 mt-4">
          Works best with sites that use standard product metadata (og:image tags). 
          Results vary by website structure.
        </p>
      </div>
    </div>
  )
}

export default URLTryOnPage
