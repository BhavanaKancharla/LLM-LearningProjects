import React, { useState } from 'react'
import { User, CheckCircle, XCircle, BarChart3 } from 'lucide-react'
import ImageUpload from '../components/ImageUpload'
import { analyzeBodyType } from '../services/api'

function BodyAnalysisPage() {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleUpload = (uploadedFile) => {
    setFile(uploadedFile)
    setPreview(URL.createObjectURL(uploadedFile))
    setResult(null)
    setError(null)
  }

  const handleAnalyze = async () => {
    if (!file) return
    setLoading(true)
    setError(null)

    const formData = new FormData()
    formData.append('file', file)

    try {
      const response = await analyzeBodyType(formData)
      setResult(response.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Analysis failed. Please upload a clear full-body photo.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Body Type Analysis</h1>
        <p className="text-gray-600">Upload a full-body photo to discover your body type and best clothing styles</p>
      </div>

      {/* Upload */}
      <div className="card mb-8">
        <ImageUpload onUpload={handleUpload} preview={preview} label="Upload full-body photo" />
        {file && (
          <div className="mt-6 text-center">
            <button onClick={handleAnalyze} disabled={loading} className="btn-primary disabled:opacity-50">
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Analyzing...
                </span>
              ) : 'Analyze Body Type'}
            </button>
          </div>
        )}
        {error && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">{error}</div>
        )}
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-6">
          {/* Body Type Badge */}
          <div className="card text-center">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-100 to-yellow-100 px-6 py-3 rounded-full mb-4">
              <User className="w-5 h-5 text-orange-600" />
              <span className="text-lg font-semibold text-orange-700">
                {result.body_type}
              </span>
            </div>
            <p className="text-gray-600 max-w-md mx-auto">{result.description}</p>
            <div className="flex flex-wrap justify-center gap-2 mt-4">
              {result.characteristics.map((c, i) => (
                <span key={i} className="text-xs bg-orange-50 text-orange-700 px-3 py-1 rounded-full border border-orange-200">
                  {c}
                </span>
              ))}
            </div>
          </div>

          {/* Proportions */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-500" />
              Body Proportions
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {Object.entries(result.proportions).map(([key, value]) => (
                <div key={key} className="text-center p-3 bg-blue-50 rounded-xl">
                  <p className="text-2xl font-bold text-blue-700">{value}</p>
                  <p className="text-xs text-gray-500 mt-1 capitalize">
                    {key.replace(/_/g, ' ')}
                  </p>
                </div>
              ))}
            </div>
            <div className="mt-4 text-center">
              <span className="text-sm text-gray-500">
                Confidence: <strong className="text-blue-600">{Math.round(result.confidence * 100)}%</strong>
              </span>
            </div>
          </div>

          {/* Best Styles */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-green-700">
              <CheckCircle className="w-5 h-5" />
              Best Clothing Styles for {result.body_type}
            </h3>
            <div className="grid md:grid-cols-2 gap-3">
              {result.best_styles.map((style, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-green-50 rounded-xl border border-green-100">
                  <span className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center flex-shrink-0 text-xs">
                    ✓
                  </span>
                  <span className="text-sm text-gray-700">{style}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Styles to Avoid */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-red-700">
              <XCircle className="w-5 h-5" />
              Styles to Avoid
            </h3>
            <div className="space-y-2">
              {result.avoid_styles.map((style, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-red-50 rounded-xl border border-red-100">
                  <span className="w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center flex-shrink-0 text-xs">
                    ✗
                  </span>
                  <span className="text-sm text-gray-700">{style}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Body Types Info */}
          <div className="card bg-gray-50">
            <h3 className="font-semibold mb-3">All Body Types</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {['Hourglass', 'Pear', 'Apple', 'Rectangle', 'Inverted Triangle'].map((type) => (
                <div
                  key={type}
                  className={`text-center p-3 rounded-xl text-sm ${
                    type === result.body_type
                      ? 'bg-orange-500 text-white font-medium'
                      : 'bg-white text-gray-600 border'
                  }`}
                >
                  {type}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tips */}
      <div className="mt-8 card bg-gradient-to-r from-orange-50 to-yellow-50 border-orange-100">
        <h3 className="font-semibold mb-3">Tips for Best Results</h3>
        <ul className="space-y-2 text-sm text-gray-600">
          <li>• Stand straight with arms slightly away from your body</li>
          <li>• Wear fitted clothing (not baggy) for accurate detection</li>
          <li>• Use a plain background with good lighting</li>
          <li>• Face the camera directly, full front view</li>
          <li>• Include your full body from head to feet</li>
        </ul>
      </div>
    </div>
  )
}

export default BodyAnalysisPage
