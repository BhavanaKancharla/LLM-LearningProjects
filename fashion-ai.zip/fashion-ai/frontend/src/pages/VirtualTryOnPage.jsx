import React, { useState, useEffect } from 'react'
import { Wand2, ArrowRight } from 'lucide-react'
import ImageUpload from '../components/ImageUpload'
import { tryOnUpload, getCatalogItems } from '../services/api'

function VirtualTryOnPage() {
  const [userPhoto, setUserPhoto] = useState(null)
  const [userPreview, setUserPreview] = useState(null)
  const [clothingPhoto, setClothingPhoto] = useState(null)
  const [clothingPreview, setClothingPreview] = useState(null)
  const [category, setCategory] = useState('tops')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleUserUpload = (file) => {
    setUserPhoto(file)
    setUserPreview(URL.createObjectURL(file))
    setResult(null)
  }

  const handleClothingUpload = (file) => {
    setClothingPhoto(file)
    setClothingPreview(URL.createObjectURL(file))
    setResult(null)
  }

  const handleTryOn = async () => {
    if (!userPhoto || !clothingPhoto) return

    setLoading(true)
    setError(null)

    const formData = new FormData()
    formData.append('user_photo', userPhoto)
    formData.append('clothing_photo', clothingPhoto)
    formData.append('category', category)

    try {
      const response = await tryOnUpload(formData)
      setResult(response.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Try-on failed. Please ensure a clear full-body photo.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Virtual Try-On</h1>
        <p className="text-gray-600">See how clothes look on you with AI body detection</p>
      </div>

      {/* Upload Section */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* User Photo */}
        <div className="card">
          <h3 className="font-semibold mb-3">Your Photo</h3>
          <p className="text-sm text-gray-500 mb-4">Upload a clear, full-body photo</p>
          <ImageUpload
            onUpload={handleUserUpload}
            preview={userPreview}
            label="Upload full-body photo"
          />
        </div>

        {/* Clothing Photo */}
        <div className="card">
          <h3 className="font-semibold mb-3">Clothing Item</h3>
          <p className="text-sm text-gray-500 mb-4">Upload the clothing image (transparent bg works best)</p>
          <ImageUpload
            onUpload={handleClothingUpload}
            preview={clothingPreview}
            label="Upload clothing image"
          />
        </div>
      </div>

      {/* Category Selection */}
      <div className="card mb-8">
        <h3 className="font-semibold mb-3">Clothing Category</h3>
        <div className="flex gap-3">
          {['tops', 'bottoms', 'dresses'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-5 py-2 rounded-lg text-sm font-medium transition-colors capitalize ${
                category === cat
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Try-On Button */}
      <div className="text-center mb-8">
        <button
          onClick={handleTryOn}
          disabled={!userPhoto || !clothingPhoto || loading}
          className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center gap-2 text-lg px-8 py-4"
        >
          {loading ? (
            <>
              <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Processing...
            </>
          ) : (
            <>
              <Wand2 className="w-5 h-5" />
              Try It On!
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="max-w-lg mx-auto mb-8 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">
          {error}
        </div>
      )}

      {/* Result */}
      {result && (
        <div className="card">
          <h3 className="text-xl font-semibold mb-4 text-center">Try-On Result</h3>

          <div className="flex flex-col md:flex-row items-center gap-6">
            {/* Before */}
            <div className="text-center flex-1">
              <p className="text-sm text-gray-500 mb-2">Original</p>
              <img
                src={userPreview}
                alt="Original"
                className="max-h-80 mx-auto rounded-xl shadow-md"
              />
            </div>

            <ArrowRight className="w-8 h-8 text-purple-400 hidden md:block" />

            {/* After */}
            <div className="text-center flex-1">
              <p className="text-sm text-gray-500 mb-2">With Clothing</p>
              <img
                src={`http://localhost:8000${result.result_image_url}`}
                alt="Try-on result"
                className="max-h-80 mx-auto rounded-xl shadow-md"
              />
            </div>
          </div>

          {/* Scores */}
          <div className="mt-6 grid grid-cols-2 gap-4">
            <div className="bg-green-50 rounded-xl p-4 text-center">
              <p className="text-sm text-green-600 mb-1">Fit Confidence</p>
              <p className="text-2xl font-bold text-green-700">
                {Math.round(result.fit_score * 100)}%
              </p>
            </div>
            <div className="bg-purple-50 rounded-xl p-4 text-center">
              <p className="text-sm text-purple-600 mb-1">Color Match</p>
              <p className="text-2xl font-bold text-purple-700">
                {Math.round(result.color_match_score * 100)}%
              </p>
            </div>
          </div>

          {/* Suggestions */}
          {result.suggestions && result.suggestions.length > 0 && (
            <div className="mt-6">
              <h4 className="font-medium mb-3">Styling Suggestions</h4>
              <ul className="space-y-2">
                {result.suggestions.map((tip, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                    <span className="text-purple-500 mt-0.5">•</span>
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Tips */}
      <div className="mt-8 card bg-gradient-to-r from-purple-50 to-pink-50 border-purple-100">
        <h3 className="font-semibold mb-3">Tips for Best Results</h3>
        <ul className="space-y-2 text-sm text-gray-600">
          <li>• Stand straight facing the camera with arms slightly away from body</li>
          <li>• Use a plain, uncluttered background</li>
          <li>• Good lighting without harsh shadows</li>
          <li>• Clothing images with transparent backgrounds work best</li>
          <li>• Front-facing clothing photos give the most realistic overlay</li>
        </ul>
      </div>
    </div>
  )
}

export default VirtualTryOnPage
