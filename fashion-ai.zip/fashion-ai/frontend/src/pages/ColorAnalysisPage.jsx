import React, { useState } from 'react'
import { Palette, Sun, Moon, Contrast, Lightbulb } from 'lucide-react'
import ImageUpload from '../components/ImageUpload'
import ColorSwatch from '../components/ColorSwatch'
import { analyzeColors } from '../services/api'

function ColorAnalysisPage() {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleUpload = (uploadedFile) => {
    setFile(uploadedFile)
    setPreview(URL.createObjectURL(uploadedFile))
    setResult(null)
    setError(null)
  }

  const handleAnalyze = async () => {
    if (!file) return

    setLoading(true)
    setError(null)

    const formData = new FormData()
    formData.append('file', file)

    try {
      const response = await analyzeColors(formData)
      setResult(response.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Analysis failed. Please try with a clearer photo.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Personal Color Analysis</h1>
        <p className="text-gray-600">Upload a clear face photo to discover your color season</p>
      </div>

      {/* Upload Section */}
      <div className="card mb-8">
        <ImageUpload
          onUpload={handleUpload}
          preview={preview}
          label="Upload your selfie"
        />

        {file && (
          <div className="mt-6 text-center">
            <button
              onClick={handleAnalyze}
              disabled={loading}
              className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Analyzing...
                </span>
              ) : (
                'Analyze My Colors'
              )}
            </button>
          </div>
        )}

        {error && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">
            {error}
          </div>
        )}
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-6 animate-in fade-in">
          {/* Season Badge */}
          <div className="card text-center">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-100 to-pink-100 px-6 py-3 rounded-full mb-4">
              <Palette className="w-5 h-5 text-purple-600" />
              <span className="text-lg font-semibold text-purple-700">
                {result.sub_season}
              </span>
            </div>
            <h2 className="text-2xl font-bold mb-2">You are a {result.season}!</h2>
            <div className="flex justify-center gap-6 mt-4">
              <div className="flex items-center gap-2">
                <Sun className="w-4 h-4 text-orange-500" />
                <span className="text-sm">{result.undertone} Undertone</span>
              </div>
              <div className="flex items-center gap-2">
                <Contrast className="w-4 h-4 text-gray-600" />
                <span className="text-sm">{result.contrast_level} Contrast</span>
              </div>
            </div>
          </div>

          {/* Detected Colors */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">Your Colors</h3>
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center">
                <div
                  className="w-20 h-20 rounded-full mx-auto border-4 border-white shadow-lg mb-2"
                  style={{ backgroundColor: result.skin_tone.hex }}
                />
                <p className="font-medium">Skin Tone</p>
                <p className="text-sm text-gray-500">{result.skin_tone.name}</p>
                <p className="text-xs text-gray-400">{result.skin_tone.hex}</p>
              </div>
              <div className="text-center">
                <div
                  className="w-20 h-20 rounded-full mx-auto border-4 border-white shadow-lg mb-2"
                  style={{ backgroundColor: result.hair_color.hex }}
                />
                <p className="font-medium">Hair Color</p>
                <p className="text-sm text-gray-500">{result.hair_color.name}</p>
                <p className="text-xs text-gray-400">{result.hair_color.hex}</p>
              </div>
              <div className="text-center">
                <div
                  className="w-20 h-20 rounded-full mx-auto border-4 border-white shadow-lg mb-2"
                  style={{ backgroundColor: result.eye_color.hex }}
                />
                <p className="font-medium">Eye Color</p>
                <p className="text-sm text-gray-500">{result.eye_color.name}</p>
                <p className="text-xs text-gray-400">{result.eye_color.hex}</p>
              </div>
            </div>
          </div>

          {/* Recommended Colors */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4 text-green-700">✓ Your Best Colors</h3>
            <div className="flex flex-wrap gap-3">
              {result.recommended_colors.map((color, i) => (
                <ColorSwatch key={i} color={color.hex} name={color.name} />
              ))}
            </div>
          </div>

          {/* Colors to Avoid */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4 text-red-700">✗ Colors to Avoid</h3>
            <div className="flex flex-wrap gap-3">
              {result.avoid_colors.map((color, i) => (
                <ColorSwatch key={i} color={color.hex} name={color.name} />
              ))}
            </div>
          </div>

          {/* Style Tips */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-yellow-500" />
              Style Tips
            </h3>
            <ul className="space-y-3">
              {result.style_tips.map((tip, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="w-6 h-6 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-medium mt-0.5">
                    {i + 1}
                  </span>
                  <span className="text-gray-700">{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}

export default ColorAnalysisPage
