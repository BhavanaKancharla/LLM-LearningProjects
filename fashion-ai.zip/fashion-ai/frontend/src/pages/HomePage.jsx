import React from 'react'
import { Link } from 'react-router-dom'
import { Sparkles, Camera, Palette, ShoppingBag, Wand2, Scissors, User, FileText, Link2 } from 'lucide-react'

function HomePage() {
  const features = [
    {
      icon: <FileText className="w-8 h-8" />,
      title: 'Full Style Report',
      description: 'Complete analysis combining face shape, body type, color season, hairstyle advice, and outfit guidelines in one report.',
      link: '/style-report',
      color: 'from-indigo-500 to-purple-500',
    },
    {
      icon: <Camera className="w-8 h-8" />,
      title: 'Color Analysis',
      description: 'AI analyzes your skin tone, hair, and eye color to determine your seasonal color type and recommend a personalized palette.',
      link: '/color-analysis',
      color: 'from-blue-500 to-cyan-400',
    },
    {
      icon: <Scissors className="w-8 h-8" />,
      title: 'Hairstyle Advisor',
      description: 'Detects your face shape and recommends flattering hairstyles and hair colors based on your features.',
      link: '/hairstyle',
      color: 'from-pink-500 to-rose-400',
    },
    {
      icon: <User className="w-8 h-8" />,
      title: 'Body Type Analysis',
      description: 'Identifies your body proportions and suggests clothing silhouettes, necklines, and styles that flatter your figure.',
      link: '/body-analysis',
      color: 'from-orange-500 to-yellow-400',
    },
    {
      icon: <Wand2 className="w-8 h-8" />,
      title: 'Virtual Try-On',
      description: 'Upload your photo and a clothing image to see how it looks on you using AI body detection and overlay.',
      link: '/try-on',
      color: 'from-purple-500 to-pink-400',
    },
    {
      icon: <Link2 className="w-8 h-8" />,
      title: 'Try-On from URL',
      description: 'Paste a product link from any shopping site — we extract the item and let you virtually try it on.',
      link: '/url-tryon',
      color: 'from-teal-500 to-emerald-400',
    },
    {
      icon: <Palette className="w-8 h-8" />,
      title: 'Smart Recommendations',
      description: 'Get personalized outfit suggestions with match scores based on your unique color profile.',
      link: '/recommendations',
      color: 'from-amber-500 to-orange-400',
    },
    {
      icon: <ShoppingBag className="w-8 h-8" />,
      title: 'Curated Catalog',
      description: 'Browse our collection with AI-powered compatibility scoring for each item.',
      link: '/catalog',
      color: 'from-green-500 to-emerald-400',
    },
  ]

  return (
    <div className="max-w-6xl mx-auto">
      {/* Hero Section */}
      <section className="text-center py-16 md:py-24">
        <div className="inline-flex items-center gap-2 bg-purple-100 text-purple-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
          <Sparkles className="w-4 h-4" />
          AI-Powered Personalized Fashion Advisor
        </div>
        <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
          Your AI
          <span className="bg-gradient-to-r from-purple-600 to-pink-500 bg-clip-text text-transparent">
            {' '}Style Advisor
          </span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-10">
          Comprehensive fashion analysis combining face shape, body type, color theory, and AI virtual try-on
          to give you personalized style recommendations.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/style-report" className="btn-primary text-lg px-8 py-4">
            Get Full Style Report
          </Link>
          <Link to="/catalog" className="btn-secondary text-lg px-8 py-4">
            Browse Catalog
          </Link>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16">
        <h2 className="text-3xl font-bold text-center mb-4">How It Works</h2>
        <p className="text-gray-600 text-center mb-12 max-w-xl mx-auto">
          Upload your photos and get a complete personalized style analysis
        </p>

        <div className="grid md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-purple-600">1</span>
            </div>
            <h3 className="font-semibold text-lg mb-2">Upload Photos</h3>
            <p className="text-sm text-gray-600">Face selfie + full-body photo for complete analysis</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-pink-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-pink-600">2</span>
            </div>
            <h3 className="font-semibold text-lg mb-2">AI Analyzes You</h3>
            <p className="text-sm text-gray-600">Face shape, body type, colors, undertone & contrast</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-orange-600">3</span>
            </div>
            <h3 className="font-semibold text-lg mb-2">Get Your Report</h3>
            <p className="text-sm text-gray-600">Style score, outfit guidelines, hairstyle advice</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-green-600">4</span>
            </div>
            <h3 className="font-semibold text-lg mb-2">Virtual Try-On</h3>
            <p className="text-sm text-gray-600">Try clothes on your avatar before you buy</p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16">
        <h2 className="text-3xl font-bold text-center mb-12">All Features</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((feature, index) => (
            <Link
              key={index}
              to={feature.link}
              className="card group hover:scale-[1.02] transition-transform duration-200 p-5"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-white mb-3`}>
                {feature.icon}
              </div>
              <h3 className="text-base font-semibold mb-1 group-hover:text-purple-600 transition-colors">
                {feature.title}
              </h3>
              <p className="text-sm text-gray-500">{feature.description}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-16">
        <h2 className="text-3xl font-bold text-center mb-4">Powered By AI/ML</h2>
        <p className="text-gray-600 text-center mb-8">Advanced computer vision and machine learning techniques</p>
        <div className="flex flex-wrap justify-center gap-3">
          {[
            'MediaPipe Face Mesh', 'MediaPipe Pose', 'K-Means Clustering',
            'CIE Lab Color Space', 'Body Segmentation', 'OpenCV',
            'Color Theory', 'Pose Estimation', 'Alpha Compositing',
            'Web Scraping', 'Style Classification'
          ].map((tech) => (
            <span key={tech} className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm text-gray-600">
              {tech}
            </span>
          ))}
        </div>
      </section>
    </div>
  )
}

export default HomePage
