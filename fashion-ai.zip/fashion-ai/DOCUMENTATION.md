# AI-Powered Personalized Fashion Advisor
## Project Documentation

---

## 1. Project Overview

**Title:** AI-Powered Personalized Fashion Advisor with Virtual Try-On and Style Recommendation

**Description:** An end-to-end AI/ML web application that analyzes users' facial features, body proportions, and personal coloring to recommend hairstyles, clothing styles, and colors — with a virtual try-on experience.

**Key Features:**
- Personal Color Analysis (12 seasonal sub-types)
- Face Shape Detection (6 shapes)
- Body Type Classification (5 types)
- Hairstyle Recommendations
- Virtual Try-On
- Product URL Extraction
- Comprehensive Style Report
- Smart Outfit Recommendations

---

## 2. System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    CLIENT (Browser)                           │
│                  React 18 + Tailwind CSS                      │
│                  Vite Dev Server                              │
│              http://localhost:3000                            │
└─────────────────────┬───────────────────────────────────────┘
                      │ HTTP REST API (Axios)
                      │ JWT Authentication
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                    SERVER (Backend)                           │
│                  Python 3.10 + FastAPI                        │
│              http://localhost:8000                            │
│                                                              │
│  ┌──────────┐  ┌──────────┐  ┌────────────────────────┐    │
│  │   Auth   │  │ Catalog  │  │     ML Services        │    │
│  │  (JWT)   │  │  (CRUD)  │  │ (OpenCV + scikit-learn)│    │
│  └──────────┘  └──────────┘  └────────────────────────┘    │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              SQLite Database                           │   │
│  │   Users | ColorProfiles | CatalogItems | Wishlist     │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Complete Folder Structure

```
fashion-ai/
│
├── backend/                                 # Python FastAPI Server
│   │
│   ├── app/                                 # Application package
│   │   ├── __init__.py                      # Package marker
│   │   ├── main.py                          # FastAPI app entry point
│   │   │                                    #   - CORS middleware
│   │   │                                    #   - Route registration
│   │   │                                    #   - Static file mounting
│   │   │
│   │   ├── api/                             # REST API Route Handlers
│   │   │   ├── __init__.py
│   │   │   ├── auth.py                      # Authentication endpoints
│   │   │   │                                #   POST /api/auth/register
│   │   │   │                                #   POST /api/auth/login
│   │   │   │                                #   GET  /api/auth/me
│   │   │   │
│   │   │   ├── color_analysis.py            # Color analysis endpoints
│   │   │   │                                #   POST /api/color-analysis/analyze
│   │   │   │                                #   GET  /api/color-analysis/profile
│   │   │   │
│   │   │   ├── face_shape.py               # Face shape endpoints
│   │   │   │                                #   POST /api/face-shape/analyze
│   │   │   │
│   │   │   ├── body_type.py                # Body type endpoints
│   │   │   │                                #   POST /api/body-type/analyze
│   │   │   │
│   │   │   ├── hairstyle.py                # Hairstyle recommendation endpoints
│   │   │   │                                #   POST /api/hairstyle/recommend
│   │   │   │                                #   GET  /api/hairstyle/by-shape
│   │   │   │
│   │   │   ├── virtual_tryon.py            # Virtual try-on endpoints
│   │   │   │                                #   POST /api/tryon/try-on
│   │   │   │                                #   POST /api/tryon/try-on-upload
│   │   │   │
│   │   │   ├── recommendations.py          # Recommendation endpoints
│   │   │   │                                #   GET  /api/recommendations/get
│   │   │   │                                #   GET  /api/recommendations/palette
│   │   │   │
│   │   │   ├── catalog.py                  # Catalog & wishlist endpoints
│   │   │   │                                #   GET  /api/catalog/items
│   │   │   │                                #   GET  /api/catalog/items/{id}
│   │   │   │                                #   POST /api/catalog/wishlist/{id}
│   │   │   │                                #   GET  /api/catalog/wishlist
│   │   │   │
│   │   │   ├── url_scraper.py              # URL scraping endpoints
│   │   │   │                                #   POST /api/scraper/extract
│   │   │   │
│   │   │   └── style_report.py             # Style report endpoints
│   │   │                                    #   POST /api/style-report/generate
│   │   │                                    #   POST /api/style-report/evaluate-outfit
│   │   │
│   │   ├── services/                        # Business Logic & ML Pipelines
│   │   │   ├── __init__.py
│   │   │   │
│   │   │   ├── color_analysis_service.py    # COLOR ANALYSIS ML SERVICE
│   │   │   │   Functions:
│   │   │   │   - analyze(image_path) → Dict
│   │   │   │   - _extract_skin_color() → RGB array
│   │   │   │   - _extract_hair_color() → RGB array
│   │   │   │   - _extract_eye_color() → RGB array
│   │   │   │   - _determine_undertone() → "Warm"/"Cool"/"Neutral"
│   │   │   │   - _determine_contrast() → "High"/"Medium"/"Low"
│   │   │   │   - _classify_season() → (season, sub_season)
│   │   │   │   Algorithm: YuNet face detection + K-Means clustering
│   │   │   │
│   │   │   ├── face_shape_service.py        # FACE SHAPE ML SERVICE
│   │   │   │   Functions:
│   │   │   │   - analyze(image_path) → Dict
│   │   │   │   - _classify_shape(measurements) → face_shape
│   │   │   │   Output: Oval/Round/Square/Heart/Oblong/Diamond
│   │   │   │   Algorithm: Face ratio proportions + decision logic
│   │   │   │
│   │   │   ├── body_type_service.py         # BODY TYPE ML SERVICE
│   │   │   │   Functions:
│   │   │   │   - analyze(image_path) → Dict
│   │   │   │   - _classify_body_type(measurements) → body_type
│   │   │   │   Output: Hourglass/Pear/Apple/Rectangle/Inverted Triangle
│   │   │   │   Algorithm: Pose landmark ratios + scoring system
│   │   │   │
│   │   │   ├── hairstyle_service.py         # HAIRSTYLE RECOMMENDATION ENGINE
│   │   │   │   Functions:
│   │   │   │   - get_recommendations(face_shape, season) → Dict
│   │   │   │   - _get_hair_color_suggestions(season) → List
│   │   │   │   Database: 6 face shapes × 6 styles each = 36 recommendations
│   │   │   │
│   │   │   ├── virtual_tryon_service.py     # VIRTUAL TRY-ON SERVICE
│   │   │   │   Functions:
│   │   │   │   - try_on(user_image, clothing_image, category) → Dict
│   │   │   │   - _overlay_top/bottom/dress() → composite image
│   │   │   │   - _alpha_blend() → transparent overlay
│   │   │   │   Algorithm: Pose detection + image compositing
│   │   │   │
│   │   │   ├── recommendation_service.py    # COLOR MATCHING ENGINE
│   │   │   │   Functions:
│   │   │   │   - get_recommendations(db, season, undertone, ...) → Dict
│   │   │   │   - _calculate_match_score(item_hex, recommended) → float
│   │   │   │   - _rgb_to_lab() → CIE Lab conversion
│   │   │   │   Algorithm: CIE Lab Euclidean distance + undertone bonus
│   │   │   │
│   │   │   ├── url_scraper_service.py       # WEB SCRAPING SERVICE
│   │   │   │   Functions:
│   │   │   │   - extract_from_url(url) → Dict
│   │   │   │   - _extract_title/image/price/color()
│   │   │   │   Algorithm: OG meta tags + CSS selectors + regex
│   │   │   │
│   │   │   └── style_report_service.py      # COMPREHENSIVE REPORT GENERATOR
│   │   │       Functions:
│   │   │       - generate_full_report(face_path, body_path) → Dict
│   │   │       - evaluate_outfit(color_profile, outfit_hex) → Dict
│   │   │       - _generate_outfit_guidelines() → Dict
│   │   │       Orchestrates: All services combined into one report
│   │   │
│   │   ├── models/                          # Database Layer
│   │   │   ├── __init__.py
│   │   │   ├── database.py                  # SQLAlchemy ORM Models
│   │   │   │   Tables: User, ColorProfile, CatalogItem, WishlistItem
│   │   │   │   Connection: SQLite with check_same_thread=False
│   │   │   │
│   │   │   └── schemas.py                   # Pydantic Validation Schemas
│   │   │       Classes: UserCreate, UserLogin, Token,
│   │   │                ColorAnalysisResult, CatalogItemSchema,
│   │   │                RecommendationResponse, TryOnResult
│   │   │
│   │   └── utils/                           # Helper utilities
│   │       └── __init__.py
│   │
│   ├── models/                              # ML Model Files (auto-downloaded)
│   │   └── face_detection_yunet_2023mar.onnx  # 340KB ONNX face detector
│   │
│   ├── static/
│   │   └── catalog/                         # Clothing item images
│   │       └── .gitkeep
│   │
│   ├── uploads/                             # Temporary user uploads
│   │   └── .gitkeep                         # (cleaned after processing)
│   │
│   ├── requirements.txt                     # Python dependencies (20 packages)
│   ├── seed_data.py                         # Populates DB with 26 sample items
│   ├── Dockerfile                           # Container build instructions
│   ├── .env                                 # SECRET_KEY, DATABASE_URL
│   └── fashion_ai.db                        # SQLite database (auto-created)
│
├── frontend/                                # React Application
│   │
│   ├── public/
│   │   └── vite.svg                         # App favicon
│   │
│   ├── src/
│   │   ├── components/                      # Reusable UI Components
│   │   │   ├── Navbar.jsx                   # Top navigation bar
│   │   │   │   Features: Responsive, dropdowns, mobile menu, auth state
│   │   │   │
│   │   │   ├── ColorSwatch.jsx              # Color circle display component
│   │   │   │   Props: color (hex), name, size, onClick
│   │   │   │
│   │   │   └── ImageUpload.jsx              # Drag & drop file upload
│   │   │       Props: onUpload, preview, label
│   │   │       Features: Drag/drop, click browse, 10MB limit, preview
│   │   │
│   │   ├── pages/                           # Route Page Components
│   │   │   ├── HomePage.jsx                 # Landing page
│   │   │   │   Sections: Hero, How It Works, Features grid, Tech stack
│   │   │   │
│   │   │   ├── LoginPage.jsx                # Login form
│   │   │   │   Flow: username/password → JWT → redirect
│   │   │   │
│   │   │   ├── RegisterPage.jsx             # Registration form
│   │   │   │   Flow: register → auto-login → redirect to analysis
│   │   │   │
│   │   │   ├── ColorAnalysisPage.jsx        # Color season analysis
│   │   │   │   Shows: Detected colors, season badge, palette, tips
│   │   │   │
│   │   │   ├── StyleReportPage.jsx          # Full comprehensive report
│   │   │   │   Shows: Score, summary, all analyses, outfit guidelines
│   │   │   │
│   │   │   ├── HairstylePage.jsx            # Hairstyle recommendations
│   │   │   │   Shows: Face shape, 6 styles with scores, color suggestions
│   │   │   │
│   │   │   ├── BodyAnalysisPage.jsx         # Body type analysis
│   │   │   │   Shows: Body type, proportions, best/avoid styles
│   │   │   │
│   │   │   ├── VirtualTryOnPage.jsx         # Image-based try-on
│   │   │   │   Flow: Upload photo + clothing → see overlay result
│   │   │   │
│   │   │   ├── URLTryOnPage.jsx             # URL-based try-on
│   │   │   │   Flow: Paste URL → extract product → try on
│   │   │   │
│   │   │   ├── CatalogPage.jsx              # Clothing catalog browser
│   │   │   │   Features: Search, filter, wishlist, color indicators
│   │   │   │
│   │   │   └── RecommendationsPage.jsx      # Personalized recommendations
│   │   │       Shows: Personal palette, scored items, styling tips
│   │   │
│   │   ├── services/                        # API Communication Layer
│   │   │   ├── api.js                       # Axios HTTP client
│   │   │   │   - Base URL: http://localhost:8000
│   │   │   │   - Auto-attaches JWT token
│   │   │   │   - All endpoint functions exported
│   │   │   │
│   │   │   └── auth.js                      # Token management
│   │   │       - getToken() / setToken() / removeToken()
│   │   │       - localStorage-based persistence
│   │   │
│   │   ├── assets/                          # Static images/icons
│   │   ├── App.jsx                          # Root component + Router
│   │   ├── main.jsx                         # React DOM render
│   │   └── index.css                        # Tailwind directives + custom classes
│   │
│   ├── index.html                           # HTML entry point
│   ├── package.json                         # Node.js dependencies
│   ├── vite.config.js                       # Dev server + API proxy config
│   ├── tailwind.config.js                   # Theme customization
│   ├── postcss.config.js                    # PostCSS plugins
│   └── Dockerfile                           # Frontend container
│
├── docker-compose.yml                       # Multi-container orchestration
├── .gitignore                               # Git exclusions
├── README.md                                # Quick start guide
└── DOCUMENTATION.md                         # This file
```

---

## 4. Technology Stack

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| Frontend | React | 18.2 | UI components |
| Frontend | Tailwind CSS | 3.3 | Styling |
| Frontend | Vite | 5.0 | Build tool |
| Frontend | React Router | 6.20 | Navigation |
| Frontend | Axios | 1.6 | HTTP client |
| Backend | Python | 3.10 | Runtime |
| Backend | FastAPI | 0.139 | Web framework |
| Backend | SQLAlchemy | 2.0 | ORM |
| Backend | Pydantic | 2.13 | Validation |
| Backend | Uvicorn | 0.51 | ASGI server |
| ML/AI | OpenCV | 5.0 | Image processing, face detection |
| ML/AI | scikit-learn | 1.7 | K-Means clustering |
| ML/AI | NumPy | 2.2 | Numerical computing |
| ML/AI | Pillow | 12.3 | Image handling |
| Auth | python-jose | 3.5 | JWT tokens |
| Scraping | BeautifulSoup4 | 4.12 | HTML parsing |
| Database | SQLite | Built-in | Data storage |
| Deploy | Docker | - | Containerization |

---

## 5. ML/AI Algorithms

### 5.1 Face Detection (YuNet DNN)
- **Model:** face_detection_yunet_2023mar.onnx (340KB)
- **Input:** Any size image
- **Output:** Bounding box + 5 landmarks (eyes, nose, mouth corners)
- **Usage:** Locates face regions for color extraction

### 5.2 K-Means Color Clustering
- **Library:** scikit-learn KMeans
- **Input:** Pixel arrays from face regions (cheeks, forehead, eyes)
- **Process:** Groups pixels into k=3 clusters, selects dominant
- **Output:** Single RGB color representing skin/hair/eye

### 5.3 Color Season Classification
- **Input:** Skin undertone + luminance + contrast level
- **Logic:** Decision tree based on color theory
- **Output:** 1 of 12 sub-seasons (e.g., "Light Spring", "Deep Winter")
- **Basis:** Munsell color system + seasonal color analysis theory

### 5.4 CIE Lab Color Distance
- **Purpose:** Score clothing items against user's palette
- **Formula:** √((L₁-L₂)² + (a₁-a₂)² + (b₁-b₂)²)
- **Why Lab:** Perceptually uniform (equal ΔE = equal visual difference)
- **Score:** Normalized 0-1, higher = better match

### 5.5 Face Shape Classification
- **Measurements:** face_length / cheekbone_width ratio, forehead:jaw ratio
- **Categories:** Oval (1.35-1.55), Round (<1.25), Oblong (>1.6), Square, Heart, Diamond
- **Method:** Weighted scoring system across multiple proportion ratios

### 5.6 Image Compositing (Virtual Try-On)
- **Step 1:** Detect body pose landmarks (shoulders, hips, knees)
- **Step 2:** Calculate target rectangle for clothing placement
- **Step 3:** Resize clothing image to fit body
- **Step 4:** Alpha blend (transparency) onto original photo

---

## 6. Database Schema

### Users Table
| Column | Type | Constraint |
|--------|------|-----------|
| id | INTEGER | PRIMARY KEY |
| username | TEXT | UNIQUE, NOT NULL |
| email | TEXT | UNIQUE, NOT NULL |
| hashed_password | TEXT | NOT NULL |
| created_at | DATETIME | DEFAULT now |

### Color Profiles Table
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | PRIMARY KEY |
| user_id | INTEGER | FK → users.id |
| skin_tone_hex | TEXT | e.g., "#c8aa8c" |
| hair_color_hex | TEXT | e.g., "#3c2814" |
| eye_color_hex | TEXT | e.g., "#64503c" |
| season | TEXT | Spring/Summer/Autumn/Winter |
| sub_season | TEXT | e.g., "Warm Autumn" |
| undertone | TEXT | Warm/Cool/Neutral |
| contrast_level | TEXT | Low/Medium/High |
| recommended_colors | JSON | Array of hex colors |
| avoid_colors | JSON | Array of hex colors |

### Catalog Items Table
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | PRIMARY KEY |
| name | TEXT | Product name |
| category | TEXT | tops/bottoms/dresses/accessories |
| color_hex | TEXT | Dominant color |
| color_name | TEXT | Human-readable color |
| image_url | TEXT | Image path |
| price | REAL | Price in USD |
| description | TEXT | Product description |
| tags | JSON | Style tags array |

### Wishlist Table
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | PRIMARY KEY |
| user_id | INTEGER | FK → users.id |
| catalog_item_id | INTEGER | FK → catalog_items.id |
| added_at | DATETIME | When added |

---

## 7. API Endpoints Reference

### Authentication
| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | /api/auth/register | {username, email, password} | {id, username, email} |
| POST | /api/auth/login | {username, password} | {access_token, token_type} |
| GET | /api/auth/me | - (Bearer token) | {id, username, email} |

### Color Analysis
| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | /api/color-analysis/analyze | multipart: file | {skin_tone, hair_color, eye_color, season, sub_season, undertone, recommended_colors, avoid_colors, style_tips} |
| GET | /api/color-analysis/profile | - | Saved color profile |

### Face Shape
| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | /api/face-shape/analyze | multipart: file | {face_shape, description, characteristics, measurements, proportions} |

### Body Type
| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | /api/body-type/analyze | multipart: file | {body_type, description, best_styles, avoid_styles, proportions} |

### Hairstyle
| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | /api/hairstyle/recommend | multipart: file | {face_shape_analysis, hairstyle_recommendations} |
| GET | /api/hairstyle/by-shape?face_shape= | - | Recommendations for shape |

### Virtual Try-On
| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | /api/tryon/try-on-upload | multipart: user_photo, clothing_photo, category | {result_image_url, fit_score} |

### URL Scraper
| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | /api/scraper/extract | {url} | {title, image_url, price, color, domain} |

### Style Report
| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | /api/style-report/generate | multipart: face_photo, body_photo? | {overall_style_score, sections, summary, key_recommendations} |
| POST | /api/style-report/evaluate-outfit | form: outfit_color_hex, outfit_category, body_type | {overall_score, color_compatibility, body_suitability, verdict} |

### Catalog
| Method | Endpoint | Params | Response |
|--------|----------|--------|----------|
| GET | /api/catalog/items | ?category, ?search, ?min_price, ?max_price | [CatalogItem] |
| POST | /api/catalog/wishlist/{id} | - | {message} |
| DELETE | /api/catalog/wishlist/{id} | - | {message} |
| GET | /api/catalog/wishlist | - | [CatalogItem] |

### Recommendations
| Method | Endpoint | Params | Response |
|--------|----------|--------|----------|
| GET | /api/recommendations/get | ?category, ?limit | {items, color_palette, styling_tips} |
| GET | /api/recommendations/palette | - | {season, palette, recommended_colors} |

---

## 8. Data Flow Diagrams

### Color Analysis Flow
```
User uploads selfie
        │
        ▼
┌─────────────────┐
│  Image Upload   │  (validate type, save temp file)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Face Detection │  (YuNet DNN → bounding box + landmarks)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Region Sampling │  (extract cheek, forehead, eye pixel arrays)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  K-Means (k=3)  │  (cluster pixels → dominant color per region)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  HSV Analysis   │  (skin hue → undertone classification)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Season Classify │  (undertone × lightness × contrast → sub-season)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Save Profile   │  (store in database for future use)
└────────┬────────┘
         │
         ▼
   Return Result
   (colors, season, palette, tips)
```

### Recommendation Flow
```
User requests recommendations
        │
        ▼
┌─────────────────┐
│  Get Profile    │  (load user's season + recommended colors from DB)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Query Catalog  │  (filter by category if specified)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  For Each Item: │
│  1. Convert item color → CIE Lab           │
│  2. Convert each recommended color → Lab   │
│  3. Calculate min Euclidean distance        │
│  4. Normalize to 0-1 score                  │
│  5. Add undertone bonus (+0.1 if match)     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Sort by Score  │  (highest match first)
└────────┬────────┘
         │
         ▼
   Return scored items + palette + tips
```

---

## 9. Setup & Installation

### Prerequisites
- Python 3.10+
- Node.js 18+
- pip (Python package manager)
- npm (Node package manager)

### Backend Setup
```bash
cd fashion-ai/backend

# Create virtual environment
python -m venv venv

# Activate (Windows)
.\venv\Scripts\Activate

# Install dependencies
pip install --index-url https://pypi.org/simple/ --trusted-host pypi.org -r requirements.txt

# Seed database with sample data
python seed_data.py

# Start server
.\venv\Scripts\python.exe -m uvicorn app.main:app --port 8000
```

### Frontend Setup
```bash
cd fashion-ai/frontend

# Install Node packages
npm install

# Start development server
npm run dev
```

### Access
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/docs

---

## 10. User Guide

### Step 1: Register & Login
1. Go to http://localhost:3000
2. Click "Sign Up"
3. Enter username, email, password
4. Auto-redirected after registration

### Step 2: Color Analysis
1. Navigate to "Color Analysis"
2. Upload a clear, well-lit selfie
3. Click "Analyze My Colors"
4. View: skin tone, hair color, eye color, season, palette

### Step 3: Full Style Report
1. Navigate to "Style Report"
2. Upload face photo (required)
3. Optionally upload full-body photo
4. Click "Generate Style Report"
5. View comprehensive analysis

### Step 4: Browse Recommendations
1. Navigate to "For You" (requires completed color analysis)
2. See items scored by color compatibility
3. Filter by category
4. Add favorites to wishlist

### Step 5: Virtual Try-On
1. Navigate to "Try On"
2. Upload your full-body photo
3. Upload a clothing image (transparent background works best)
4. Select category (tops/bottoms/dresses)
5. Click "Try It On!"

---

## 11. Testing

### Manual Testing Checklist
- [ ] Register new user
- [ ] Login with credentials
- [ ] Upload selfie → get color analysis
- [ ] View recommended colors palette
- [ ] Generate full style report
- [ ] Browse catalog with filters
- [ ] Add item to wishlist
- [ ] View personalized recommendations
- [ ] Try on clothing virtually

### API Testing (Swagger)
- Open http://localhost:8000/docs
- Use "Authorize" button with JWT token
- Test each endpoint interactively

---

## 12. Deployment Options

### Option 1: Docker
```bash
docker-compose up --build
```

### Option 2: Cloud (Railway/Render)
- Backend: Deploy as Python web service
- Frontend: Deploy on Vercel/Netlify
- Database: Upgrade to PostgreSQL for production

### Option 3: Local Demo
- Run both servers as described in Setup section

---

## 13. Known Limitations

1. **MediaPipe Solutions unavailable on Windows** — Uses OpenCV DNN as alternative
2. **Virtual Try-On** — Works best with front-facing photos and transparent clothing images
3. **URL Scraper** — Some websites block scraping; works best with standard e-commerce sites
4. **Color Analysis accuracy** — Depends on photo lighting; natural light recommended
5. **SQLite** — Single-user; upgrade to PostgreSQL for multi-user production

---

## 14. Future Enhancements

- [ ] Real-time webcam analysis (WebRTC)
- [ ] PDF report export
- [ ] AR live try-on
- [ ] Mobile app (React Native)
- [ ] E-commerce API integration
- [ ] GAN-based texture transfer
- [ ] Multi-language support
- [ ] User feedback loop for recommendation improvement

---

## 15. References

- Munsell Color System — Color theory foundation
- Seasonal Color Analysis — Suzanne Caygill's methodology
- OpenCV DNN Module — Intel's deep neural network inference
- CIE Lab Color Space — International Commission on Illumination
- K-Means Clustering — MacQueen (1967)
- FastAPI Documentation — https://fastapi.tiangolo.com
- React Documentation — https://react.dev

---

**Document Version:** 2.0
**Last Updated:** July 2026
**Author:** Fashion AI Project Team
