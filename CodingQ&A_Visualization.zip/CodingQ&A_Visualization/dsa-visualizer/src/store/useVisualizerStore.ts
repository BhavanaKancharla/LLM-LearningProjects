import { create } from 'zustand'

export interface VisualizationStep {
  description: string
  codeLineHighlight: number[]
  state: Record<string, unknown>
  pointers?: Record<string, number>
  highlights?: number[]
  found?: number[]
  explanation?: string
}

interface VisualizerState {
  currentStep: number
  isPlaying: boolean
  speed: number // ms per step
  steps: VisualizationStep[]
  totalSteps: number

  setSteps: (steps: VisualizationStep[]) => void
  nextStep: () => void
  prevStep: () => void
  goToStep: (step: number) => void
  play: () => void
  pause: () => void
  reset: () => void
  setSpeed: (speed: number) => void
}

export const useVisualizerStore = create<VisualizerState>((set, get) => ({
  currentStep: 0,
  isPlaying: false,
  speed: 1000,
  steps: [],
  totalSteps: 0,

  setSteps: (steps) => set({ steps, totalSteps: steps.length, currentStep: 0, isPlaying: false }),
  
  nextStep: () => {
    const { currentStep, totalSteps } = get()
    if (currentStep < totalSteps - 1) {
      set({ currentStep: currentStep + 1 })
    } else {
      set({ isPlaying: false })
    }
  },
  
  prevStep: () => {
    const { currentStep } = get()
    if (currentStep > 0) {
      set({ currentStep: currentStep - 1 })
    }
  },
  
  goToStep: (step) => set({ currentStep: step }),
  
  play: () => set({ isPlaying: true }),
  
  pause: () => set({ isPlaying: false }),
  
  reset: () => set({ currentStep: 0, isPlaying: false }),
  
  setSpeed: (speed) => set({ speed }),
}))
