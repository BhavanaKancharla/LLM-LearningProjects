import { create } from 'zustand'
import { Visualization } from '../visualizations'

interface CustomProblem {
  slug: string
  title: string
  category: string
  visualization: Visualization
  createdAt: string
}

interface CustomProblemsState {
  problems: CustomProblem[]
  addProblem: (problem: CustomProblem) => void
  removeProblem: (slug: string) => void
  loadFromStorage: () => void
  getBySlug: (slug: string) => CustomProblem | undefined
}

const STORAGE_KEY = 'dsa-visualizer-custom-problems'

export const useCustomProblems = create<CustomProblemsState>((set, get) => ({
  problems: [],
  
  addProblem: (problem) => {
    set(state => {
      // Replace if exists, otherwise add
      const existing = state.problems.findIndex(p => p.slug === problem.slug)
      let updated: CustomProblem[]
      if (existing >= 0) {
        updated = [...state.problems]
        updated[existing] = problem
      } else {
        updated = [...state.problems, problem]
      }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
      return { problems: updated }
    })
  },
  
  removeProblem: (slug) => {
    set(state => {
      const updated = state.problems.filter(p => p.slug !== slug)
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
      return { problems: updated }
    })
  },
  
  loadFromStorage: () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored) {
        set({ problems: JSON.parse(stored) })
      }
    } catch {
      // ignore parsing errors
    }
  },
  
  getBySlug: (slug) => {
    return get().problems.find(p => p.slug === slug)
  },
}))
