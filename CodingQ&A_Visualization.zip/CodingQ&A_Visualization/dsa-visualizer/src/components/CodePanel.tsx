import { motion } from 'framer-motion'
import { useVisualizerStore } from '../store/useVisualizerStore'

interface CodePanelProps {
  code: string
  language?: string
}

export default function CodePanel({ code }: CodePanelProps) {
  const { currentStep, steps } = useVisualizerStore()
  const highlightedLines = steps[currentStep]?.codeLineHighlight || []

  const lines = code.split('\n')

  return (
    <div className="glass-panel overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 border-b border-dark-700/50">
        <span className="text-xs font-mono text-dark-400">solution.py</span>
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-red-500/60" />
          <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
          <div className="w-3 h-3 rounded-full bg-green-500/60" />
        </div>
      </div>
      <div className="overflow-auto max-h-[500px] p-4">
        <pre className="text-sm font-mono">
          {lines.map((line, i) => {
            const isHighlighted = highlightedLines.includes(i + 1)
            return (
              <motion.div
                key={i}
                animate={{
                  backgroundColor: isHighlighted ? 'rgba(59, 130, 246, 0.15)' : 'transparent',
                  borderLeftColor: isHighlighted ? '#3b82f6' : 'transparent',
                }}
                className="flex border-l-2 border-transparent -ml-2 pl-2 rounded-r"
              >
                <span className="inline-block w-8 text-right mr-4 text-dark-600 select-none text-xs leading-6">
                  {i + 1}
                </span>
                <span className={`leading-6 ${isHighlighted ? 'text-white' : 'text-dark-300'}`}>
                  {line || ' '}
                </span>
              </motion.div>
            )
          })}
        </pre>
      </div>
    </div>
  )
}
