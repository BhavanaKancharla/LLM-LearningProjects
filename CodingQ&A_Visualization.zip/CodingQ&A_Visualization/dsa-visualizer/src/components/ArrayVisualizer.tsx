import { motion } from 'framer-motion'
import { useVisualizerStore } from '../store/useVisualizerStore'

interface ArrayVisualizerProps {
  title?: string
}

export default function ArrayVisualizer({ title = 'Array' }: ArrayVisualizerProps) {
  const { currentStep, steps } = useVisualizerStore()
  const step = steps[currentStep]
  
  if (!step) return null

  const array = (step.state.array as number[]) || []
  const pointers = step.pointers || {}
  const highlights = step.highlights || []
  const found = step.found || []

  return (
    <div className="space-y-4">
      {title && (
        <h3 className="text-sm font-semibold text-dark-300 uppercase tracking-wider">{title}</h3>
      )}
      
      {/* Array cells */}
      <div className="flex flex-wrap gap-2 items-end">
        {array.map((val, i) => {
          const isHighlighted = highlights.includes(i)
          const isFound = found.includes(i)
          const pointerNames = Object.entries(pointers)
            .filter(([_, idx]) => idx === i)
            .map(([name]) => name)
          
          return (
            <div key={i} className="flex flex-col items-center">
              {/* Pointer labels above */}
              <div className="h-6 flex flex-col items-center justify-end">
                {pointerNames.map((name) => (
                  <motion.span
                    key={name}
                    initial={{ y: -5, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="viz-pointer text-primary-400"
                  >
                    {name} ↓
                  </motion.span>
                ))}
              </div>
              
              {/* Cell */}
              <motion.div
                layout
                animate={{
                  scale: isHighlighted || isFound ? 1.1 : 1,
                  y: isHighlighted ? -4 : 0,
                }}
                transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                className={`viz-cell ${
                  isFound
                    ? 'viz-cell-found'
                    : isHighlighted
                    ? 'viz-cell-active'
                    : pointerNames.length > 0
                    ? 'viz-cell-highlight'
                    : ''
                }`}
              >
                {val}
              </motion.div>

              {/* Index below */}
              <span className="text-[10px] text-dark-500 mt-1 font-mono">{i}</span>
            </div>
          )
        })}
      </div>

      {/* Extra state info */}
      {step.state.hashMap && (
        <div className="mt-4">
          <h4 className="text-xs font-semibold text-dark-400 mb-2">HashMap:</h4>
          <div className="bg-dark-900 rounded-lg p-3 font-mono text-xs text-dark-300">
            {JSON.stringify(step.state.hashMap, null, 2)}
          </div>
        </div>
      )}

      {step.explanation && (
        <motion.div
          key={currentStep}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-accent-500/10 border border-accent-500/30 rounded-lg p-3"
        >
          <p className="text-sm text-accent-300">{step.explanation}</p>
        </motion.div>
      )}
    </div>
  )
}
