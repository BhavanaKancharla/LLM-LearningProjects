import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { useVisualizerStore } from '../store/useVisualizerStore'

export default function StepControls() {
  const {
    currentStep,
    totalSteps,
    isPlaying,
    speed,
    steps,
    nextStep,
    prevStep,
    goToStep,
    play,
    pause,
    reset,
    setSpeed,
  } = useVisualizerStore()

  const intervalRef = useRef<number | null>(null)

  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = window.setInterval(() => {
        nextStep()
      }, speed)
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
        intervalRef.current = null
      }
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [isPlaying, speed, nextStep])

  const currentDescription = steps[currentStep]?.description || ''

  return (
    <div className="glass-panel p-4 space-y-4">
      {/* Step description */}
      <motion.div
        key={currentStep}
        initial={{ opacity: 0, x: 10 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-dark-900 rounded-lg p-3 min-h-[3rem] flex items-center"
      >
        <p className="text-sm text-dark-200">
          <span className="text-primary-400 font-mono font-semibold mr-2">
            Step {currentStep + 1}/{totalSteps}:
          </span>
          {currentDescription}
        </p>
      </motion.div>

      {/* Progress bar */}
      <div className="relative h-2 bg-dark-700 rounded-full overflow-hidden">
        <motion.div
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-primary-500 to-accent-500 rounded-full"
          animate={{ width: `${((currentStep + 1) / totalSteps) * 100}%` }}
          transition={{ duration: 0.3 }}
        />
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={reset}
            className="p-2 rounded-lg bg-dark-700 hover:bg-dark-600 text-dark-300 hover:text-white transition-all"
            title="Reset"
          >
            ⏮
          </button>
          <button
            onClick={prevStep}
            disabled={currentStep === 0}
            className="p-2 rounded-lg bg-dark-700 hover:bg-dark-600 text-dark-300 hover:text-white transition-all disabled:opacity-30"
            title="Previous"
          >
            ⏪
          </button>
          <button
            onClick={isPlaying ? pause : play}
            className="p-3 rounded-xl bg-primary-600 hover:bg-primary-500 text-white font-bold transition-all shadow-lg shadow-primary-600/30"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? '⏸' : '▶️'}
          </button>
          <button
            onClick={nextStep}
            disabled={currentStep >= totalSteps - 1}
            className="p-2 rounded-lg bg-dark-700 hover:bg-dark-600 text-dark-300 hover:text-white transition-all disabled:opacity-30"
            title="Next"
          >
            ⏩
          </button>
        </div>

        {/* Speed control */}
        <div className="flex items-center gap-3">
          <span className="text-xs text-dark-400">Speed:</span>
          <div className="flex gap-1">
            {[2000, 1000, 500, 250].map((s) => (
              <button
                key={s}
                onClick={() => setSpeed(s)}
                className={`px-2 py-1 text-xs rounded-md transition-all ${
                  speed === s
                    ? 'bg-primary-600 text-white'
                    : 'bg-dark-700 text-dark-400 hover:text-white'
                }`}
              >
                {s === 2000 ? '0.5x' : s === 1000 ? '1x' : s === 500 ? '2x' : '4x'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Step timeline */}
      <div className="flex gap-1 overflow-x-auto py-1">
        {steps.map((_, i) => (
          <button
            key={i}
            onClick={() => goToStep(i)}
            className={`min-w-[24px] h-2 rounded-full transition-all ${
              i === currentStep
                ? 'bg-primary-400 scale-125'
                : i < currentStep
                ? 'bg-primary-700'
                : 'bg-dark-700'
            }`}
          />
        ))}
      </div>
    </div>
  )
}
