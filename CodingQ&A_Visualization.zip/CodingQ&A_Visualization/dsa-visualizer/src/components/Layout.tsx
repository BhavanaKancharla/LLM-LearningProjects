import { Outlet, Link, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { useCustomProblems } from '../store/useCustomProblems'

export default function Layout() {
  const location = useLocation()
  const { loadFromStorage } = useCustomProblems()

  useEffect(() => {
    loadFromStorage()
  }, [loadFromStorage])

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="glass-panel border-b border-dark-700/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center text-sm font-bold">
                DS
              </div>
              <span className="text-lg font-semibold text-white group-hover:text-primary-400 transition-colors">
                DSA Visualizer
              </span>
            </Link>
            
            <nav className="flex items-center gap-6">
              <Link
                to="/"
                className={`text-sm font-medium transition-colors ${
                  location.pathname === '/' ? 'text-primary-400' : 'text-dark-300 hover:text-white'
                }`}
              >
                Problems
              </Link>
              <Link
                to="/builder"
                className={`text-sm font-medium transition-colors ${
                  location.pathname === '/builder' ? 'text-accent-400' : 'text-dark-300 hover:text-white'
                }`}
              >
                🛠️ Builder
              </Link>
              <Link
                to="/assistant"
                className={`text-sm font-medium transition-colors ${
                  location.pathname === '/assistant' ? 'text-amber-400' : 'text-dark-300 hover:text-white'
                }`}
              >
                🤖 AI Help
              </Link>
              <a
                href="https://leetcode.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm font-medium text-dark-300 hover:text-white transition-colors"
              >
                LeetCode ↗
              </a>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          <Outlet />
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="border-t border-dark-800 py-6 px-4 text-center text-dark-500 text-sm">
        DSA Visualizer — Step-by-step algorithm visualization for learning
      </footer>
    </div>
  )
}
