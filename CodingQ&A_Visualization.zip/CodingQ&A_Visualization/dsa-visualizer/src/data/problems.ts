export type Difficulty = 'Easy' | 'Medium' | 'Hard'

export interface Problem {
  slug: string
  title: string
  difficulty: Difficulty
  category: string
  categorySlug: string
  hasVisualization: boolean
}

export interface Category {
  slug: string
  name: string
  icon: string
  color: string
  count: number
  problems: Problem[]
}

export const categories: Category[] = [
  {
    slug: 'arrays-hashing',
    name: 'Arrays & Hashing',
    icon: '📦',
    color: 'from-blue-500 to-cyan-400',
    count: 15,
    problems: [
      { slug: 'contains-duplicate', title: 'Contains Duplicate', difficulty: 'Easy', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: true },
      { slug: 'valid-anagram', title: 'Valid Anagram', difficulty: 'Easy', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: true },
      { slug: 'two-sum', title: 'Two Sum', difficulty: 'Easy', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: true },
      { slug: 'group-anagrams', title: 'Group Anagrams', difficulty: 'Medium', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'top-k-frequent-elements', title: 'Top K Frequent Elements', difficulty: 'Medium', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'product-of-array-except-self', title: 'Product of Array Except Self', difficulty: 'Medium', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'valid-sudoku', title: 'Valid Sudoku', difficulty: 'Medium', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'longest-consecutive-sequence', title: 'Longest Consecutive Sequence', difficulty: 'Medium', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'majority-element', title: 'Majority Element', difficulty: 'Easy', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'remove-element', title: 'Remove Element', difficulty: 'Easy', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'remove-duplicates-from-sorted-array', title: 'Remove Duplicates from Sorted Array', difficulty: 'Easy', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'remove-duplicates-from-sorted-array-ii', title: 'Remove Duplicates from Sorted Array II', difficulty: 'Medium', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'rotate-array', title: 'Rotate Array', difficulty: 'Medium', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'h-index', title: 'H-Index', difficulty: 'Medium', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
      { slug: 'insert-delete-getrandom-o1', title: 'Insert Delete GetRandom O(1)', difficulty: 'Medium', category: 'Arrays & Hashing', categorySlug: 'arrays-hashing', hasVisualization: false },
    ]
  },
  {
    slug: 'two-pointers',
    name: 'Two Pointers',
    icon: '👆',
    color: 'from-purple-500 to-pink-400',
    count: 10,
    problems: [
      { slug: 'valid-palindrome', title: 'Valid Palindrome', difficulty: 'Easy', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: true },
      { slug: 'is-subsequence', title: 'Is Subsequence', difficulty: 'Easy', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: false },
      { slug: 'two-sum-ii-input-array-is-sorted', title: 'Two Sum II', difficulty: 'Medium', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: true },
      { slug: 'container-with-most-water', title: 'Container With Most Water', difficulty: 'Medium', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: false },
      { slug: 'trapping-rain-water', title: 'Trapping Rain Water', difficulty: 'Hard', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: false },
      { slug: '3sum', title: '3Sum', difficulty: 'Medium', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: false },
      { slug: 'reverse-words-in-a-string', title: 'Reverse Words in a String', difficulty: 'Medium', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: false },
      { slug: 'zigzag-conversion', title: 'Zigzag Conversion', difficulty: 'Medium', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: false },
      { slug: 'longest-common-prefix', title: 'Longest Common Prefix', difficulty: 'Easy', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: false },
      { slug: 'find-the-index-of-the-first-occurrence-in-a-string', title: 'Find First Occurrence in a String', difficulty: 'Easy', category: 'Two Pointers', categorySlug: 'two-pointers', hasVisualization: false },
    ]
  },
  {
    slug: 'sliding-window',
    name: 'Sliding Window',
    icon: '🪟',
    color: 'from-amber-500 to-orange-400',
    count: 8,
    problems: [
      { slug: 'best-time-to-buy-and-sell-stock', title: 'Best Time to Buy and Sell Stock', difficulty: 'Easy', category: 'Sliding Window', categorySlug: 'sliding-window', hasVisualization: true },
      { slug: 'best-time-to-buy-and-sell-stock-ii', title: 'Best Time to Buy and Sell Stock II', difficulty: 'Medium', category: 'Sliding Window', categorySlug: 'sliding-window', hasVisualization: false },
      { slug: 'longest-substring-without-repeating-characters', title: 'Longest Substring Without Repeating Characters', difficulty: 'Medium', category: 'Sliding Window', categorySlug: 'sliding-window', hasVisualization: false },
      { slug: 'longest-repeating-character-replacement', title: 'Longest Repeating Character Replacement', difficulty: 'Medium', category: 'Sliding Window', categorySlug: 'sliding-window', hasVisualization: false },
      { slug: 'permutation-in-string', title: 'Permutation in String', difficulty: 'Medium', category: 'Sliding Window', categorySlug: 'sliding-window', hasVisualization: false },
      { slug: 'minimum-window-substring', title: 'Minimum Window Substring', difficulty: 'Hard', category: 'Sliding Window', categorySlug: 'sliding-window', hasVisualization: false },
      { slug: 'sliding-window-maximum', title: 'Sliding Window Maximum', difficulty: 'Hard', category: 'Sliding Window', categorySlug: 'sliding-window', hasVisualization: false },
      { slug: 'minimum-size-subarray-sum', title: 'Minimum Size Subarray Sum', difficulty: 'Medium', category: 'Sliding Window', categorySlug: 'sliding-window', hasVisualization: false },
    ]
  },
  {
    slug: 'stack',
    name: 'Stack',
    icon: '📚',
    color: 'from-red-500 to-rose-400',
    count: 8,
    problems: [
      { slug: 'valid-parentheses', title: 'Valid Parentheses', difficulty: 'Easy', category: 'Stack', categorySlug: 'stack', hasVisualization: true },
      { slug: 'min-stack', title: 'Min Stack', difficulty: 'Medium', category: 'Stack', categorySlug: 'stack', hasVisualization: false },
      { slug: 'evaluate-reverse-polish-notation', title: 'Evaluate Reverse Polish Notation', difficulty: 'Medium', category: 'Stack', categorySlug: 'stack', hasVisualization: false },
      { slug: 'daily-temperatures', title: 'Daily Temperatures', difficulty: 'Medium', category: 'Stack', categorySlug: 'stack', hasVisualization: false },
      { slug: 'car-fleet', title: 'Car Fleet', difficulty: 'Medium', category: 'Stack', categorySlug: 'stack', hasVisualization: false },
      { slug: 'largest-rectangle-in-histogram', title: 'Largest Rectangle in Histogram', difficulty: 'Hard', category: 'Stack', categorySlug: 'stack', hasVisualization: false },
      { slug: 'simplify-path', title: 'Simplify Path', difficulty: 'Medium', category: 'Stack', categorySlug: 'stack', hasVisualization: false },
      { slug: 'basic-calculator', title: 'Basic Calculator', difficulty: 'Hard', category: 'Stack', categorySlug: 'stack', hasVisualization: false },
    ]
  },
  {
    slug: 'binary-search',
    name: 'Binary Search',
    icon: '🔍',
    color: 'from-green-500 to-emerald-400',
    count: 7,
    problems: [
      { slug: 'binary-search', title: 'Binary Search', difficulty: 'Easy', category: 'Binary Search', categorySlug: 'binary-search', hasVisualization: true },
      { slug: 'search-insert-position', title: 'Search Insert Position', difficulty: 'Easy', category: 'Binary Search', categorySlug: 'binary-search', hasVisualization: false },
      { slug: 'search-a-2d-matrix', title: 'Search a 2D Matrix', difficulty: 'Medium', category: 'Binary Search', categorySlug: 'binary-search', hasVisualization: false },
      { slug: 'find-minimum-in-rotated-sorted-array', title: 'Find Minimum in Rotated Sorted Array', difficulty: 'Medium', category: 'Binary Search', categorySlug: 'binary-search', hasVisualization: false },
      { slug: 'search-in-rotated-sorted-array', title: 'Search in Rotated Sorted Array', difficulty: 'Medium', category: 'Binary Search', categorySlug: 'binary-search', hasVisualization: false },
      { slug: 'find-first-and-last-position-of-element-in-sorted-array', title: 'Find First and Last Position', difficulty: 'Medium', category: 'Binary Search', categorySlug: 'binary-search', hasVisualization: false },
      { slug: 'median-of-two-sorted-arrays', title: 'Median of Two Sorted Arrays', difficulty: 'Hard', category: 'Binary Search', categorySlug: 'binary-search', hasVisualization: false },
    ]
  },
  {
    slug: 'linked-list',
    name: 'Linked List',
    icon: '🔗',
    color: 'from-teal-500 to-cyan-400',
    count: 12,
    problems: [
      { slug: 'reverse-linked-list', title: 'Reverse Linked List', difficulty: 'Easy', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: true },
      { slug: 'merge-two-sorted-lists', title: 'Merge Two Sorted Lists', difficulty: 'Easy', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'linked-list-cycle', title: 'Linked List Cycle', difficulty: 'Easy', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'reorder-list', title: 'Reorder List', difficulty: 'Medium', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'remove-nth-node-from-end-of-list', title: 'Remove Nth Node From End', difficulty: 'Medium', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'copy-list-with-random-pointer', title: 'Copy List with Random Pointer', difficulty: 'Medium', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'add-two-numbers', title: 'Add Two Numbers', difficulty: 'Medium', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'find-the-duplicate-number', title: 'Find the Duplicate Number', difficulty: 'Medium', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'lru-cache', title: 'LRU Cache', difficulty: 'Medium', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'merge-k-sorted-lists', title: 'Merge k Sorted Lists', difficulty: 'Hard', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'reverse-nodes-in-k-group', title: 'Reverse Nodes in k-Group', difficulty: 'Hard', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
      { slug: 'rotate-list', title: 'Rotate List', difficulty: 'Medium', category: 'Linked List', categorySlug: 'linked-list', hasVisualization: false },
    ]
  },
  {
    slug: 'trees',
    name: 'Trees',
    icon: '🌲',
    color: 'from-emerald-500 to-green-400',
    count: 15,
    problems: [
      { slug: 'invert-binary-tree', title: 'Invert Binary Tree', difficulty: 'Easy', category: 'Trees', categorySlug: 'trees', hasVisualization: true },
      { slug: 'maximum-depth-of-binary-tree', title: 'Maximum Depth of Binary Tree', difficulty: 'Easy', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'diameter-of-binary-tree', title: 'Diameter of Binary Tree', difficulty: 'Easy', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'balanced-binary-tree', title: 'Balanced Binary Tree', difficulty: 'Easy', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'same-tree', title: 'Same Tree', difficulty: 'Easy', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'subtree-of-another-tree', title: 'Subtree of Another Tree', difficulty: 'Easy', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'lowest-common-ancestor-of-a-binary-search-tree', title: 'Lowest Common Ancestor of BST', difficulty: 'Medium', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'binary-tree-level-order-traversal', title: 'Binary Tree Level Order Traversal', difficulty: 'Medium', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'binary-tree-right-side-view', title: 'Binary Tree Right Side View', difficulty: 'Medium', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'count-good-nodes-in-binary-tree', title: 'Count Good Nodes in Binary Tree', difficulty: 'Medium', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'validate-binary-search-tree', title: 'Validate Binary Search Tree', difficulty: 'Medium', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'kth-smallest-element-in-a-bst', title: 'Kth Smallest Element in BST', difficulty: 'Medium', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'construct-binary-tree-from-preorder-and-inorder-traversal', title: 'Construct Binary Tree (Pre/In)', difficulty: 'Medium', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'binary-tree-maximum-path-sum', title: 'Binary Tree Maximum Path Sum', difficulty: 'Hard', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
      { slug: 'serialize-and-deserialize-binary-tree', title: 'Serialize and Deserialize Binary Tree', difficulty: 'Hard', category: 'Trees', categorySlug: 'trees', hasVisualization: false },
    ]
  },
  {
    slug: 'heap-priority-queue',
    name: 'Heap / Priority Queue',
    icon: '⛰️',
    color: 'from-indigo-500 to-violet-400',
    count: 7,
    problems: [
      { slug: 'kth-largest-element-in-a-stream', title: 'Kth Largest Element in a Stream', difficulty: 'Easy', category: 'Heap / Priority Queue', categorySlug: 'heap-priority-queue', hasVisualization: false },
      { slug: 'last-stone-weight', title: 'Last Stone Weight', difficulty: 'Easy', category: 'Heap / Priority Queue', categorySlug: 'heap-priority-queue', hasVisualization: false },
      { slug: 'k-closest-points-to-origin', title: 'K Closest Points to Origin', difficulty: 'Medium', category: 'Heap / Priority Queue', categorySlug: 'heap-priority-queue', hasVisualization: false },
      { slug: 'kth-largest-element-in-an-array', title: 'Kth Largest Element in an Array', difficulty: 'Medium', category: 'Heap / Priority Queue', categorySlug: 'heap-priority-queue', hasVisualization: false },
      { slug: 'task-scheduler', title: 'Task Scheduler', difficulty: 'Medium', category: 'Heap / Priority Queue', categorySlug: 'heap-priority-queue', hasVisualization: false },
      { slug: 'design-twitter', title: 'Design Twitter', difficulty: 'Medium', category: 'Heap / Priority Queue', categorySlug: 'heap-priority-queue', hasVisualization: false },
      { slug: 'find-median-from-data-stream', title: 'Find Median from Data Stream', difficulty: 'Hard', category: 'Heap / Priority Queue', categorySlug: 'heap-priority-queue', hasVisualization: false },
    ]
  },
  {
    slug: 'backtracking',
    name: 'Backtracking',
    icon: '🔄',
    color: 'from-fuchsia-500 to-pink-400',
    count: 10,
    problems: [
      { slug: 'subsets', title: 'Subsets', difficulty: 'Medium', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
      { slug: 'combination-sum', title: 'Combination Sum', difficulty: 'Medium', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
      { slug: 'combination-sum-ii', title: 'Combination Sum II', difficulty: 'Medium', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
      { slug: 'permutations', title: 'Permutations', difficulty: 'Medium', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
      { slug: 'subsets-ii', title: 'Subsets II', difficulty: 'Medium', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
      { slug: 'generate-parentheses', title: 'Generate Parentheses', difficulty: 'Medium', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
      { slug: 'word-search', title: 'Word Search', difficulty: 'Medium', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
      { slug: 'palindrome-partitioning', title: 'Palindrome Partitioning', difficulty: 'Medium', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
      { slug: 'letter-combinations-of-a-phone-number', title: 'Letter Combinations of a Phone Number', difficulty: 'Medium', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
      { slug: 'n-queens', title: 'N-Queens', difficulty: 'Hard', category: 'Backtracking', categorySlug: 'backtracking', hasVisualization: false },
    ]
  },
  {
    slug: 'trie',
    name: 'Trie',
    icon: '🌳',
    color: 'from-lime-500 to-green-400',
    count: 3,
    problems: [
      { slug: 'implement-trie-prefix-tree', title: 'Implement Trie', difficulty: 'Medium', category: 'Trie', categorySlug: 'trie', hasVisualization: false },
      { slug: 'design-add-and-search-words-data-structure', title: 'Design Add and Search Words', difficulty: 'Medium', category: 'Trie', categorySlug: 'trie', hasVisualization: false },
      { slug: 'word-search-ii', title: 'Word Search II', difficulty: 'Hard', category: 'Trie', categorySlug: 'trie', hasVisualization: false },
    ]
  },
  {
    slug: 'graphs-bfs-dfs',
    name: 'Graphs – BFS / DFS',
    icon: '🕸️',
    color: 'from-sky-500 to-blue-400',
    count: 12,
    problems: [
      { slug: 'number-of-islands', title: 'Number of Islands', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'max-area-of-island', title: 'Max Area of Island', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'clone-graph', title: 'Clone Graph', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'walls-and-gates', title: 'Walls and Gates', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'rotting-oranges', title: 'Rotting Oranges', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'pacific-atlantic-water-flow', title: 'Pacific Atlantic Water Flow', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'surrounded-regions', title: 'Surrounded Regions', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'course-schedule', title: 'Course Schedule', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'course-schedule-ii', title: 'Course Schedule II', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'graph-valid-tree', title: 'Graph Valid Tree', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'number-of-connected-components-in-an-undirected-graph', title: 'Number of Connected Components', difficulty: 'Medium', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
      { slug: 'word-ladder', title: 'Word Ladder', difficulty: 'Hard', category: 'Graphs – BFS / DFS', categorySlug: 'graphs-bfs-dfs', hasVisualization: false },
    ]
  },
  {
    slug: 'advanced-graphs',
    name: 'Advanced Graphs',
    icon: '🗺️',
    color: 'from-cyan-500 to-teal-400',
    count: 6,
    problems: [
      { slug: 'network-delay-time', title: 'Network Delay Time', difficulty: 'Medium', category: 'Advanced Graphs', categorySlug: 'advanced-graphs', hasVisualization: false },
      { slug: 'reconstruct-itinerary', title: 'Reconstruct Itinerary', difficulty: 'Hard', category: 'Advanced Graphs', categorySlug: 'advanced-graphs', hasVisualization: false },
      { slug: 'min-cost-to-connect-all-points', title: 'Min Cost to Connect All Points', difficulty: 'Medium', category: 'Advanced Graphs', categorySlug: 'advanced-graphs', hasVisualization: false },
      { slug: 'swim-in-rising-water', title: 'Swim in Rising Water', difficulty: 'Hard', category: 'Advanced Graphs', categorySlug: 'advanced-graphs', hasVisualization: false },
      { slug: 'alien-dictionary', title: 'Alien Dictionary', difficulty: 'Hard', category: 'Advanced Graphs', categorySlug: 'advanced-graphs', hasVisualization: false },
      { slug: 'cheapest-flights-within-k-stops', title: 'Cheapest Flights Within K Stops', difficulty: 'Medium', category: 'Advanced Graphs', categorySlug: 'advanced-graphs', hasVisualization: false },
    ]
  },
  {
    slug: 'dp-1d',
    name: 'Dynamic Programming – 1D',
    icon: '📈',
    color: 'from-yellow-500 to-amber-400',
    count: 10,
    problems: [
      { slug: 'climbing-stairs', title: 'Climbing Stairs', difficulty: 'Easy', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
      { slug: 'min-cost-climbing-stairs', title: 'Min Cost Climbing Stairs', difficulty: 'Easy', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
      { slug: 'house-robber', title: 'House Robber', difficulty: 'Medium', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
      { slug: 'house-robber-ii', title: 'House Robber II', difficulty: 'Medium', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
      { slug: 'longest-palindromic-substring', title: 'Longest Palindromic Substring', difficulty: 'Medium', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
      { slug: 'palindromic-substrings', title: 'Palindromic Substrings', difficulty: 'Medium', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
      { slug: 'decode-ways', title: 'Decode Ways', difficulty: 'Medium', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
      { slug: 'coin-change', title: 'Coin Change', difficulty: 'Medium', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
      { slug: 'maximum-product-subarray', title: 'Maximum Product Subarray', difficulty: 'Medium', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
      { slug: 'word-break', title: 'Word Break', difficulty: 'Medium', category: 'Dynamic Programming – 1D', categorySlug: 'dp-1d', hasVisualization: false },
    ]
  },
  {
    slug: 'dp-2d',
    name: 'Dynamic Programming – 2D',
    icon: '🧮',
    color: 'from-orange-500 to-red-400',
    count: 10,
    problems: [
      { slug: 'unique-paths', title: 'Unique Paths', difficulty: 'Medium', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
      { slug: 'longest-common-subsequence', title: 'Longest Common Subsequence', difficulty: 'Medium', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
      { slug: 'best-time-to-buy-and-sell-stock-with-cooldown', title: 'Best Time to Buy and Sell Stock with Cooldown', difficulty: 'Medium', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
      { slug: 'coin-change-ii', title: 'Coin Change II', difficulty: 'Medium', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
      { slug: 'target-sum', title: 'Target Sum', difficulty: 'Medium', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
      { slug: 'interleaving-string', title: 'Interleaving String', difficulty: 'Medium', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
      { slug: 'longest-increasing-path-in-a-matrix', title: 'Longest Increasing Path in a Matrix', difficulty: 'Hard', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
      { slug: 'distinct-subsequences', title: 'Distinct Subsequences', difficulty: 'Hard', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
      { slug: 'edit-distance', title: 'Edit Distance', difficulty: 'Medium', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
      { slug: 'burst-balloons', title: 'Burst Balloons', difficulty: 'Hard', category: 'Dynamic Programming – 2D', categorySlug: 'dp-2d', hasVisualization: false },
    ]
  },
  {
    slug: 'greedy-intervals',
    name: 'Greedy & Intervals',
    icon: '🎯',
    color: 'from-rose-500 to-pink-400',
    count: 8,
    problems: [
      { slug: 'maximum-subarray', title: 'Maximum Subarray', difficulty: 'Medium', category: 'Greedy & Intervals', categorySlug: 'greedy-intervals', hasVisualization: false },
      { slug: 'jump-game', title: 'Jump Game', difficulty: 'Medium', category: 'Greedy & Intervals', categorySlug: 'greedy-intervals', hasVisualization: false },
      { slug: 'jump-game-ii', title: 'Jump Game II', difficulty: 'Medium', category: 'Greedy & Intervals', categorySlug: 'greedy-intervals', hasVisualization: false },
      { slug: 'gas-station', title: 'Gas Station', difficulty: 'Medium', category: 'Greedy & Intervals', categorySlug: 'greedy-intervals', hasVisualization: false },
      { slug: 'hand-of-straights', title: 'Hand of Straights', difficulty: 'Medium', category: 'Greedy & Intervals', categorySlug: 'greedy-intervals', hasVisualization: false },
      { slug: 'partition-labels', title: 'Partition Labels', difficulty: 'Medium', category: 'Greedy & Intervals', categorySlug: 'greedy-intervals', hasVisualization: false },
      { slug: 'insert-interval', title: 'Insert Interval', difficulty: 'Medium', category: 'Greedy & Intervals', categorySlug: 'greedy-intervals', hasVisualization: false },
      { slug: 'merge-intervals', title: 'Merge Intervals', difficulty: 'Medium', category: 'Greedy & Intervals', categorySlug: 'greedy-intervals', hasVisualization: false },
    ]
  },
]

export function getAllProblems(): Problem[] {
  return categories.flatMap(c => c.problems)
}

export function getProblemBySlug(slug: string): Problem | undefined {
  return getAllProblems().find(p => p.slug === slug)
}

export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find(c => c.slug === slug)
}
