import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import HomePage from './pages/HomePage'
import ProblemPage from './pages/ProblemPage'
import CategoryPage from './pages/CategoryPage'
import BuilderPage from './pages/BuilderPage'
import AIAssistantPage from './pages/AIAssistantPage'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="category/:categorySlug" element={<CategoryPage />} />
        <Route path="problem/:problemSlug" element={<ProblemPage />} />
        <Route path="builder" element={<BuilderPage />} />
        <Route path="assistant" element={<AIAssistantPage />} />
      </Route>
    </Routes>
  )
}

export default App
