import { useState, useRef, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { categories } from '../data/problems'

interface Message {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: Date
}

interface AIConfig {
  provider: 'openai' | 'gemini' | 'ollama'
  apiKey: string
  model: string
  baseUrl?: string
}

const DEFAULT_CONFIG: AIConfig = {
  provider: 'openai',
  apiKey: '',
  model: 'gpt-4o-mini',
}

const SYSTEM_PROMPT = `You are a DSA (Data Structures & Algorithms) tutor and coding assistant. Your role is to:

1. Help users understand and solve LeetCode-style coding problems
2. Give hints when they're stuck — start with small hints, escalate only if asked
3. Explain approaches (brute force → optimized), time/space complexity
4. Debug their code and explain what's wrong
5. Walk through solutions step by step
6. Explain patterns: sliding window, two pointers, BFS/DFS, dynamic programming, etc.

Rules:
- If the user shares a problem, first ask what they've tried before giving the solution
- Give HINTS first, not full solutions (unless explicitly asked)
- Use clear examples with small inputs to illustrate
- Always explain WHY an approach works, not just HOW
- Format code in markdown code blocks with language specified
- If asked for a solution, provide it with detailed comments explaining each step
- Relate problems to common patterns (two pointers, hashmap, sliding window, etc.)
- Be encouraging and supportive

You know all common LeetCode problems and their optimal solutions.`

const HINT_LEVELS = [
  { label: '💡 Small Hint', prompt: 'Give me a small hint without revealing the approach' },
  { label: '🧩 Pattern Hint', prompt: 'What pattern or technique should I use for this problem?' },
  { label: '📐 Approach', prompt: 'Walk me through the approach step by step' },
  { label: '💻 Solution', prompt: 'Show me the full solution with explanations' },
]

const CONFIG_STORAGE_KEY = 'dsa-ai-config'
const HISTORY_STORAGE_KEY = 'dsa-ai-history'

function loadConfig(): AIConfig {
  try {
    const stored = localStorage.getItem(CONFIG_STORAGE_KEY)
    return stored ? { ...DEFAULT_CONFIG, ...JSON.parse(stored) } : DEFAULT_CONFIG
  } catch {
    return DEFAULT_CONFIG
  }
}

function saveConfig(config: AIConfig) {
  localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(config))
}

function loadHistory(): Message[] {
  try {
    const stored = localStorage.getItem(HISTORY_STORAGE_KEY)
    if (stored) {
      const parsed = JSON.parse(stored)
      return parsed.map((m: Message) => ({ ...m, timestamp: new Date(m.timestamp) }))
    }
    return []
  } catch {
    return []
  }
}

function saveHistory(messages: Message[]) {
  // Keep last 50 messages
  const toSave = messages.slice(-50)
  localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(toSave))
}

async function callAI(messages: { role: string; content: string }[], config: AIConfig): Promise<string> {
  if (!config.apiKey && config.provider !== 'ollama') {
    throw new Error('API key not configured. Go to Settings (⚙️) to add your API key.')
  }

  let url: string
  let headers: Record<string, string>
  let body: unknown

  switch (config.provider) {
    case 'openai':
      url = 'https://api.openai.com/v1/chat/completions'
      headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.apiKey}`,
      }
      body = {
        model: config.model || 'gpt-4o-mini',
        messages,
        temperature: 0.7,
        max_tokens: 2000,
      }
      break

    case 'gemini':
      url = `https://generativelanguage.googleapis.com/v1beta/models/${config.model || 'gemini-1.5-flash'}:generateContent?key=${config.apiKey}`
      headers = { 'Content-Type': 'application/json' }
      body = {
        contents: messages.filter(m => m.role !== 'system').map(m => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: m.content }],
        })),
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
      }
      break

    case 'ollama':
      url = config.baseUrl || 'http://localhost:11434/api/chat'
      headers = { 'Content-Type': 'application/json' }
      body = {
        model: config.model || 'llama3',
        messages,
        stream: false,
      }
      break

    default:
      throw new Error('Unknown provider')
  }

  const response = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  })

  if (!response.ok) {
    const errorText = await response.text()
    throw new Error(`API Error (${response.status}): ${errorText.slice(0, 200)}`)
  }

  const data = await response.json()

  switch (config.provider) {
    case 'openai':
      return data.choices?.[0]?.message?.content || 'No response'
    case 'gemini':
      return data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response'
    case 'ollama':
      return data.message?.content || 'No response'
    default:
      return 'Unknown provider'
  }
}

export default function AIAssistantPage() {
  const [messages, setMessages] = useState<Message[]>(loadHistory)
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [showProblems, setShowProblems] = useState(false)
  const [config, setConfig] = useState<AIConfig>(loadConfig)
  const [error, setError] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  useEffect(() => {
    saveHistory(messages)
  }, [messages])

  const sendMessage = async (content: string) => {
    if (!content.trim()) return
    setError('')

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: content.trim(),
      timestamp: new Date(),
    }

    setMessages(prev => [...prev, userMsg])
    setInput('')
    setIsLoading(true)

    try {
      // Build message history for API
      const apiMessages = [
        { role: 'system', content: SYSTEM_PROMPT },
        ...messages.slice(-20).map(m => ({ role: m.role, content: m.content })),
        { role: 'user', content: content.trim() },
      ]

      const response = await callAI(apiMessages, config)

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      }

      setMessages(prev => [...prev, assistantMsg])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    sendMessage(input)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage(input)
    }
  }

  const askAboutProblem = (title: string) => {
    setShowProblems(false)
    sendMessage(`I'm working on "${title}". Can you help me understand the approach?`)
  }

  const clearHistory = () => {
    setMessages([])
    localStorage.removeItem(HISTORY_STORAGE_KEY)
  }

  const saveSettings = () => {
    saveConfig(config)
    setShowSettings(false)
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 h-[calc(100vh-10rem)] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <Link to="/" className="text-sm text-dark-400 hover:text-primary-400 transition-colors mb-1 block">
            ← Home
          </Link>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            🤖 AI DSA Assistant
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowProblems(!showProblems)}
            className="px-3 py-1.5 bg-dark-700 hover:bg-dark-600 rounded-lg text-xs text-dark-300 hover:text-white transition-colors"
          >
            📋 Problems
          </button>
          <button
            onClick={clearHistory}
            className="px-3 py-1.5 bg-dark-700 hover:bg-dark-600 rounded-lg text-xs text-dark-300 hover:text-white transition-colors"
          >
            🗑️ Clear
          </button>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
              showSettings ? 'bg-primary-600 text-white' : 'bg-dark-700 text-dark-300 hover:bg-dark-600 hover:text-white'
            }`}
          >
            ⚙️ Settings
          </button>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="glass-panel p-4 mb-4"
        >
          <h3 className="text-sm font-semibold text-white mb-3">AI Configuration</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-dark-400 block mb-1">Provider</label>
              <select
                value={config.provider}
                onChange={e => setConfig({ ...config, provider: e.target.value as AIConfig['provider'] })}
                className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm focus:border-primary-500 focus:outline-none"
              >
                <option value="openai">OpenAI (GPT-4o mini, GPT-4)</option>
                <option value="gemini">Google Gemini</option>
                <option value="ollama">Ollama (Local)</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-dark-400 block mb-1">Model</label>
              <input
                type="text"
                value={config.model}
                onChange={e => setConfig({ ...config, model: e.target.value })}
                className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm focus:border-primary-500 focus:outline-none"
                placeholder={config.provider === 'openai' ? 'gpt-4o-mini' : config.provider === 'gemini' ? 'gemini-1.5-flash' : 'llama3'}
              />
            </div>
            <div>
              <label className="text-xs text-dark-400 block mb-1">API Key</label>
              <input
                type="password"
                value={config.apiKey}
                onChange={e => setConfig({ ...config, apiKey: e.target.value })}
                className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm focus:border-primary-500 focus:outline-none"
                placeholder={config.provider === 'ollama' ? 'Not needed' : 'sk-...'}
              />
            </div>
            {config.provider === 'ollama' && (
              <div>
                <label className="text-xs text-dark-400 block mb-1">Base URL</label>
                <input
                  type="text"
                  value={config.baseUrl || ''}
                  onChange={e => setConfig({ ...config, baseUrl: e.target.value })}
                  className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm focus:border-primary-500 focus:outline-none"
                  placeholder="http://localhost:11434/api/chat"
                />
              </div>
            )}
          </div>
          <button
            onClick={saveSettings}
            className="mt-3 px-4 py-2 bg-primary-600 hover:bg-primary-500 rounded-lg text-sm font-medium text-white transition-colors"
          >
            Save Settings
          </button>
          <p className="text-xs text-dark-500 mt-2">
            API keys are stored locally in your browser. Never shared externally.
          </p>
        </motion.div>
      )}

      {/* Problem Picker */}
      {showProblems && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="glass-panel p-4 mb-4 max-h-60 overflow-y-auto"
        >
          <h3 className="text-sm font-semibold text-white mb-3">Ask about a problem:</h3>
          <div className="space-y-2">
            {categories.map(cat => (
              <div key={cat.slug}>
                <p className="text-xs text-dark-400 font-semibold mt-2 mb-1">{cat.icon} {cat.name}</p>
                <div className="flex flex-wrap gap-1">
                  {cat.problems.slice(0, 5).map(p => (
                    <button
                      key={p.slug}
                      onClick={() => askAboutProblem(p.title)}
                      className="px-2 py-1 bg-dark-700 hover:bg-dark-600 rounded text-xs text-dark-300 hover:text-white transition-colors"
                    >
                      {p.title}
                    </button>
                  ))}
                  {cat.problems.length > 5 && (
                    <span className="px-2 py-1 text-xs text-dark-500">+{cat.problems.length - 5} more</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto glass-panel p-4 mb-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center py-12">
            <p className="text-4xl mb-4">🧠</p>
            <h2 className="text-lg font-semibold text-white mb-2">DSA AI Assistant</h2>
            <p className="text-dark-400 text-sm max-w-md mx-auto mb-6">
              Ask me about any DSA problem. I'll give hints, explain approaches, debug your code, or walk through full solutions.
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {[
                'How do I solve Two Sum?',
                'Explain sliding window pattern',
                'Help me with binary search',
                'When to use DFS vs BFS?',
              ].map(suggestion => (
                <button
                  key={suggestion}
                  onClick={() => sendMessage(suggestion)}
                  className="px-3 py-2 bg-dark-700 hover:bg-dark-600 rounded-lg text-xs text-dark-300 hover:text-white transition-colors"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-xl px-4 py-3 ${
                msg.role === 'user'
                  ? 'bg-primary-600/30 border border-primary-500/30 text-white'
                  : 'bg-dark-700/50 border border-dark-600/50 text-dark-200'
              }`}
            >
              <div className="text-sm whitespace-pre-wrap leading-relaxed prose-code">
                <MessageContent content={msg.content} />
              </div>
              <p className="text-[10px] text-dark-500 mt-1.5">
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </motion.div>
        ))}

        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-start"
          >
            <div className="bg-dark-700/50 border border-dark-600/50 rounded-xl px-4 py-3">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </motion.div>
        )}

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-sm text-red-300">
            {error}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Hint shortcuts */}
      <div className="flex gap-2 mb-2 overflow-x-auto pb-1">
        {HINT_LEVELS.map((hint) => (
          <button
            key={hint.label}
            onClick={() => sendMessage(hint.prompt)}
            disabled={isLoading}
            className="px-3 py-1.5 bg-dark-800 hover:bg-dark-700 border border-dark-700 rounded-lg text-xs text-dark-300 hover:text-white transition-colors whitespace-nowrap disabled:opacity-50"
          >
            {hint.label}
          </button>
        ))}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <textarea
          ref={textareaRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask about a DSA problem, paste your code for help, or request hints..."
          className="flex-1 bg-dark-800 border border-dark-700 rounded-xl px-4 py-3 text-white text-sm focus:border-primary-500 focus:outline-none resize-none min-h-[48px] max-h-32"
          rows={1}
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="px-4 py-3 bg-primary-600 hover:bg-primary-500 rounded-xl text-white font-medium text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Send
        </button>
      </form>
    </div>
  )
}

// Simple markdown-ish renderer for code blocks
function MessageContent({ content }: { content: string }) {
  const parts = content.split(/(```[\s\S]*?```)/g)
  
  return (
    <>
      {parts.map((part, i) => {
        if (part.startsWith('```')) {
          const lines = part.slice(3, -3).split('\n')
          const lang = lines[0]?.trim() || ''
          const code = lines.slice(lang ? 1 : 0).join('\n')
          return (
            <pre key={i} className="bg-dark-900 rounded-lg p-3 my-2 overflow-x-auto">
              {lang && <span className="text-[10px] text-dark-500 block mb-1">{lang}</span>}
              <code className="text-xs font-mono text-green-300">{code}</code>
            </pre>
          )
        }
        // Handle inline code
        const inlineParts = part.split(/(`[^`]+`)/g)
        return (
          <span key={i}>
            {inlineParts.map((ip, j) => {
              if (ip.startsWith('`') && ip.endsWith('`')) {
                return (
                  <code key={j} className="bg-dark-700 px-1.5 py-0.5 rounded text-xs font-mono text-primary-300">
                    {ip.slice(1, -1)}
                  </code>
                )
              }
              // Bold
              const boldParts = ip.split(/(\*\*[^*]+\*\*)/g)
              return boldParts.map((bp, k) => {
                if (bp.startsWith('**') && bp.endsWith('**')) {
                  return <strong key={`${j}-${k}`} className="text-white font-semibold">{bp.slice(2, -2)}</strong>
                }
                return <span key={`${j}-${k}`}>{bp}</span>
              })
            })}
          </span>
        )
      })}
    </>
  )
}
