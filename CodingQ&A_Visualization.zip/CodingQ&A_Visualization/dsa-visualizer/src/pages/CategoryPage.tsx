import { useParams, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { getCategoryBySlug } from '../data/problems'

const difficultyColors = {
  Easy: 'text-green-400 bg-green-400/10 border-green-400/30',
  Medium: 'text-amber-400 bg-amber-400/10 border-amber-400/30',
  Hard: 'text-red-400 bg-red-400/10 border-red-400/30',
}

export default function CategoryPage() {
  const { categorySlug } = useParams()
  const category = getCategoryBySlug(categorySlug || '')

  if (!category) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-dark-300">Category not found</h1>
        <Link to="/" className="text-primary-400 hover:underline mt-4 block">← Back to Home</Link>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="mb-8">
        <Link to="/" className="text-sm text-dark-400 hover:text-primary-400 transition-colors mb-4 block">
          ← All Categories
        </Link>
        <div className="flex items-center gap-3">
          <span className="text-3xl">{category.icon}</span>
          <div>
            <h1 className="text-2xl font-bold text-white">{category.name}</h1>
            <p className="text-sm text-dark-400">{category.count} problems</p>
          </div>
        </div>
      </div>

      {/* Problem List */}
      <div className="space-y-2">
        {category.problems.map((problem, i) => (
          <motion.div
            key={problem.slug}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.03 }}
          >
            <Link
              to={`/problem/${problem.slug}`}
              className={`glass-panel p-4 flex items-center justify-between group transition-all duration-200 ${
                problem.hasVisualization
                  ? 'hover:border-primary-500/50 hover:shadow-lg hover:shadow-primary-500/5'
                  : 'opacity-60 hover:opacity-80'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={`text-lg ${problem.hasVisualization ? '🟢' : ''}`}>
                  {problem.hasVisualization ? '▶️' : '⬜'}
                </span>
                <span className="font-medium text-white group-hover:text-primary-300 transition-colors">
                  {problem.title}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className={`text-xs px-2 py-0.5 rounded-full border ${difficultyColors[problem.difficulty]}`}>
                  {problem.difficulty}
                </span>
                {problem.hasVisualization && (
                  <span className="text-xs text-accent-400 font-medium">
                    Visualize →
                  </span>
                )}
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
