import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { categories } from '../data/problems'

export default function HomePage() {
  const totalProblems = categories.reduce((sum, c) => sum + c.count, 0)
  const totalVisualized = categories.reduce(
    (sum, c) => sum + c.problems.filter(p => p.hasVisualization).length, 0
  )

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero */}
      <div className="text-center mb-16">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl sm:text-5xl font-bold mb-4"
        >
          <span className="bg-gradient-to-r from-primary-400 to-accent-400 bg-clip-text text-transparent">
            DSA Visualizer
          </span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-lg text-dark-400 max-w-2xl mx-auto"
        >
          Step-by-step animated walkthroughs for {totalProblems} coding problems.
          See how pointers move, trees traverse, and algorithms think.
        </motion.p>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mt-6 flex justify-center gap-6 text-sm"
        >
          <div className="glass-panel px-4 py-2">
            <span className="text-primary-400 font-semibold">{totalProblems}</span>
            <span className="text-dark-400 ml-1">Problems</span>
          </div>
          <div className="glass-panel px-4 py-2">
            <span className="text-accent-400 font-semibold">{totalVisualized}</span>
            <span className="text-dark-400 ml-1">Visualized</span>
          </div>
          <div className="glass-panel px-4 py-2">
            <span className="text-amber-400 font-semibold">{categories.length}</span>
            <span className="text-dark-400 ml-1">Categories</span>
          </div>
        </motion.div>
      </div>

      {/* Category Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((category, i) => (
          <motion.div
            key={category.slug}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Link
              to={`/category/${category.slug}`}
              className="glass-panel p-5 block group hover:border-primary-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary-500/5"
            >
              <div className="flex items-center gap-3 mb-3">
                <span className="text-2xl">{category.icon}</span>
                <h2 className="font-semibold text-white group-hover:text-primary-300 transition-colors">
                  {category.name}
                </h2>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-dark-400">
                  {category.count} problems
                </span>
                <div className="flex items-center gap-1">
                  <span className="text-xs text-accent-400">
                    {category.problems.filter(p => p.hasVisualization).length} visualized
                  </span>
                </div>
              </div>
              {/* Progress bar */}
              <div className="mt-3 h-1.5 bg-dark-700 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full bg-gradient-to-r ${category.color}`}
                  style={{
                    width: `${(category.problems.filter(p => p.hasVisualization).length / category.count) * 100}%`
                  }}
                />
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
