import { useState, useCallback, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { useVisualizerStore, VisualizationStep } from '../store/useVisualizerStore'
import { useCustomProblems } from '../store/useCustomProblems'
import StepControls from '../components/StepControls'
import ArrayVisualizer from '../components/ArrayVisualizer'

interface StepDraft {
  description: string
  codeLines: string
  arrayStr: string
  pointersStr: string
  highlightsStr: string
  foundStr: string
  explanation: string
  hashMapStr: string
}

const emptyDraft: StepDraft = {
  description: '',
  codeLines: '',
  arrayStr: '',
  pointersStr: '',
  highlightsStr: '',
  foundStr: '',
  explanation: '',
  hashMapStr: '',
}

function parseArray(str: string): number[] | string[] {
  if (!str.trim()) return []
  try {
    const parsed = JSON.parse(`[${str}]`)
    return parsed
  } catch {
    // Try as strings
    return str.split(',').map(s => s.trim().replace(/['"]/g, ''))
  }
}

function parsePointers(str: string): Record<string, number> {
  if (!str.trim()) return {}
  const result: Record<string, number> = {}
  str.split(',').forEach(pair => {
    const [key, val] = pair.split(':').map(s => s.trim())
    if (key && val !== undefined) result[key] = parseInt(val)
  })
  return result
}

function parseIndices(str: string): number[] {
  if (!str.trim()) return []
  return str.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n))
}

function parseHashMap(str: string): Record<string, unknown> | null {
  if (!str.trim()) return null
  try {
    return JSON.parse(str)
  } catch {
    // Try key:value pairs
    const result: Record<string, string> = {}
    str.split(',').forEach(pair => {
      const [key, val] = pair.split(':').map(s => s.trim())
      if (key && val !== undefined) result[key] = val
    })
    return result
  }
}

export default function BuilderPage() {
  const { setSteps, steps } = useVisualizerStore()
  const { addProblem, problems, loadFromStorage } = useCustomProblems()
  const [code, setCode] = useState(`def twoSum(nums, target):\n    hashmap = {}\n    for i, n in enumerate(nums):\n        complement = target - n\n        if complement in hashmap:\n            return [hashmap[complement], i]\n        hashmap[n] = i\n    return []`)
  const [title, setTitle] = useState('My Problem')
  const [draftSteps, setDraftSteps] = useState<StepDraft[]>([{ ...emptyDraft }])
  const [editingIndex, setEditingIndex] = useState(0)
  const [previewMode, setPreviewMode] = useState(false)
  const [exportJson, setExportJson] = useState('')
  const [saveMessage, setSaveMessage] = useState('')

  useEffect(() => {
    loadFromStorage()
  }, [loadFromStorage])

  const currentDraft = draftSteps[editingIndex]

  const updateDraft = (field: keyof StepDraft, value: string) => {
    setDraftSteps(prev => {
      const updated = [...prev]
      updated[editingIndex] = { ...updated[editingIndex], [field]: value }
      return updated
    })
  }

  const addStep = () => {
    // Copy array and pointers from previous step for convenience
    const prev = draftSteps[draftSteps.length - 1]
    const newStep = { ...emptyDraft, arrayStr: prev.arrayStr, pointersStr: prev.pointersStr }
    setDraftSteps(prev => [...prev, newStep])
    setEditingIndex(draftSteps.length)
  }

  const removeStep = (index: number) => {
    if (draftSteps.length <= 1) return
    setDraftSteps(prev => prev.filter((_, i) => i !== index))
    if (editingIndex >= draftSteps.length - 1) {
      setEditingIndex(Math.max(0, editingIndex - 1))
    }
  }

  const duplicateStep = (index: number) => {
    const copy = { ...draftSteps[index] }
    setDraftSteps(prev => [...prev.slice(0, index + 1), copy, ...prev.slice(index + 1)])
    setEditingIndex(index + 1)
  }

  const buildSteps = useCallback((): VisualizationStep[] => {
    return draftSteps.map(draft => ({
      description: draft.description,
      codeLineHighlight: parseIndices(draft.codeLines),
      state: {
        array: parseArray(draft.arrayStr),
        ...(parseHashMap(draft.hashMapStr) ? { hashMap: parseHashMap(draft.hashMapStr) } : {}),
      },
      pointers: parsePointers(draft.pointersStr),
      highlights: parseIndices(draft.highlightsStr),
      found: parseIndices(draft.foundStr),
      explanation: draft.explanation || undefined,
    }))
  }, [draftSteps])

  const handlePreview = () => {
    const built = buildSteps()
    setSteps(built)
    setPreviewMode(true)
  }

  const handleExport = () => {
    const built = buildSteps()
    const exportData = {
      slug: title.toLowerCase().replace(/\s+/g, '-'),
      description: '',
      approach: '',
      timeComplexity: 'O(?)',
      spaceComplexity: 'O(?)',
      visualizerTitle: title,
      code,
      steps: built,
    }
    setExportJson(JSON.stringify(exportData, null, 2))
  }

  const handleImport = (jsonStr: string) => {
    try {
      const data = JSON.parse(jsonStr)
      if (data.code) setCode(data.code)
      if (data.visualizerTitle) setTitle(data.visualizerTitle)
      if (data.steps && Array.isArray(data.steps)) {
        const imported: StepDraft[] = data.steps.map((step: VisualizationStep) => ({
          description: step.description || '',
          codeLines: (step.codeLineHighlight || []).join(', '),
          arrayStr: Array.isArray(step.state?.array) 
            ? step.state.array.map((v: unknown) => typeof v === 'string' ? `"${v}"` : v).join(', ')
            : '',
          pointersStr: Object.entries(step.pointers || {}).map(([k, v]) => `${k}:${v}`).join(', '),
          highlightsStr: (step.highlights || []).join(', '),
          foundStr: (step.found || []).join(', '),
          explanation: step.explanation || '',
          hashMapStr: step.state?.hashMap ? JSON.stringify(step.state.hashMap) : '',
        }))
        setDraftSteps(imported)
        setEditingIndex(0)
      }
    } catch (e) {
      alert('Invalid JSON format')
    }
  }

  const handleSave = () => {
    const built = buildSteps()
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
    const visualization = {
      slug,
      description: '',
      approach: '',
      timeComplexity: 'O(?)',
      spaceComplexity: 'O(?)',
      visualizerTitle: title,
      code,
      steps: built,
    }
    addProblem({
      slug,
      title,
      category: 'Custom',
      visualization,
      createdAt: new Date().toISOString(),
    })
    setSaveMessage(`✅ Saved "${title}" — view at /problem/custom-${slug}`)
    setTimeout(() => setSaveMessage(''), 4000)
  }

  if (previewMode) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-white">{title} — Preview</h1>
          <button
            onClick={() => setPreviewMode(false)}
            className="px-4 py-2 bg-dark-700 hover:bg-dark-600 rounded-lg text-sm font-medium text-white transition-colors"
          >
            ← Back to Editor
          </button>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-6">
            <div className="glass-panel p-6">
              <ArrayVisualizer title={title} />
            </div>
            <StepControls />
          </div>
          <div className="glass-panel overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2 border-b border-dark-700/50">
              <span className="text-xs font-mono text-dark-400">solution.py</span>
            </div>
            <pre className="p-4 text-sm font-mono overflow-auto max-h-[500px]">
              {code.split('\n').map((line, i) => {
                const step = steps[useVisualizerStore.getState().currentStep]
                const isHighlighted = step?.codeLineHighlight?.includes(i + 1)
                return (
                  <div key={i} className={`flex ${isHighlighted ? 'bg-primary-500/15 border-l-2 border-primary-500' : 'border-l-2 border-transparent'} -ml-2 pl-2`}>
                    <span className="inline-block w-8 text-right mr-4 text-dark-600 select-none text-xs leading-6">{i + 1}</span>
                    <span className={`leading-6 ${isHighlighted ? 'text-white' : 'text-dark-300'}`}>{line || ' '}</span>
                  </div>
                )
              })}
            </pre>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <Link to="/" className="text-sm text-dark-400 hover:text-primary-400 transition-colors mb-2 block">
            ← Home
          </Link>
          <h1 className="text-2xl font-bold text-white">Visualization Builder</h1>
          <p className="text-dark-400 text-sm mt-1">Write your code, define steps, preview the animation</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={handlePreview}
            className="px-4 py-2 bg-primary-600 hover:bg-primary-500 rounded-lg text-sm font-semibold text-white transition-colors shadow-lg shadow-primary-600/30"
          >
            ▶️ Preview
          </button>
          <button
            onClick={handleExport}
            className="px-4 py-2 bg-accent-600 hover:bg-accent-500 rounded-lg text-sm font-semibold text-white transition-colors"
          >
            📦 Export
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-green-600 hover:bg-green-500 rounded-lg text-sm font-semibold text-white transition-colors"
          >
            💾 Save
          </button>
        </div>
      </div>

      {/* Save message */}
      {saveMessage && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-4 p-3 bg-green-500/10 border border-green-500/30 rounded-lg text-sm text-green-300"
        >
          {saveMessage}
        </motion.div>
      )}

      {/* Saved custom problems */}
      {problems.length > 0 && (
        <div className="mb-6 glass-panel p-4">
          <h3 className="text-xs text-dark-400 uppercase tracking-wider mb-2">Your Saved Visualizations ({problems.length})</h3>
          <div className="flex flex-wrap gap-2">
            {problems.map(p => (
              <Link
                key={p.slug}
                to={`/problem/custom-${p.slug}`}
                className="px-3 py-1.5 bg-dark-700 hover:bg-dark-600 rounded-lg text-xs text-dark-300 hover:text-white transition-colors"
              >
                {p.title}
              </Link>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Code Editor + Title */}
        <div className="space-y-4">
          {/* Title */}
          <div className="glass-panel p-4">
            <label className="text-xs text-dark-400 uppercase tracking-wider block mb-2">Problem Title</label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm focus:border-primary-500 focus:outline-none"
              placeholder="e.g. Two Sum"
            />
          </div>

          {/* Code */}
          <div className="glass-panel p-4">
            <label className="text-xs text-dark-400 uppercase tracking-wider block mb-2">
              Solution Code (Python/JS)
            </label>
            <textarea
              value={code}
              onChange={e => setCode(e.target.value)}
              className="w-full h-64 bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-green-300 text-sm font-mono focus:border-primary-500 focus:outline-none resize-y"
              spellCheck={false}
            />
            <p className="text-xs text-dark-500 mt-2">
              Line numbers in "Code Lines" below refer to lines in this code (1-indexed).
            </p>
          </div>

          {/* Import */}
          <div className="glass-panel p-4">
            <label className="text-xs text-dark-400 uppercase tracking-wider block mb-2">
              Import / Export JSON
            </label>
            <textarea
              value={exportJson}
              onChange={e => setExportJson(e.target.value)}
              className="w-full h-32 bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-dark-300 text-xs font-mono focus:border-primary-500 focus:outline-none resize-y"
              placeholder='Paste exported JSON here to re-import...'
            />
            <button
              onClick={() => handleImport(exportJson)}
              className="mt-2 px-3 py-1.5 bg-dark-700 hover:bg-dark-600 rounded-md text-xs text-dark-300 hover:text-white transition-colors"
            >
              Import JSON
            </button>
          </div>
        </div>

        {/* Right: Steps Editor */}
        <div className="space-y-4">
          {/* Step tabs */}
          <div className="glass-panel p-3">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-dark-400 uppercase tracking-wider">
                Steps ({draftSteps.length})
              </span>
              <button
                onClick={addStep}
                className="px-3 py-1 bg-primary-600/30 hover:bg-primary-600/50 border border-primary-500/50 rounded-md text-xs text-primary-300 transition-colors"
              >
                + Add Step
              </button>
            </div>
            <div className="flex flex-wrap gap-1">
              {draftSteps.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setEditingIndex(i)}
                  className={`px-2.5 py-1 rounded-md text-xs font-mono transition-all ${
                    i === editingIndex
                      ? 'bg-primary-600 text-white'
                      : 'bg-dark-700 text-dark-400 hover:text-white'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </div>

          {/* Current step editor */}
          <motion.div
            key={editingIndex}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-panel p-4 space-y-3"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">Step {editingIndex + 1}</h3>
              <div className="flex gap-2">
                <button
                  onClick={() => duplicateStep(editingIndex)}
                  className="text-xs text-dark-400 hover:text-primary-400 transition-colors"
                  title="Duplicate step"
                >
                  📋 Duplicate
                </button>
                <button
                  onClick={() => removeStep(editingIndex)}
                  className="text-xs text-dark-400 hover:text-red-400 transition-colors"
                  title="Delete step"
                >
                  🗑️ Delete
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs text-dark-500 block mb-1">Description (what happens in this step)</label>
              <input
                type="text"
                value={currentDraft.description}
                onChange={e => updateDraft('description', e.target.value)}
                className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm focus:border-primary-500 focus:outline-none"
                placeholder="e.g. Check if complement exists in hashmap"
              />
            </div>

            <div>
              <label className="text-xs text-dark-500 block mb-1">Array Values (comma-separated)</label>
              <input
                type="text"
                value={currentDraft.arrayStr}
                onChange={e => updateDraft('arrayStr', e.target.value)}
                className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm font-mono focus:border-primary-500 focus:outline-none"
                placeholder='e.g. 2, 7, 11, 15  or  "a", "b", "c"'
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-dark-500 block mb-1">Pointers (name:index)</label>
                <input
                  type="text"
                  value={currentDraft.pointersStr}
                  onChange={e => updateDraft('pointersStr', e.target.value)}
                  className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm font-mono focus:border-primary-500 focus:outline-none"
                  placeholder="i:0, j:3"
                />
              </div>
              <div>
                <label className="text-xs text-dark-500 block mb-1">Code Lines (highlighted)</label>
                <input
                  type="text"
                  value={currentDraft.codeLines}
                  onChange={e => updateDraft('codeLines', e.target.value)}
                  className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm font-mono focus:border-primary-500 focus:outline-none"
                  placeholder="4, 5, 6"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-dark-500 block mb-1">Highlights (active indices)</label>
                <input
                  type="text"
                  value={currentDraft.highlightsStr}
                  onChange={e => updateDraft('highlightsStr', e.target.value)}
                  className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm font-mono focus:border-primary-500 focus:outline-none"
                  placeholder="0, 1"
                />
              </div>
              <div>
                <label className="text-xs text-dark-500 block mb-1">Found (green indices)</label>
                <input
                  type="text"
                  value={currentDraft.foundStr}
                  onChange={e => updateDraft('foundStr', e.target.value)}
                  className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm font-mono focus:border-primary-500 focus:outline-none"
                  placeholder="0, 1"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-dark-500 block mb-1">HashMap / Extra State (JSON)</label>
              <input
                type="text"
                value={currentDraft.hashMapStr}
                onChange={e => updateDraft('hashMapStr', e.target.value)}
                className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm font-mono focus:border-primary-500 focus:outline-none"
                placeholder='{"key": "value"} or key:val, key2:val2'
              />
            </div>

            <div>
              <label className="text-xs text-dark-500 block mb-1">Explanation (extra context, optional)</label>
              <input
                type="text"
                value={currentDraft.explanation}
                onChange={e => updateDraft('explanation', e.target.value)}
                className="w-full bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 text-white text-sm focus:border-primary-500 focus:outline-none"
                placeholder="✅ Found the answer!"
              />
            </div>
          </motion.div>

          {/* Live mini-preview of current step */}
          <div className="glass-panel p-4">
            <h4 className="text-xs text-dark-400 uppercase tracking-wider mb-3">Step {editingIndex + 1} Preview</h4>
            <div className="flex flex-wrap gap-2">
              {parseArray(currentDraft.arrayStr).map((val, i) => {
                const ptrs = parsePointers(currentDraft.pointersStr)
                const highlights = parseIndices(currentDraft.highlightsStr)
                const found = parseIndices(currentDraft.foundStr)
                const pointerNames = Object.entries(ptrs).filter(([_, idx]) => idx === i).map(([name]) => name)
                const isHighlighted = highlights.includes(i)
                const isFound = found.includes(i)
                
                return (
                  <div key={i} className="flex flex-col items-center">
                    <div className="h-5 text-[10px] text-primary-400 font-mono">
                      {pointerNames.join(',')}
                      {pointerNames.length > 0 && '↓'}
                    </div>
                    <div className={`w-10 h-10 flex items-center justify-center border-2 rounded-lg text-sm font-mono font-semibold ${
                      isFound ? 'border-green-400 bg-green-400/20 text-green-300'
                      : isHighlighted ? 'border-accent-400 bg-accent-400/20 text-accent-300'
                      : pointerNames.length > 0 ? 'border-primary-400 bg-primary-400/20 text-primary-300'
                      : 'border-dark-600 text-dark-300'
                    }`}>
                      {String(val)}
                    </div>
                    <span className="text-[10px] text-dark-600 mt-0.5">{i}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
