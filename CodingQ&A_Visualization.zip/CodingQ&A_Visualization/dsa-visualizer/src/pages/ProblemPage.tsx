import { useParams, Link } from 'react-router-dom'
import { useEffect } from 'react'
import { getProblemBySlug } from '../data/problems'
import { useVisualizerStore } from '../store/useVisualizerStore'
import { useCustomProblems } from '../store/useCustomProblems'
import { getVisualization } from '../visualizations'
import StepControls from '../components/StepControls'
import CodePanel from '../components/CodePanel'
import ArrayVisualizer from '../components/ArrayVisualizer'

const difficultyColors = {
  Easy: 'text-green-400',
  Medium: 'text-amber-400',
  Hard: 'text-red-400',
}

export default function ProblemPage() {
  const { problemSlug } = useParams()
  const { setSteps, reset } = useVisualizerStore()
  const { loadFromStorage, getBySlug: getCustomBySlug } = useCustomProblems()

  useEffect(() => {
    loadFromStorage()
  }, [loadFromStorage])

  // Check if it's a custom problem (slug starts with "custom-")
  const isCustom = problemSlug?.startsWith('custom-')
  const customSlug = isCustom ? problemSlug!.replace('custom-', '') : ''
  const customProblem = isCustom ? getCustomBySlug(customSlug) : undefined

  const problem = isCustom
    ? customProblem ? { slug: customProblem.slug, title: customProblem.title, difficulty: 'Medium' as const, category: 'Custom', categorySlug: 'custom', hasVisualization: true } : undefined
    : getProblemBySlug(problemSlug || '')

  const visualization = isCustom
    ? customProblem?.visualization || null
    : problem ? getVisualization(problem.slug) : null

  useEffect(() => {
    if (visualization) {
      setSteps(visualization.steps)
    }
    return () => reset()
  }, [problemSlug, visualization, setSteps, reset])

  if (!problem) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-dark-300">Problem not found</h1>
        <Link to="/" className="text-primary-400 hover:underline mt-4 block">← Back to Home</Link>
      </div>
    )
  }

  if (!visualization) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12">
        <Link to={`/category/${problem.categorySlug}`} className="text-sm text-dark-400 hover:text-primary-400 transition-colors mb-4 block">
          ← {problem.category}
        </Link>
        <h1 className="text-2xl font-bold text-white mb-2">{problem.title}</h1>
        <p className={`text-sm ${difficultyColors[problem.difficulty]}`}>{problem.difficulty}</p>
        <div className="glass-panel p-8 mt-8 text-center">
          <p className="text-dark-400 text-lg">🚧 Visualization coming soon</p>
          <p className="text-dark-500 text-sm mt-2">This problem doesn't have a visualization yet.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-6">
        <Link to={`/category/${problem.categorySlug}`} className="text-sm text-dark-400 hover:text-primary-400 transition-colors mb-2 block">
          ← {problem.category}
        </Link>
        <div className="flex items-center gap-4">
          <h1 className="text-2xl font-bold text-white">{problem.title}</h1>
          <span className={`text-sm font-medium ${difficultyColors[problem.difficulty]}`}>
            {problem.difficulty}
          </span>
          <Link
            to={`/assistant`}
            state={{ problem: problem.title }}
            className="ml-auto px-3 py-1.5 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs text-amber-300 hover:bg-amber-500/20 transition-colors"
          >
            🤖 Ask AI for Help
          </Link>
        </div>
        {visualization.description && (
          <p className="text-dark-400 mt-2 max-w-3xl">{visualization.description}</p>
        )}
      </div>

      {/* Main layout: Visualization + Code side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Visualization */}
        <div className="space-y-6">
          <div className="glass-panel p-6">
            <ArrayVisualizer title={visualization.visualizerTitle || 'Array'} />
          </div>
          <StepControls />
        </div>

        {/* Right: Code */}
        <div>
          <CodePanel code={visualization.code} />
          
          {/* Approach explanation */}
          {visualization.approach && (
            <div className="glass-panel p-5 mt-6">
              <h3 className="text-sm font-semibold text-dark-300 uppercase tracking-wider mb-3">
                Approach
              </h3>
              <p className="text-sm text-dark-300 leading-relaxed">{visualization.approach}</p>
              <div className="mt-4 flex gap-4 text-xs text-dark-400">
                <span>Time: <code className="text-primary-400">{visualization.timeComplexity}</code></span>
                <span>Space: <code className="text-primary-400">{visualization.spaceComplexity}</code></span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
