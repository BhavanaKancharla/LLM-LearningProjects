import { Visualization } from './index'

export const reverseLinkedListVisualization: Visualization = {
  slug: 'reverse-linked-list',
  description: 'Given the head of a singly linked list, reverse the list, and return the reversed list.',
  approach: 'Iterate through the list. At each node, redirect its next pointer to the previous node. Track prev, curr, and next pointers.',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(1)',
  visualizerTitle: 'head = [1, 2, 3, 4, 5]',
  code: `def reverseList(head):
    prev = None
    curr = head
    
    while curr:
        nxt = curr.next
        curr.next = prev
        prev = curr
        curr = nxt
    
    return prev`,
  steps: [
    {
      description: 'Initialize: prev=None, curr=1 (head).',
      codeLineHighlight: [2, 3],
      state: { array: [1, 2, 3, 4, 5], hashMap: { prev: 'None' } },
      pointers: { curr: 0 },
      highlights: [],
    },
    {
      description: 'Save nxt=2. Point 1→None (was 1→2). Move prev=1, curr=2.',
      codeLineHighlight: [6, 7, 8, 9],
      state: { array: [1, 2, 3, 4, 5], hashMap: { prev: '1', direction: 'None ← 1  2 → 3 → 4 → 5' } },
      pointers: { prev: 0, curr: 1 },
      highlights: [0],
      explanation: 'Node 1 now points to None (reversed)',
    },
    {
      description: 'Save nxt=3. Point 2→1 (was 2→3). Move prev=2, curr=3.',
      codeLineHighlight: [6, 7, 8, 9],
      state: { array: [1, 2, 3, 4, 5], hashMap: { prev: '2', direction: 'None ← 1 ← 2  3 → 4 → 5' } },
      pointers: { prev: 1, curr: 2 },
      highlights: [0, 1],
      explanation: 'Node 2 now points to 1',
    },
    {
      description: 'Save nxt=4. Point 3→2 (was 3→4). Move prev=3, curr=4.',
      codeLineHighlight: [6, 7, 8, 9],
      state: { array: [1, 2, 3, 4, 5], hashMap: { prev: '3', direction: 'None ← 1 ← 2 ← 3  4 → 5' } },
      pointers: { prev: 2, curr: 3 },
      highlights: [0, 1, 2],
      explanation: 'Node 3 now points to 2',
    },
    {
      description: 'Save nxt=5. Point 4→3 (was 4→5). Move prev=4, curr=5.',
      codeLineHighlight: [6, 7, 8, 9],
      state: { array: [1, 2, 3, 4, 5], hashMap: { prev: '4', direction: 'None ← 1 ← 2 ← 3 ← 4  5' } },
      pointers: { prev: 3, curr: 4 },
      highlights: [0, 1, 2, 3],
      explanation: 'Node 4 now points to 3',
    },
    {
      description: 'Save nxt=None. Point 5→4. Move prev=5, curr=None. Loop ends!',
      codeLineHighlight: [6, 7, 8, 9],
      state: { array: [1, 2, 3, 4, 5], hashMap: { prev: '5', direction: 'None ← 1 ← 2 ← 3 ← 4 ← 5' } },
      pointers: { prev: 4 },
      highlights: [0, 1, 2, 3, 4],
      explanation: 'Node 5 now points to 4 — fully reversed!',
    },
    {
      description: 'Return prev (node 5) — new head of reversed list: 5→4→3→2→1→None',
      codeLineHighlight: [11],
      state: { array: [5, 4, 3, 2, 1], hashMap: { result: '5 → 4 → 3 → 2 → 1 → None' } },
      pointers: {},
      highlights: [],
      found: [0, 1, 2, 3, 4],
      explanation: '✅ List reversed: [5, 4, 3, 2, 1]',
    },
  ],
}
