import { Visualization } from './index'

export const validParenthesesVisualization: Visualization = {
  slug: 'valid-parentheses',
  description: 'Given a string containing just the characters (){}[], determine if the input string is valid.',
  approach: 'Use a stack. For every opening bracket, push its corresponding closing bracket. For every closing bracket, check if it matches the top of the stack.',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(n)',
  visualizerTitle: 's = "{[()]}"',
  code: `def isValid(s):
    stack = []
    closeToOpen = {")": "(", "]": "[", "}": "{"}
    
    for c in s:
        if c in closeToOpen:
            if stack and stack[-1] == closeToOpen[c]:
                stack.pop()
            else:
                return False
        else:
            stack.append(c)
    
    return len(stack) == 0`,
  steps: [
    {
      description: 'Initialize empty stack. Process string "{[()]}".',
      codeLineHighlight: [2, 3],
      state: { array: ['{','[','(',')',']','}'], hashMap: { stack: '[]' } },
      pointers: {},
      highlights: [],
    },
    {
      description: 'c="{" — opening bracket. Push to stack.',
      codeLineHighlight: [11, 12],
      state: { array: ['{','[','(',')',']','}'], hashMap: { stack: '["{"]' } },
      pointers: { c: 0 },
      highlights: [0],
    },
    {
      description: 'c="[" — opening bracket. Push to stack.',
      codeLineHighlight: [11, 12],
      state: { array: ['{','[','(',')',']','}'], hashMap: { stack: '["{", "["]' } },
      pointers: { c: 1 },
      highlights: [1],
    },
    {
      description: 'c="(" — opening bracket. Push to stack.',
      codeLineHighlight: [11, 12],
      state: { array: ['{','[','(',')',']','}'], hashMap: { stack: '["{", "[", "("]' } },
      pointers: { c: 2 },
      highlights: [2],
    },
    {
      description: 'c=")" — closing bracket. Top of stack is "(". Match! Pop.',
      codeLineHighlight: [6, 7, 8],
      state: { array: ['{','[','(',')',']','}'], hashMap: { stack: '["{", "["]' } },
      pointers: { c: 3 },
      highlights: [3],
      found: [2, 3],
      explanation: '")" matches "(" at top of stack ✓',
    },
    {
      description: 'c="]" — closing bracket. Top of stack is "[". Match! Pop.',
      codeLineHighlight: [6, 7, 8],
      state: { array: ['{','[','(',')',']','}'], hashMap: { stack: '["{"]' } },
      pointers: { c: 4 },
      highlights: [4],
      found: [1, 2, 3, 4],
      explanation: '"]" matches "[" at top of stack ✓',
    },
    {
      description: 'c="}" — closing bracket. Top of stack is "{". Match! Pop.',
      codeLineHighlight: [6, 7, 8],
      state: { array: ['{','[','(',')',']','}'], hashMap: { stack: '[]' } },
      pointers: { c: 5 },
      highlights: [5],
      found: [0, 1, 2, 3, 4, 5],
      explanation: '"}" matches "{" at top of stack ✓',
    },
    {
      description: 'Stack is empty! Return True — valid parentheses.',
      codeLineHighlight: [14],
      state: { array: ['{','[','(',')',']','}'], hashMap: { stack: '[]' } },
      pointers: {},
      highlights: [],
      found: [0, 1, 2, 3, 4, 5],
      explanation: '✅ All brackets matched correctly!',
    },
  ],
}
