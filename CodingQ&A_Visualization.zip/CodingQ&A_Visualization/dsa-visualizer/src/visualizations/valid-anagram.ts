import { Visualization } from './index'

export const validAnagramVisualization: Visualization = {
  slug: 'valid-anagram',
  description: 'Given two strings s and t, return true if t is an anagram of s.',
  approach: 'Count character frequencies for both strings using a hashmap, then compare. Alternatively, sort both strings and compare.',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(1) — at most 26 keys',
  visualizerTitle: 's = "anagram", t = "nagaram"',
  code: `def isAnagram(s, t):
    if len(s) != len(t):
        return False
    
    count = {}
    for c in s:
        count[c] = count.get(c, 0) + 1
    
    for c in t:
        count[c] = count.get(c, 0) - 1
        if count[c] < 0:
            return False
    
    return True`,
  steps: [
    {
      description: 'Check lengths: len("anagram")=7, len("nagaram")=7. Equal, continue.',
      codeLineHighlight: [2, 3],
      state: { array: [97, 110, 97, 103, 114, 97, 109], hashMap: {} },
      pointers: {},
      highlights: [],
      explanation: 's = "anagram", t = "nagaram" — same length ✓',
    },
    {
      description: 'Count chars in s: processing "a","n","a","g","r","a","m"',
      codeLineHighlight: [6, 7],
      state: { array: [97, 110, 97, 103, 114, 97, 109], hashMap: { a: 3, n: 1, g: 1, r: 1, m: 1 } },
      pointers: {},
      highlights: [0, 1, 2, 3, 4, 5, 6],
      explanation: 'Character frequencies for s built.',
    },
    {
      description: 'Subtract chars from t: "n" → count[n]=1-1=0',
      codeLineHighlight: [9, 10],
      state: { array: [97, 110, 97, 103, 114, 97, 109], hashMap: { a: 3, n: 0, g: 1, r: 1, m: 1 } },
      pointers: {},
      highlights: [],
    },
    {
      description: 'Subtract "a" → count[a]=3-1=2, "g" → count[g]=1-1=0, "a" → count[a]=2-1=1',
      codeLineHighlight: [9, 10],
      state: { array: [97, 110, 97, 103, 114, 97, 109], hashMap: { a: 1, n: 0, g: 0, r: 1, m: 1 } },
      pointers: {},
      highlights: [],
    },
    {
      description: 'Subtract "r" → 0, "a" → 0, "m" → 0. All counts are 0!',
      codeLineHighlight: [13],
      state: { array: [97, 110, 97, 103, 114, 97, 109], hashMap: { a: 0, n: 0, g: 0, r: 0, m: 0 } },
      pointers: {},
      highlights: [],
      found: [0, 1, 2, 3, 4, 5, 6],
      explanation: '✅ All character counts are 0 — it IS a valid anagram!',
    },
  ],
}
