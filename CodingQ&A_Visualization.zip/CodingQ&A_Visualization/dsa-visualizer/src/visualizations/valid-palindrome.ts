import { Visualization } from './index'

export const validPalindromeVisualization: Visualization = {
  slug: 'valid-palindrome',
  description: 'Given a string s, determine if it is a palindrome, considering only alphanumeric characters and ignoring cases.',
  approach: 'Use two pointers starting from both ends. Skip non-alphanumeric characters. Compare characters at both pointers — if they ever differ, it is not a palindrome.',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(1)',
  visualizerTitle: 's = "racecar"',
  code: `def isPalindrome(s):
    l, r = 0, len(s) - 1
    
    while l < r:
        while l < r and not s[l].isalnum():
            l += 1
        while l < r and not s[r].isalnum():
            r -= 1
        if s[l].lower() != s[r].lower():
            return False
        l += 1
        r -= 1
    
    return True`,
  steps: [
    {
      description: 'Initialize two pointers: l=0 (start), r=6 (end).',
      codeLineHighlight: [2],
      state: { array: ['r','a','c','e','c','a','r'] },
      pointers: { l: 0, r: 6 },
      highlights: [],
    },
    {
      description: 'Compare s[0]="r" with s[6]="r" — match! Move pointers inward.',
      codeLineHighlight: [9, 11, 12],
      state: { array: ['r','a','c','e','c','a','r'] },
      pointers: { l: 0, r: 6 },
      highlights: [0, 6],
      found: [0, 6],
      explanation: '"r" == "r" ✓',
    },
    {
      description: 'Compare s[1]="a" with s[5]="a" — match! Move pointers inward.',
      codeLineHighlight: [9, 11, 12],
      state: { array: ['r','a','c','e','c','a','r'] },
      pointers: { l: 1, r: 5 },
      highlights: [1, 5],
      found: [0, 1, 5, 6],
      explanation: '"a" == "a" ✓',
    },
    {
      description: 'Compare s[2]="c" with s[4]="c" — match! Move pointers inward.',
      codeLineHighlight: [9, 11, 12],
      state: { array: ['r','a','c','e','c','a','r'] },
      pointers: { l: 2, r: 4 },
      highlights: [2, 4],
      found: [0, 1, 2, 4, 5, 6],
      explanation: '"c" == "c" ✓',
    },
    {
      description: 'l=3, r=3. l is NOT < r, so loop ends. Return True — it IS a palindrome!',
      codeLineHighlight: [14],
      state: { array: ['r','a','c','e','c','a','r'] },
      pointers: { l: 3, r: 3 },
      highlights: [3],
      found: [0, 1, 2, 3, 4, 5, 6],
      explanation: '✅ "racecar" is a palindrome!',
    },
  ],
}
