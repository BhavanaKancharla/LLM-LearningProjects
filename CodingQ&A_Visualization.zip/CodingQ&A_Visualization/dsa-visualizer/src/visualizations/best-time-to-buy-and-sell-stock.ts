import { Visualization } from './index'

export const bestTimeToBuyAndSellStockVisualization: Visualization = {
  slug: 'best-time-to-buy-and-sell-stock',
  description: 'Given prices where prices[i] is the price on the ith day, find the maximum profit from one buy-sell transaction.',
  approach: 'Use a sliding window / two pointer approach. Track the minimum price seen so far (buy day) and calculate profit at each step. Keep the maximum profit.',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(1)',
  visualizerTitle: 'prices = [7, 1, 5, 3, 6, 4]',
  code: `def maxProfit(prices):
    maxP = 0
    l = 0  # buy day
    
    for r in range(1, len(prices)):
        if prices[r] < prices[l]:
            l = r  # new minimum found
        else:
            profit = prices[r] - prices[l]
            maxP = max(maxP, profit)
    
    return maxP`,
  steps: [
    {
      description: 'Initialize: maxProfit=0, l=0 (buy at price 7).',
      codeLineHighlight: [2, 3],
      state: { array: [7, 1, 5, 3, 6, 4], hashMap: { maxProfit: 0 } },
      pointers: { l: 0 },
      highlights: [],
    },
    {
      description: 'r=1, prices[1]=1 < prices[0]=7. Found lower buy price! Move l to 1.',
      codeLineHighlight: [6, 7],
      state: { array: [7, 1, 5, 3, 6, 4], hashMap: { maxProfit: 0 } },
      pointers: { l: 0, r: 1 },
      highlights: [1],
      explanation: 'New minimum found: buy at 1 instead of 7',
    },
    {
      description: 'r=2, prices[2]=5 > prices[1]=1. Profit = 5-1=4. maxProfit=4.',
      codeLineHighlight: [8, 9, 10],
      state: { array: [7, 1, 5, 3, 6, 4], hashMap: { maxProfit: 4, profit: 4 } },
      pointers: { l: 1, r: 2 },
      highlights: [1, 2],
      explanation: 'Buy at 1, sell at 5 → profit = 4',
    },
    {
      description: 'r=3, prices[3]=3 > prices[1]=1. Profit = 3-1=2. maxProfit stays 4.',
      codeLineHighlight: [8, 9, 10],
      state: { array: [7, 1, 5, 3, 6, 4], hashMap: { maxProfit: 4, profit: 2 } },
      pointers: { l: 1, r: 3 },
      highlights: [1, 3],
      explanation: 'Buy at 1, sell at 3 → profit = 2 (less than current max)',
    },
    {
      description: 'r=4, prices[4]=6 > prices[1]=1. Profit = 6-1=5. NEW maxProfit=5!',
      codeLineHighlight: [8, 9, 10],
      state: { array: [7, 1, 5, 3, 6, 4], hashMap: { maxProfit: 5, profit: 5 } },
      pointers: { l: 1, r: 4 },
      highlights: [1, 4],
      found: [1, 4],
      explanation: '🎉 Buy at 1, sell at 6 → profit = 5 (new best!)',
    },
    {
      description: 'r=5, prices[5]=4 > prices[1]=1. Profit = 4-1=3. maxProfit stays 5.',
      codeLineHighlight: [8, 9, 10],
      state: { array: [7, 1, 5, 3, 6, 4], hashMap: { maxProfit: 5, profit: 3 } },
      pointers: { l: 1, r: 5 },
      highlights: [1, 5],
    },
    {
      description: 'Done! Maximum profit = 5 (buy at day 1, sell at day 4).',
      codeLineHighlight: [12],
      state: { array: [7, 1, 5, 3, 6, 4], hashMap: { maxProfit: 5 } },
      pointers: {},
      highlights: [],
      found: [1, 4],
      explanation: '✅ Best trade: Buy at $1, Sell at $6 → Profit = $5',
    },
  ],
}
