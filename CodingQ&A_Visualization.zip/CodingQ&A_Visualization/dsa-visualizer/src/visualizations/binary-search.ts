import { Visualization } from './index'

export const binarySearchVisualization: Visualization = {
  slug: 'binary-search',
  description: 'Given a sorted array of integers and a target, return the index of the target. If not found, return -1.',
  approach: 'Maintain left and right pointers. Calculate mid, compare with target. If target > mid, search right half. If target < mid, search left half.',
  timeComplexity: 'O(log n)',
  spaceComplexity: 'O(1)',
  visualizerTitle: 'nums = [-1, 0, 3, 5, 9, 12], target = 9',
  code: `def search(nums, target):
    l, r = 0, len(nums) - 1
    
    while l <= r:
        mid = (l + r) // 2
        if nums[mid] < target:
            l = mid + 1
        elif nums[mid] > target:
            r = mid - 1
        else:
            return mid
    
    return -1`,
  steps: [
    {
      description: 'Initialize: l=0, r=5. Searching for target=9.',
      codeLineHighlight: [2],
      state: { array: [-1, 0, 3, 5, 9, 12] },
      pointers: { l: 0, r: 5 },
      highlights: [],
    },
    {
      description: 'mid = (0+5)//2 = 2. nums[2]=3. 3 < 9, so search right half: l = mid+1 = 3.',
      codeLineHighlight: [5, 6, 7],
      state: { array: [-1, 0, 3, 5, 9, 12] },
      pointers: { l: 0, r: 5, mid: 2 },
      highlights: [2],
      explanation: 'nums[2]=3 < target=9 → move left pointer right',
    },
    {
      description: 'l=3, r=5. mid = (3+5)//2 = 4. nums[4]=9. 9 == target!',
      codeLineHighlight: [5, 10, 11],
      state: { array: [-1, 0, 3, 5, 9, 12] },
      pointers: { l: 3, r: 5, mid: 4 },
      highlights: [3, 4, 5],
      found: [4],
      explanation: '✅ Found target 9 at index 4!',
    },
  ],
}
