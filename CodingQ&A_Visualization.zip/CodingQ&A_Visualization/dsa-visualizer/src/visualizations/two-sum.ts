import { Visualization } from './index'

export const twoSumVisualization: Visualization = {
  slug: 'two-sum',
  description: 'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.',
  approach: 'Use a HashMap to store each number and its index as we iterate. For each number, check if (target - num) already exists in the map. If it does, we found our answer.',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(n)',
  visualizerTitle: 'nums = [2, 7, 11, 15], target = 9',
  code: `def twoSum(nums, target):
    hashmap = {}  # val -> index
    
    for i, n in enumerate(nums):
        complement = target - n
        if complement in hashmap:
            return [hashmap[complement], i]
        hashmap[n] = i
    
    return []`,
  steps: [
    {
      description: 'Initialize empty HashMap. We will store {value: index} pairs.',
      codeLineHighlight: [2],
      state: { array: [2, 7, 11, 15], hashMap: {} },
      pointers: {},
      highlights: [],
    },
    {
      description: 'i=0, n=2. Calculate complement: target - n = 9 - 2 = 7',
      codeLineHighlight: [4, 5],
      state: { array: [2, 7, 11, 15], hashMap: {} },
      pointers: { i: 0 },
      highlights: [0],
      explanation: 'Looking for 7 in hashmap... not found yet.',
    },
    {
      description: 'Complement 7 not in hashmap. Store nums[0]=2 with index 0.',
      codeLineHighlight: [7],
      state: { array: [2, 7, 11, 15], hashMap: { 2: 0 } },
      pointers: { i: 0 },
      highlights: [0],
    },
    {
      description: 'i=1, n=7. Calculate complement: target - n = 9 - 7 = 2',
      codeLineHighlight: [4, 5],
      state: { array: [2, 7, 11, 15], hashMap: { 2: 0 } },
      pointers: { i: 1 },
      highlights: [1],
      explanation: 'Looking for 2 in hashmap... FOUND! hashmap[2] = 0',
    },
    {
      description: '✅ Found! complement 2 is in hashmap at index 0. Return [0, 1].',
      codeLineHighlight: [6],
      state: { array: [2, 7, 11, 15], hashMap: { 2: 0 } },
      pointers: { i: 1 },
      highlights: [],
      found: [0, 1],
      explanation: 'nums[0] + nums[1] = 2 + 7 = 9 ✓',
    },
  ],
}
