import { Visualization } from './index'

export const containsDuplicateVisualization: Visualization = {
  slug: 'contains-duplicate',
  description: 'Given an integer array nums, return true if any value appears at least twice in the array.',
  approach: 'Use a HashSet to track seen numbers. For each number, check if it is already in the set. If yes, return true. Otherwise, add it to the set.',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(n)',
  visualizerTitle: 'nums = [1, 2, 3, 1]',
  code: `def containsDuplicate(nums):
    seen = set()
    
    for n in nums:
        if n in seen:
            return True
        seen.add(n)
    
    return False`,
  steps: [
    {
      description: 'Initialize empty set to track seen numbers.',
      codeLineHighlight: [2],
      state: { array: [1, 2, 3, 1], hashMap: { 'seen': '{}' } },
      pointers: {},
      highlights: [],
    },
    {
      description: 'n=1. Check if 1 is in seen... No. Add 1 to seen.',
      codeLineHighlight: [4, 5, 7],
      state: { array: [1, 2, 3, 1], hashMap: { 'seen': '{1}' } },
      pointers: { n: 0 },
      highlights: [0],
    },
    {
      description: 'n=2. Check if 2 is in seen... No. Add 2 to seen.',
      codeLineHighlight: [4, 5, 7],
      state: { array: [1, 2, 3, 1], hashMap: { 'seen': '{1, 2}' } },
      pointers: { n: 1 },
      highlights: [1],
    },
    {
      description: 'n=3. Check if 3 is in seen... No. Add 3 to seen.',
      codeLineHighlight: [4, 5, 7],
      state: { array: [1, 2, 3, 1], hashMap: { 'seen': '{1, 2, 3}' } },
      pointers: { n: 2 },
      highlights: [2],
    },
    {
      description: '✅ n=1. Check if 1 is in seen... YES! Return True — duplicate found!',
      codeLineHighlight: [5, 6],
      state: { array: [1, 2, 3, 1], hashMap: { 'seen': '{1, 2, 3}' } },
      pointers: { n: 3 },
      highlights: [],
      found: [0, 3],
      explanation: 'Value 1 appears at index 0 and index 3 — duplicate!',
    },
  ],
}
