import { Visualization } from './index'

export const invertBinaryTreeVisualization: Visualization = {
  slug: 'invert-binary-tree',
  description: 'Given the root of a binary tree, invert the tree (swap left and right children at every node).',
  approach: 'Use recursion (DFS). At each node, swap its left and right children, then recursively invert the subtrees.',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(h) — height of tree for recursion stack',
  visualizerTitle: 'Tree: [4, 2, 7, 1, 3, 6, 9]',
  code: `def invertTree(root):
    if not root:
        return None
    
    # Swap children
    root.left, root.right = root.right, root.left
    
    # Recurse
    invertTree(root.left)
    invertTree(root.right)
    
    return root`,
  steps: [
    {
      description: 'Start at root (4). Tree: [4, 2, 7, 1, 3, 6, 9].',
      codeLineHighlight: [1, 2],
      state: { array: [4, 2, 7, 1, 3, 6, 9] },
      pointers: { root: 0 },
      highlights: [0],
      explanation: 'Level-order: 4 is root, 2/7 are children, 1/3/6/9 are leaves',
    },
    {
      description: 'At root (4): Swap left child (2) with right child (7).',
      codeLineHighlight: [6],
      state: { array: [4, 7, 2, 1, 3, 6, 9] },
      pointers: { root: 0 },
      highlights: [1, 2],
      explanation: 'Root\'s children swapped: left=7, right=2',
    },
    {
      description: 'Recurse left → now at node 7. Swap its children: 6 ↔ 9.',
      codeLineHighlight: [6, 9],
      state: { array: [4, 7, 2, 9, 6, 1, 3] },
      pointers: { node: 1 },
      highlights: [3, 4],
      explanation: 'Node 7: left becomes 9, right becomes 6',
    },
    {
      description: 'Recurse right → now at node 2. Swap its children: 1 ↔ 3.',
      codeLineHighlight: [6, 10],
      state: { array: [4, 7, 2, 9, 6, 3, 1] },
      pointers: { node: 2 },
      highlights: [5, 6],
      explanation: 'Node 2: left becomes 3, right becomes 1',
    },
    {
      description: 'All leaf nodes reached (base case: None). Recursion complete!',
      codeLineHighlight: [12],
      state: { array: [4, 7, 2, 9, 6, 3, 1] },
      pointers: {},
      highlights: [],
      found: [0, 1, 2, 3, 4, 5, 6],
      explanation: '✅ Tree inverted! Original: [4,2,7,1,3,6,9] → Result: [4,7,2,9,6,3,1]',
    },
  ],
}
