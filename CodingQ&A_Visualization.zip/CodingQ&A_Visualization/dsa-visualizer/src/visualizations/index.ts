import { VisualizationStep } from '../store/useVisualizerStore'
import { twoSumVisualization } from './two-sum'
import { containsDuplicateVisualization } from './contains-duplicate'
import { validPalindromeVisualization } from './valid-palindrome'
import { binarySearchVisualization } from './binary-search'
import { validParenthesesVisualization } from './valid-parentheses'
import { bestTimeToBuyAndSellStockVisualization } from './best-time-to-buy-and-sell-stock'
import { twoSumIIVisualization } from './two-sum-ii'
import { reverseLinkedListVisualization } from './reverse-linked-list'
import { invertBinaryTreeVisualization } from './invert-binary-tree'
import { validAnagramVisualization } from './valid-anagram'

export interface Visualization {
  slug: string
  description: string
  approach: string
  timeComplexity: string
  spaceComplexity: string
  code: string
  steps: VisualizationStep[]
  visualizerTitle?: string
}

const visualizations: Record<string, Visualization> = {
  'two-sum': twoSumVisualization,
  'contains-duplicate': containsDuplicateVisualization,
  'valid-anagram': validAnagramVisualization,
  'valid-palindrome': validPalindromeVisualization,
  'binary-search': binarySearchVisualization,
  'valid-parentheses': validParenthesesVisualization,
  'best-time-to-buy-and-sell-stock': bestTimeToBuyAndSellStockVisualization,
  'two-sum-ii-input-array-is-sorted': twoSumIIVisualization,
  'reverse-linked-list': reverseLinkedListVisualization,
  'invert-binary-tree': invertBinaryTreeVisualization,
}

export function getVisualization(slug: string): Visualization | null {
  return visualizations[slug] || null
}
