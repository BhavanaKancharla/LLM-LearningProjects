import { Visualization } from './index'

export const twoSumIIVisualization: Visualization = {
  slug: 'two-sum-ii-input-array-is-sorted',
  description: 'Given a sorted array, find two numbers that add up to target. Return their 1-indexed positions.',
  approach: 'Use two pointers — one at start, one at end. If sum is too small, move left pointer right. If sum is too large, move right pointer left.',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(1)',
  visualizerTitle: 'numbers = [2, 7, 11, 15], target = 9',
  code: `def twoSum(numbers, target):
    l, r = 0, len(numbers) - 1
    
    while l < r:
        curr_sum = numbers[l] + numbers[r]
        if curr_sum > target:
            r -= 1
        elif curr_sum < target:
            l += 1
        else:
            return [l + 1, r + 1]`,
  steps: [
    {
      description: 'Initialize: l=0, r=3. target=9.',
      codeLineHighlight: [2],
      state: { array: [2, 7, 11, 15] },
      pointers: { l: 0, r: 3 },
      highlights: [],
    },
    {
      description: 'sum = numbers[0] + numbers[3] = 2 + 15 = 17. 17 > 9, move r left.',
      codeLineHighlight: [5, 6, 7],
      state: { array: [2, 7, 11, 15], hashMap: { sum: 17, target: 9 } },
      pointers: { l: 0, r: 3 },
      highlights: [0, 3],
      explanation: 'Sum 17 is too large → decrease by moving right pointer',
    },
    {
      description: 'sum = numbers[0] + numbers[2] = 2 + 11 = 13. 13 > 9, move r left.',
      codeLineHighlight: [5, 6, 7],
      state: { array: [2, 7, 11, 15], hashMap: { sum: 13, target: 9 } },
      pointers: { l: 0, r: 2 },
      highlights: [0, 2],
      explanation: 'Sum 13 still too large → move right pointer again',
    },
    {
      description: 'sum = numbers[0] + numbers[1] = 2 + 7 = 9. 9 == target! Found!',
      codeLineHighlight: [5, 10, 11],
      state: { array: [2, 7, 11, 15], hashMap: { sum: 9, target: 9 } },
      pointers: { l: 0, r: 1 },
      highlights: [],
      found: [0, 1],
      explanation: '✅ 2 + 7 = 9. Return [1, 2] (1-indexed)',
    },
  ],
}
