# DSA Visualizer

Step-by-step animated walkthroughs for 130+ coding problems. Visualize how algorithms work — pointers moving through arrays, trees being traversed, stacks growing and shrinking.

## Getting Started

```bash
# Install dependencies
npm install

# Start dev server
npm run dev
```

Open http://localhost:5173

## Features

- **Animated Step-by-Step Walkthroughs** — Watch pointers move, cells highlight, and data structures transform
- **Code Panel with Line Highlighting** — See exactly which line of code executes at each step
- **Playback Controls** — Play/pause, step forward/back, speed control (0.5x to 4x)
- **15 Problem Categories** — Arrays, Two Pointers, Sliding Window, Stack, Binary Search, Linked Lists, Trees, Heaps, Backtracking, Tries, Graphs, Advanced Graphs, DP 1D, DP 2D, Greedy
- **130+ Problems Listed** — With visualizations being added progressively

## Currently Visualized (10 problems)

1. Two Sum (Arrays & Hashing)
2. Contains Duplicate (Arrays & Hashing)
3. Valid Anagram (Arrays & Hashing)
4. Valid Palindrome (Two Pointers)
5. Two Sum II (Two Pointers)
6. Best Time to Buy and Sell Stock (Sliding Window)
7. Valid Parentheses (Stack)
8. Binary Search (Binary Search)
9. Reverse Linked List (Linked List)
10. Invert Binary Tree (Trees)

## Adding New Visualizations

Create a new file in `src/visualizations/`:

```ts
import { Visualization } from './index'

export const myVisualization: Visualization = {
  slug: 'problem-slug',
  description: 'Problem description',
  approach: 'How the algorithm works',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(1)',
  visualizerTitle: 'Input display',
  code: `def solution():
    ...`,
  steps: [
    {
      description: 'What happens in this step',
      codeLineHighlight: [1, 2],  // lines to highlight
      state: { array: [1, 2, 3] },
      pointers: { i: 0 },         // named pointers
      highlights: [0],            // active cells
      found: [],                  // "answer" cells (green)
      explanation: 'Extra context',
    },
  ],
}
```

Then register it in `src/visualizations/index.ts`.

## Tech Stack

- React 18 + TypeScript
- Vite 5
- Tailwind CSS 3
- Framer Motion (animations)
- Zustand (state management)
- React Router 6
