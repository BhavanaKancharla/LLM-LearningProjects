# Setup Guide

## Prerequisites

- **Node.js** v18+ (recommended: v20+)
- **npm** v9+ (comes with Node.js)
- A modern browser (Chrome, Firefox, Edge, Safari)

## Installation

```bash
# 1. Navigate to the project
cd dsa-visualizer

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev
```

The app will open at **http://localhost:5173**

## Build for Production

```bash
npm run build
```

Output goes to `dist/` — deploy this folder anywhere (Vercel, Netlify, GitHub Pages, etc.)

## Preview Production Build

```bash
npm run preview
```

---

## AI Assistant Setup

The AI Assistant supports 3 providers. Choose one:

### Option A: OpenAI (Recommended for quality)

1. Get an API key from https://platform.openai.com/api-keys
2. In the app, go to **🤖 AI Help → ⚙️ Settings**
3. Set:
   - Provider: `OpenAI`
   - Model: `gpt-4o-mini` (cheap & fast) or `gpt-4o` (best quality)
   - API Key: paste your key

**Cost:** ~$0.01–0.05 per conversation

### Option B: Google Gemini (Free tier available)

1. Get an API key from https://aistudio.google.com/apikey
2. In the app, go to **🤖 AI Help → ⚙️ Settings**
3. Set:
   - Provider: `Google Gemini`
   - Model: `gemini-1.5-flash` (fast) or `gemini-1.5-pro` (better)
   - API Key: paste your key

**Cost:** Free tier available (60 requests/minute)

### Option C: Ollama (Free, runs locally)

1. Install Ollama: https://ollama.ai/download
2. Pull a model:
   ```bash
   ollama pull llama3
   # or for coding-focused:
   ollama pull codellama
   ```
3. Ollama runs automatically on `http://localhost:11434`
4. In the app, go to **🤖 AI Help → ⚙️ Settings**
5. Set:
   - Provider: `Ollama (Local)`
   - Model: `llama3` (or whichever you pulled)
   - API Key: leave blank
   - Base URL: `http://localhost:11434/api/chat` (default)

**Cost:** Completely free. Runs on your machine.

---

## Project Structure

```
dsa-visualizer/
├── public/                  # Static assets
├── src/
│   ├── components/          # Reusable UI components
│   │   ├── ArrayVisualizer.tsx   # Animated array/cell display
│   │   ├── CodePanel.tsx         # Code editor with line highlighting
│   │   ├── Layout.tsx            # App shell (nav, footer)
│   │   └── StepControls.tsx      # Play/pause/step/speed controls
│   ├── data/
│   │   └── problems.ts     # All 130+ problems & categories
│   ├── pages/
│   │   ├── AIAssistantPage.tsx   # AI chat interface
│   │   ├── BuilderPage.tsx       # Visualization builder tool
│   │   ├── CategoryPage.tsx      # Category problem list
│   │   ├── HomePage.tsx          # Main dashboard
│   │   └── ProblemPage.tsx       # Visualization player
│   ├── store/
│   │   ├── useCustomProblems.ts  # Saved custom visualizations
│   │   └── useVisualizerStore.ts # Playback state (steps, speed)
│   ├── visualizations/      # Step-by-step data per problem
│   │   ├── index.ts              # Registry of all visualizations
│   │   ├── two-sum.ts
│   │   ├── binary-search.ts
│   │   └── ... (10 problems)
│   ├── App.tsx              # Route definitions
│   ├── index.css            # Tailwind + custom styles
│   └── main.tsx             # Entry point
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── vite.config.ts
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `npm install` fails | Make sure Node.js v18+ is installed: `node --version` |
| Port 5173 in use | Run `npm run dev -- --port 3000` to use a different port |
| AI not responding | Check API key in Settings. For Ollama, make sure it's running (`ollama serve`) |
| Styles look broken | Clear browser cache or run `npm run dev` fresh |
| TypeScript errors on build | Run `npm install` again to ensure all types are installed |

---

## Tech Stack

| Technology | Purpose |
|-----------|---------|
| React 18 | UI framework |
| TypeScript | Type safety |
| Vite 5 | Build tool & dev server |
| Tailwind CSS 3 | Utility-first styling |
| Framer Motion | Animations (cell highlights, transitions) |
| Zustand | State management (step playback) |
| React Router 6 | Client-side routing |
| D3.js | (Available for tree/graph visualizations) |
