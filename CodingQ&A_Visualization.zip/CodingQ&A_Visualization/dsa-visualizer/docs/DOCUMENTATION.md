# DSA Visualizer — Documentation

## What Is This?

DSA Visualizer is a personal learning tool that helps you **understand how algorithms work visually**. After you solve a coding problem, you can see the solution execute step-by-step with:

- **Animated arrays** with highlighted cells, colored pointers, and state changes
- **Code highlighting** showing exactly which line runs at each step
- **Playback controls** — play, pause, step forward/back, speed adjustment
- **AI tutor** that explains approaches, gives hints, and helps debug your code

It's built for the ~130 most common DSA problems grouped by pattern (Arrays, Two Pointers, Sliding Window, Trees, Graphs, DP, etc.)

---

## Features

### 1. Problem Browser (Home Page — `/`)

A grid of 15 categories with all problems listed. Each category shows:
- Number of total problems
- How many have visualizations built
- Progress bar

Click a category to see its problems, click a problem to see the visualization.

### 2. Step-by-Step Visualization (`/problem/:slug`)

The core feature. For each visualized problem you see:

**Left Panel — Visual Animation:**
- Array cells rendered as boxes with values
- **Pointers** (labeled arrows) showing where variables point (e.g., `i`, `j`, `left`, `right`)
- **Highlights** (blue glow) — cells currently being examined
- **Found** (green glow) — cells that are part of the answer
- **HashMap display** — shows auxiliary data structures

**Right Panel — Code:**
- The solution code with line numbers
- Current step's active lines highlighted in blue
- Approach explanation with time/space complexity

**Bottom — Controls:**
- ▶️ Play / ⏸ Pause — auto-advances through steps
- ⏪ ⏩ — Step backward/forward manually
- ⏮ — Reset to beginning
- Speed: 0.5x, 1x, 2x, 4x
- Timeline dots — click any step to jump to it
- Step description — explains what's happening in plain English

### 3. Visualization Builder (`/builder`)

Create your own visualizations interactively:

**Left Side:**
- Write/paste your solution code
- Set the problem title

**Right Side — Step Editor:**
- Add/remove/duplicate steps
- For each step, define:
  - **Description** — what happens (shown to user during playback)
  - **Array** — the data being visualized
  - **Pointers** — named positions (e.g., `left:0, right:4`)
  - **Code Lines** — which lines to highlight
  - **Highlights** — active cells (blue)
  - **Found** — answer cells (green)
  - **HashMap** — extra state to display
  - **Explanation** — callout text
- Live mini-preview of the current step

**Actions:**
- **Preview** — run the full animation with controls
- **Export** — get JSON to save/share
- **Import** — load a previously exported visualization
- **Save** — persist to browser localStorage (survives refresh)

### 4. AI DSA Assistant (`/assistant`)

A conversational AI tutor that helps with DSA problems:

**Capabilities:**
- Explains any LeetCode problem's approach
- Gives escalating hints (small hint → pattern → full approach → solution)
- Debugs your code — paste it in and ask what's wrong
- Explains patterns (sliding window, two pointers, BFS/DFS, DP, etc.)
- Compares approaches (brute force vs optimized)
- Explains time/space complexity

**Hint Buttons (quick actions):**
| Button | What it does |
|--------|-------------|
| 💡 Small Hint | Nudge without revealing the approach |
| 🧩 Pattern Hint | Tells you which technique to use |
| 📐 Approach | Full step-by-step walkthrough |
| 💻 Solution | Complete code with comments |

**Problem Picker:**
Click "📋 Problems" to see all 130+ problems grouped by category. Click one to instantly ask the AI about it.

**Supported AI Providers:**
- OpenAI (GPT-4o-mini, GPT-4o)
- Google Gemini (gemini-1.5-flash, gemini-1.5-pro)
- Ollama (any local model — free, no API key)

**Privacy:** API keys are stored only in your browser's localStorage. The app never sends your keys to any server other than the AI provider you chose.

---

## How the Visualization System Works

### Data Model

Each visualization is defined as a TypeScript object:

```typescript
interface Visualization {
  slug: string               // URL-friendly identifier
  description: string        // Problem statement
  approach: string           // How the algorithm works
  timeComplexity: string     // e.g., "O(n)"
  spaceComplexity: string    // e.g., "O(1)"
  code: string               // The solution code
  visualizerTitle: string    // Shown above the array
  steps: VisualizationStep[] // Array of step objects
}

interface VisualizationStep {
  description: string              // "Check if complement in hashmap"
  codeLineHighlight: number[]      // [4, 5] — lines to highlight
  state: {
    array: number[] | string[]     // Data to display as cells
    hashMap?: Record<string, any>  // Extra state to show
  }
  pointers?: Record<string, number> // { i: 0, j: 3 }
  highlights?: number[]             // Blue-highlighted indices
  found?: number[]                  // Green "answer" indices
  explanation?: string              // Callout text
}
```

### Playback Engine

The `useVisualizerStore` (Zustand) manages:
- `currentStep` — which step is active
- `isPlaying` — auto-advance active
- `speed` — ms between steps (250–2000)
- `steps` — the full step array
- Controls: `nextStep()`, `prevStep()`, `goToStep(n)`, `play()`, `pause()`, `reset()`

When playing, a `setInterval` advances `currentStep` every `speed` milliseconds. Components react to `currentStep` changes and animate accordingly using Framer Motion.

### Adding a New Visualization

1. Create `src/visualizations/my-problem.ts`:

```typescript
import { Visualization } from './index'

export const myProblemVisualization: Visualization = {
  slug: 'my-problem',
  description: 'Problem statement here',
  approach: 'How the algorithm works',
  timeComplexity: 'O(n)',
  spaceComplexity: 'O(1)',
  visualizerTitle: 'nums = [1, 2, 3, 4]',
  code: `def myFunction(nums):
    # your solution
    pass`,
  steps: [
    {
      description: 'Initialize variables',
      codeLineHighlight: [1],
      state: { array: [1, 2, 3, 4] },
      pointers: { i: 0 },
      highlights: [0],
    },
    // ... more steps
  ],
}
```

2. Register in `src/visualizations/index.ts`:

```typescript
import { myProblemVisualization } from './my-problem'

// Add to the visualizations record:
const visualizations: Record<string, Visualization> = {
  // ...existing ones
  'my-problem': myProblemVisualization,
}
```

3. Mark it as visualized in `src/data/problems.ts`:

```typescript
{ slug: 'my-problem', title: 'My Problem', ..., hasVisualization: true },
```

### Using the Builder (Faster Way)

Instead of writing JSON by hand:

1. Go to `/builder`
2. Paste your code
3. Add steps visually
4. Hit **Export** → copy the JSON
5. Paste into a new `.ts` file in `src/visualizations/`

---

## Concepts & Patterns

The problems are organized into these DSA patterns:

| # | Category | Key Technique | Count |
|---|----------|---------------|-------|
| 1 | Arrays & Hashing | HashMap/HashSet lookups | 15 |
| 2 | Two Pointers | Left/right pointers converging | 10 |
| 3 | Sliding Window | Expandable/shrinkable window | 8 |
| 4 | Stack | LIFO for matching/tracking | 8 |
| 5 | Binary Search | Halving search space | 7 |
| 6 | Linked List | Pointer manipulation | 12 |
| 7 | Trees | Recursion, DFS, BFS | 15 |
| 8 | Heap / Priority Queue | Min/max heap operations | 7 |
| 9 | Backtracking | Generate all combinations | 10 |
| 10 | Trie | Prefix tree operations | 3 |
| 11 | Graphs – BFS/DFS | Traversal, connected components | 12 |
| 12 | Advanced Graphs | Dijkstra, topological sort | 6 |
| 13 | DP – 1D | Memoization with 1 dimension | 10 |
| 14 | DP – 2D | Memoization with 2 dimensions | 10 |
| 15 | Greedy & Intervals | Local optimal → global optimal | 8 |

**Total: ~131 problems**

---

## Recommended Learning Flow

1. **Pick a category** you want to study
2. **Read the problem** on LeetCode
3. **Try solving it** yourself (set a timer — 25 min for Medium)
4. **If stuck** → use the AI Assistant:
   - First ask for a small hint
   - Then ask for the pattern
   - Only ask for the full solution after genuinely trying
5. **Once you have a solution** → open the visualization to understand the flow
6. **Build your own visualization** in the Builder if one doesn't exist
7. **Review** — come back in 2–3 days and try solving it again without help

---

## Data Storage

| What | Where | Persists |
|------|-------|----------|
| Problem list | `src/data/problems.ts` | In code |
| Pre-built visualizations | `src/visualizations/*.ts` | In code |
| Custom visualizations | Browser localStorage | Per browser |
| AI chat history | Browser localStorage | Per browser (last 50 msgs) |
| AI config (provider/key) | Browser localStorage | Per browser |

---

## Extending the App

### Adding Tree/Graph Visualizations

The `d3` library is already included. Create a new component:

```typescript
// src/components/TreeVisualizer.tsx
// Use D3 to render tree nodes and edges
// Listen to useVisualizerStore for currentStep
// Highlight nodes based on step.highlights
```

### Adding More Visualizer Types

Beyond arrays, you might want:
- **Stack visualizer** — vertical stack with push/pop animations
- **Linked list visualizer** — nodes with arrows
- **Grid/matrix visualizer** — 2D grid for BFS/DFS problems
- **Graph visualizer** — nodes + edges with D3 force layout

Each would be a new component in `src/components/` that reads from the same `useVisualizerStore`.

### Deploying

```bash
npm run build
```

Then deploy the `dist/` folder to:
- **Vercel**: `npx vercel` (zero config)
- **Netlify**: drag & drop `dist/` folder
- **GitHub Pages**: push `dist/` to gh-pages branch
